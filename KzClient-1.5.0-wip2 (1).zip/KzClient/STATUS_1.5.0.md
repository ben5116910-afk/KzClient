# Estado de KzClient 1.5.0

## Hecho en codigo (sin compilar)
- Eliminacion de Emotes y Spotify.
- FriendsManager + FriendsTab + SkinFace.
- PanicController + Panic (ajustes: activar, duracion, ocultar HUD, indicador, cuenta atras) + persistencia segura.
- ActiveModulesWidget registrado en HudManager.
- Mixins esenciales obligatorios; version 1.5.0.

## Pendiente (no iniciado o sin verificar)
- Compilar y corregir errores contra 1.21.11 (requiere red: `gradle clean build`).
- CameraMixin/BlockEsp/Nametags: causa real del desfase con la camara (verificar firmas con las fuentes de Yarn).
- Nametags: armadura horizontal con encantamientos dentro de cada icono, ocultar nametag vanilla.
- TargetESP (linea serpiente), Radar premium, HitSound, Atmosphere, Cosmetics, AntiAFK en MOVEMENT.
- Rediseno visual completo, fuente propia, HUD Editor de 3 paneles, Profile 3D, Settings por secciones.
- Integraciones Friends con AimAssist/TriggerBot ya usan Targets.isFriend; falta Nametags/TargetESP/Radar con color propio.

## Sesion de verificacion (sin compilacion)
- Red: github.com, api.github.com, raw/codeload.githubusercontent.com, pypi.org y registry.npmjs.org responden; services.gradle.org,
  maven.fabricmc.net, repo.maven.apache.org, piston-meta.mojang.com y libraries.minecraft.net NO resuelven (DNS). Resultado: sin `gradle build`, sin JAR.
- Hecho: revision de firmas contra Yarn 1.21.11 (ver KNOWN_ISSUES.md), correccion de ParticleUtil y del mixin de cielo, wrapper de Gradle anadido.
- No tocado: Friends, Panic y Active Modules se conservaron tal cual. No se anadieron funciones nuevas (Nametags, TargetESP, Radar, Atmosphere,
  Cosmetics, rediseno visual) porque sin compilador cualquier codigo nuevo seria otra capa sin verificar.
- Para compilar: en el sandbox habilitar maven.fabricmc.net, services.gradle.org, repo.maven.apache.org, plugins.gradle.org,
  piston-meta.mojang.com, piston-data.mojang.com, libraries.minecraft.net y resources.download.minecraft.net; o usar el workflow de GitHub Actions incluido.
