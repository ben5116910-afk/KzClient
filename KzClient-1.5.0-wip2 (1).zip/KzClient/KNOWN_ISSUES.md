# Puntos de riesgo (APIs de 1.21.11 no verificadas por compilacion)

- KzClient: HudElementRegistry.addLast, AttackEntityCallback, ClientLifecycleEvents.
- DrawContext.getMatrices() como Matrix3x2fStack (pushMatrix/translate/scale) en HudWidget, HudTab y Nametags.
- InventoryScreen.drawEntity(...): se usa con DOS firmas distintas en SkinViewer y SkinViewerFeature; al menos una es incorrecta.
- AutoTool: PlayerInventory.getSelectedSlot()/setSelectedSlot(int); ItemStack.getMiningSpeedMultiplier(BlockState).
- Targets.mining: ClientPlayerInteractionManager.isBreakingBlock().
- PlayerListEntry.getProfile().name() (StaffList, AntiVanish).
- Nametags: ItemStack.getEnchantments().getEnchantmentEntries(), RegistryEntry.getIdAsString().
- ParticleUtil: ClientWorld.addParticleClient; DustParticleEffect(int, float).
- auth: net.minecraft.client.session.Session (constructor por reflexion), MinecraftClientAccessor (@Accessor "session").
- BrowserUtil: Util.getOperatingSystem().open(URI); MinecraftClient.keyboard.setClipboard(String).
- Mixins (defaultRequire 0, fallan en silencio): Entity.getTargetingMargin / isGlowing / getTeamColorValue /
  changeLookDirection, Camera.update(World, Entity, boolean, boolean, float), ClientWorld.getSkyColor(Vec3d, float),
  WorldRenderer.drawBlockOutline (int color, float width).

## Anadido en 1.2.0 (sin verificar por compilacion)
- CameraMixin: Camera.getPos(), getYaw(), getPitch() (captura FrameCamera) y inyeccion `update` sin argumentos.
- GameRendererMixin: GameRenderer.getFov(Camera, float, boolean) (si la firma difiere, el FOV cae a options.getFov()).
- Projector: Entity.getYaw(float)/getPitch(float) en la ruta de respaldo.
- Nametags: PlayerListEntry.getLatency(), DrawContext.drawItem/fillGradient/drawText(.., boolean),
  getMatrices().pushMatrix()/translate/scale/popMatrix (Matrix3x2fStack).
- SettingPanel: DrawContext.fillGradient, enableScissor/disableScissor anidados, GLFW.glfwGetKey por tecla.
- Si algo falla al compilar, copia el error completo y lo corrijo.

## Anadido en 1.3.0 (sin verificar por compilacion)
- AntiAfk: KeyBinding.getBoundKeyTranslationKey(), InputUtil.fromTranslationKey(String).getCode(), KeyBinding.setPressed(boolean),
  LivingEntity.hurtTime, Entity.isClimbing()/isInLava(), Direction.rotateYCounterclockwise(), BlockPos.offset(Direction,int).
- Nametags: ItemStack.getEnchantments() (ItemEnchantmentsComponent.equals), Text.translatable(String).getString(), ItemStack.isDamageable().
- CameraMixin: Camera.update(World, Entity, boolean, boolean, float) con 5 argumentos; Camera.getPos()/getYaw()/getPitch();
  Window.getFramebufferWidth()/getFramebufferHeight().
- feature `skinviewer`: InventoryScreen.drawEntity(DrawContext,int,int,int,int,float,Vector3f,Quaternionf,Quaternionf,LivingEntity) publica;
  LivingEntity.bodyYaw/lastBodyYaw/headYaw/lastHeadYaw.
- feature `glint`: NativeImage.read/getColorArgb/setColorArgb/getWidth/getHeight, NativeImageBackedTexture.getImage()/upload(),
  TextureManager.registerTexture(Identifier, AbstractTexture)/destroyTexture(Identifier), ResourceManager.open(Identifier),
  Identifier.ofVanilla(String). Si falla alguna: `-Pfeature.<id>=false` y enviame el error.

## 1.4.0
- Sigue SIN compilar en el entorno de desarrollo (sin red ni jars). Se corrigieron los 4 errores que reportaste; pueden aparecer otros.
- CameraMixin: se asume que Camera.update llama a setPos para fijar la posicion final. Si FrameCamera nunca se captura, el proyector
  cae a la camara del jugador (sin mixin).
- MinecraftClientMixin: campo `session` de MinecraftClient (nombre Yarn).
- RadarWidget: AnimalEntity, HostileEntity, LivingEntity.isAlive().

## Pendiente respecto a tu lista (no hecho en esta pasada)
Rediseno completo de tooltips y de cada pantalla, efectos y temporizadores en Nametags, ubicacion configurable de la vida en Nametags,
revision linea a linea de cada modulo con pruebas en juego, MotionBlur / alas y capas 3D (ver README).

## 1.5.0
- SkinFace: PlayerSkinDrawer.draw(DrawContext, SkinTextures, int, int, int) y PlayerListEntry.getSkinTextures() sin verificar.
- FriendsManager: PlayerListEntry.getProfile().id()/name() (GameProfile como record), ClientPlayNetworkHandler.getPlayerList().
- PanicController/ActiveModulesWidget: solo usan APIs ya presentes en 1.4.0 (DrawContext.fill/drawText, MinecraftClient).
- kzclient.mixins.json ahora es required=true: si alguna firma de mixin no existe en 1.21.11 el juego lo indicara al arrancar.

## Verificacion contra Yarn 1.21.11 (sesion con red parcial)
Metodo: clon de https://github.com/FabricMC/yarn (rama 1.21.11) y comprobacion de nombre+descriptor. NO es una compilacion:
solo confirma que el metodo existe con esa firma en los mappings. Maven/Gradle/Fabric/Mojang no resolvieron DNS en el sandbox,
asi que no hubo `gradle build` y no existe JAR.

Confirmado OK: InventoryScreen.drawEntity(DrawContext,int,int,int,int,int,float,float,float,LivingEntity) (SkinViewer y
SkinViewerFeature ya coinciden); DrawContext.getMatrices() -> Matrix3x2fStack; fillGradient/enableScissor/drawItem/drawText;
PlayerInventory.get/setSelectedSlot; ClientPlayerInteractionManager.isBreakingBlock; PlayerListEntry.getProfile/getSkinTextures/getLatency;
PlayerSkinDrawer.draw(DrawContext,SkinTextures,int,int,int); Camera.update(World,Entity,boolean,boolean,float)/setPos(DDD)/setRotation/getYaw/getPitch;
GameRenderer.getFov(Camera,float,boolean); WorldRenderer.drawBlockOutline (hay un unico int y un unico float, por lo que el ModifyVariable
argsOnly sigue siendo valido); Entity.getTargetingMargin/isGlowing/getTeamColorValue/changeLookDirection; Session (constructor de 5 args);
Util.getOperatingSystem().open(URI); Keyboard.setClipboard; DustParticleEffect(int,float); ItemEnchantmentsComponent.getEnchantmentEntries;
RegistryEntry.getIdAsString; ItemStack.getMiningSpeedMultiplier/isDamageable; KeyBinding.setPressed/getBoundKeyTranslationKey;
InputUtil.fromTranslationKey; Direction.rotateYCounterclockwise; Vec3i.offset(Direction,int); Window.getFramebufferWidth/Height;
NativeImage/NativeImageBackedTexture/TextureManager (glint); ResourceFactory.open(Identifier); Identifier.ofVanilla; MinecraftClient.session.

Corregido en esta sesion (error real detectado):
- ParticleUtil: `World.addParticleClient` en 1.21.11 es (ParticleEffect, boolean force, boolean canSpawnOnMinimal, x,y,z,vx,vy,vz);
  la llamada de 7 argumentos no existia.
- Mixin ClientWorld.getSkyColor: ese metodo YA NO EXISTE. Con required=true el juego habria fallado al arrancar. Sustituido por
  SkyRenderingMixin sobre SkyRendering.updateRenderState(ClientWorld,float,Camera,SkyRenderState) escribiendo SkyRenderState.skyColor.

Sigue sin verificar (requiere compilar): que SkyRenderState.skyColor sea public (los mappings no indican acceso) y su formato de color
(ARGB vs RGB); HudElementRegistry/AttackEntityCallback/ClientLifecycleEvents (son de Fabric API, no de Yarn); la API de Fabric 0.141.3+1.21.11
y Loom `net.fabricmc.fabric-loom-remap` 1.15-SNAPSHOT; el wrapper (gradlew, gradlew.bat y gradle-wrapper.jar se tomaron del tag v9.2.1 de
github.com/gradle/gradle y no se les comprobo checksum).
