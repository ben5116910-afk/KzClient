# KzClient 1.5.0 (en desarrollo) - Fabric, Minecraft 1.21.11, Java 21

## Compilar
```
gradle clean build   # Gradle + JDK 21; el jar queda en build/libs/
```
**Estado de la compilacion: NO verificada.** Las sesiones de desarrollo hasta ahora no tuvieron acceso a Maven/Fabric/Mojang, asi que
ningun archivo se compilo contra los jars reales de 1.21.11. Solo se comprobo la sintaxis. Ver `STATUS_1.5.0.md` (que esta hecho y
que falta) y `KNOWN_ISSUES.md` (llamadas a la API sin verificar).

## Uso
- Panel: Right Shift (o Insert). Panic: End (configurable en SETTINGS > Keybinds). Cada modulo tiene tecla propia en su tarjeta.
- Configuracion: `config/kzclient/` -> `config.json`, `friends.json`, `lists.json` (staff), `blocks.txt`, `profiles/*.json`, `tokens.vault`.

## Novedades de 1.5.0 (hasta ahora)
- Eliminados Emotes y Spotify por completo (codigo, ajustes, teclas, HUD, dependencias de build y documentacion).
- Pestana **FRIENDS** (sustituye a EMOTES): buscador, tarjetas con avatar/estado, menu "...", confirmacion antes de eliminar,
  notificaciones, persistencia en `friends.json` (migra los amigos de `lists.json`).
- **API central de amigos**: `KzClient.friends().isFriend(Entity | String | UUID)`. `Targets.isFriend` y StaffList ya la usan.
- **Panic reconstruido** (`PanicController`): guarda el conjunto exacto de modulos activos, los suspende, oculta HUD/lista, muestra
  indicador con cuenta atras (30 s por defecto, configurable) y restaura todo solo al terminar o al pulsar de nuevo.
  Bug de 1.4.0 corregido: el autosave/cierre durante Panic guardaba los modulos apagados; ahora se guarda el estado original.
- **Active Modules** (widget de HUD): lista dinamica con animacion de entrada/salida, orden, tecla y fondo configurables.
- Mixins esenciales ahora son `required: true` (`defaultRequire: 1`): un fallo de inyeccion se ve en el log al arrancar en lugar de ocultarse.

## Funciones opcionales (`src/features/<id>`)
| id | Que anade |
|---|---|
| `skinviewer` | Visor de skin con giro libre en PROFILE (`InventoryScreen.drawEntity`) |
| `glint` | Modulo `CustomGlint` (color y arcoiris del brillo de encantamiento) |

Si una no compila: `gradle build -Pfeature.glint=false`.
