package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.input.KeybindManager;
import com.kzclient.module.modules.Animations;
import com.kzclient.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Panel principal. El raton se lee por GLFW (flancos de pulsacion) para no depender de las
 * firmas de entrada de Screen; el texto de los campos lo gestionan los TextFieldWidget.
 */
public final class ClickGuiScreen extends Screen {
    public static final int TAB_MODULES = 0;
    public static final int TAB_FRIENDS = 1;
    public static final int TAB_PROFILE = 2;
    public static final int TAB_HUD = 3;
    public static final int TAB_SETTINGS = 4;

    private static final String[] LABELS = {"MODULES", "FRIENDS", "PROFILE", "HUD", "SETTINGS"};
    private static final int HEADER_H = 36;

    private final GuiTab[] tabs = {new ModulesTab(), new FriendsTab(), new ProfileTab(), new HudTab(), new SettingsTab()};
    private final Frame frame = new Frame();
    private int current;

    private int wx;
    private int wy;
    private int ww;
    private int wh;
    private boolean placed;
    private boolean draggingWindow;
    private int dragOffX;
    private int dragOffY;

    private boolean prevLeft;
    private boolean prevRight;
    private boolean prevOpenKey;
    private long lastNanos;
    private double open;
    private double tabFade = 1.0;
    private boolean closing;

    public ClickGuiScreen(int tab) {
        super(Text.literal("KzClient"));
        this.current = Math.max(0, Math.min(tabs.length - 1, tab));
    }

    public TextFieldWidget registerField(TextFieldWidget field) {
        return addDrawableChild(field);
    }

    /** Cierra de inmediato (sin animacion). */
    public void requestClose() {
        super.close();
    }

    private void layout() {
        float scale = KzClient.settings().uiScale;
        ww = Math.min(Math.round(600 * scale), width - 16);
        wh = Math.min(Math.round(390 * scale), height - 16);
        if (!placed) {
            wx = (width - ww) / 2;
            wy = (height - wh) / 2;
            placed = true;
        }
        clampWindow();
    }

    @Override
    protected void init() {
        layout();
        for (GuiTab tab : tabs) {
            tab.init(this);
        }
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        prevLeft = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        prevRight = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        prevOpenKey = KeybindManager.isDown(KzClient.keybinds().key(KeybindManager.Action.OPEN_GUI));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Animations animations = KzClient.modules().get(Animations.class);
        if (animations.openClose() && !closing) {
            closing = true;
        } else {
            super.close();
        }
    }

    @Override
    public void removed() {
        if (KzClient.config() != null) {
            KzClient.config().save();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (tabs[current].scrolled(mouseX, mouseY, verticalAmount)) {
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void clampWindow() {
        wx = Math.max(0, Math.min(width - ww, wx));
        wy = Math.max(0, Math.min(height - wh, wy));
    }

    private boolean textFocused() {
        return getFocused() instanceof TextFieldWidget field && field.isFocused();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        long now = System.nanoTime();
        double dt = lastNanos == 0L ? 0.016 : Math.min(0.1, (now - lastNanos) / 1.0e9);
        lastNanos = now;

        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        boolean leftDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rightDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean click = leftDown && !prevLeft;
        boolean rightClick = rightDown && !prevRight;
        prevLeft = leftDown;
        prevRight = rightDown;

        boolean openKey = KeybindManager.isDown(KzClient.keybinds().key(KeybindManager.Action.OPEN_GUI));
        if (openKey && !prevOpenKey && !textFocused() && !tabs[current].capturing() && !closing) {
            prevOpenKey = true;
            close();
        }
        prevOpenKey = openKey;

        Animations animations = KzClient.modules().get(Animations.class);
        if (animations.openClose()) {
            open += ((closing ? 0.0 : 1.0) - open) * (1.0 - Math.exp(-dt * animations.speed()));
            if (closing && open < 0.03) {
                super.close();
                return;
            }
        } else {
            open = closing ? 0.0 : 1.0;
            if (closing) {
                super.close();
                return;
            }
        }
        double e = Math.max(0.0, Math.min(1.0, open));
        int oy = (int) Math.round((1.0 - e) * 14.0);
        if (animations.tabFade()) {
            tabFade = Math.min(1.0, tabFade + dt * animations.speed() * 0.9);
        } else {
            tabFade = 1.0;
        }

        if (!leftDown) {
            draggingWindow = false;
        }
        if (draggingWindow) {
            wx = mouseX - dragOffX;
            wy = mouseY - dragOffY;
            clampWindow();
        }
        int top = wy + oy;
        TextRenderer font = MinecraftClient.getInstance().textRenderer;

        ctx.fill(0, 0, width, height, ColorUtil.withAlpha(0x000000, (int) (0x99 * e)));
        Render2D.shadow(ctx, wx, top, ww, wh, 8, 5);
        Render2D.roundedRect(ctx, wx - 1, top - 1, ww + 2, wh + 2, 9, ThemePalette.ACCENT_SOFT);
        Render2D.roundedPanel(ctx, wx, top, ww, wh, 8,
                ColorUtil.withAlpha(ThemePalette.BACKGROUND, KzClient.settings().opacity * 255 / 100),
                ThemePalette.BORDER);
        Render2D.watermarkKz(ctx, wx + ww / 2 + 50, top + HEADER_H + (wh - HEADER_H) / 2, Math.max(5, wh / 18),
                ThemePalette.WATERMARK);

        drawHeader(ctx, font, top, mouseX, mouseY, click);

        frame.ctx = ctx;
        frame.font = font;
        frame.mx = mouseX;
        frame.my = mouseY;
        frame.click = click && !draggingWindow;
        frame.rightClick = rightClick;
        frame.leftDown = leftDown;
        frame.dt = dt;
        frame.x = wx;
        frame.y = top + HEADER_H;
        frame.w = ww;
        frame.h = wh - HEADER_H;
        frame.screenW = width;
        frame.screenH = height;
        for (int i = 0; i < tabs.length; i++) {
            if (i != current) {
                tabs[i].hide();
            }
        }
        tabs[current].draw(frame);

        if (tabFade < 1.0) {
            Render2D.roundedRect(ctx, wx + 1, top + HEADER_H + 1, ww - 2, wh - HEADER_H - 2, 7,
                    ColorUtil.withAlpha(ThemePalette.BACKGROUND, (int) ((1.0 - tabFade) * 255)));
        }
        if (e < 0.999) {
            Render2D.roundedRect(ctx, wx - 1, top - 1, ww + 2, wh + 2, 9,
                    ColorUtil.withAlpha(ThemePalette.BACKGROUND, (int) ((1.0 - e) * 255)));
        }
    }

    private void drawHeader(DrawContext ctx, TextRenderer font, int top, int mx, int my, boolean click) {
        Render2D.roundedRect(ctx, wx + 1, top + 1, ww - 2, HEADER_H, 7, ThemePalette.HEADER);
        ctx.fill(wx + 1, top + HEADER_H - 8, wx + ww - 1, top + HEADER_H, ThemePalette.HEADER);
        ctx.fillGradient(wx + 1, top + 1, wx + ww - 1, top + HEADER_H, 0x30000000 | (ThemePalette.ACCENT & 0xFFFFFF),
                0x00000000 | (ThemePalette.ACCENT & 0xFFFFFF));
        ctx.fill(wx + 1, top + HEADER_H, wx + ww - 1, top + HEADER_H + 1, ThemePalette.BORDER);

        Render2D.text(ctx, font, "KZ", wx + 14, top + 14, ThemePalette.ACCENT);
        Render2D.text(ctx, font, Frame.fit(font, KzClient.brand(false), 60), wx + 14 + font.getWidth("KZ") + 6, top + 14,
                ThemePalette.TEXT_DIM);

        boolean headerClick = click && Render2D.inside(mx, my, wx, top, ww, HEADER_H);
        int tx = wx + 112;
        for (int i = 0; i < LABELS.length; i++) {
            int tw = font.getWidth(LABELS[i]) + 20;
            boolean selected = i == current;
            boolean hover = Render2D.inside(mx, my, tx, top + 8, tw, 22);
            if (selected) {
                Render2D.roundedRect(ctx, tx, top + 8, tw, 22, 6, ThemePalette.ACCENT_SOFT);
            }
            Render2D.text(ctx, font, LABELS[i], tx + 10, top + 15,
                    selected ? ThemePalette.ACCENT : (hover ? ThemePalette.TEXT : ThemePalette.TEXT_DIM));
            if (headerClick && hover) {
                if (i != current) {
                    current = i;
                    tabFade = 0.0;
                }
                headerClick = false;
            }
            tx += tw + 4;
        }
        String key = com.kzclient.input.KeyNames.of(KzClient.keybinds().key(KeybindManager.Action.OPEN_GUI));
        Render2D.textRight(ctx, font, key, wx + ww - 14, top + 14, ThemePalette.TEXT_DIM);

        if (headerClick) {
            draggingWindow = true;
            dragOffX = mx - wx;
            dragOffY = my - wy;
        }
    }
}
