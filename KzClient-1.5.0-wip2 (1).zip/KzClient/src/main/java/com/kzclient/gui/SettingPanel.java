package com.kzclient.gui;

import com.kzclient.input.KeyNames;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ColorSetting;
import com.kzclient.module.setting.KeySetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.module.setting.Setting;
import com.kzclient.util.ColorUtil;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Dibuja y gestiona ajustes (slider, interruptor, selector, color, tecla). En modo "rich" (tarjetas de modulos)
 * los selectores de pocas opciones se muestran como pildoras y los colores abren un selector HSV; las alturas
 * son variables y se obtienen de {@link #height(Setting)}. En modo clasico todas las filas miden {@link #ROW}.
 */
public final class SettingPanel {
    public static final int ROW = 24;
    public static final int PICKER_H = 62;
    private static final int PILL_ROW = 38;

    private final boolean rich;
    private NumberSetting active;
    private int sliderX = 1;
    private int sliderW = 1;

    private ColorSetting dragColor;
    private int dragMode;
    private int dragX;
    private int dragY;
    private int dragW = 1;
    private int dragH = 1;

    private KeySetting listening;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public SettingPanel() {
        this(false);
    }

    public SettingPanel(boolean rich) {
        this.rich = rich;
    }

    public boolean capturing() {
        return listening != null;
    }

    /** Altura actual de un ajuste (incluye la animacion de apertura del selector de color). */
    public int height(Setting setting) {
        if (rich) {
            if (setting instanceof ColorSetting color) {
                return ROW + Math.round(PICKER_H * color.openProgress());
            }
            if (setting instanceof ModeSetting mode && mode.size() <= 4) {
                return PILL_ROW;
            }
        }
        return ROW;
    }

    /** Llamar una vez por fotograma antes de dibujar filas. */
    public void update(Frame f) {
        if (!f.leftDown) {
            active = null;
            dragColor = null;
        }
        if (active != null) {
            active.setFromRatio((f.mx - sliderX) / (double) sliderW);
        }
        if (dragColor != null) {
            double px = Math.max(0.0, Math.min(1.0, (f.mx - dragX) / (double) dragW));
            if (dragMode == 0) {
                double py = Math.max(0.0, Math.min(1.0, (f.my - dragY) / (double) dragH));
                dragColor.setHsv(dragColor.hue(), (float) px, (float) (1.0 - py));
            } else {
                dragColor.setHsv((float) (px * 359.999), Math.max(0.05f, dragColor.saturation()),
                        Math.max(0.05f, dragColor.brightness()));
            }
        }
        if (listening != null) {
            pollKey();
        }
    }

    private void pollKey() {
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            boolean down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            boolean pressed = down && !prevKeys[key];
            prevKeys[key] = down;
            if (!pressed || listening == null) {
                continue;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                listening.setListening(false);
            } else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
                listening.set(0);
                listening.setListening(false);
            } else {
                listening.set(key);
                listening.setListening(false);
            }
            listening = null;
        }
    }

    private void startListening(KeySetting key) {
        if (listening != null) {
            listening.setListening(false);
        }
        listening = key;
        key.setListening(true);
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            prevKeys[k] = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        }
    }

    /** Dibuja el ajuste y devuelve la altura usada. */
    public int draw(Frame f, Setting setting, int x, int y, int w, boolean inView) {
        if (setting instanceof NumberSetting number) {
            drawNumber(f, number, x, y, w, inView);
        } else if (setting instanceof BoolSetting bool) {
            float a = bool.anim().step(bool.get(), f.dt);
            Render2D.text(f.ctx, f.font, Frame.fit(f.font, bool.name(), w - 60), x + 10, y + 6, ThemePalette.TEXT_DIM);
            Render2D.toggle(f.ctx, x + w - 38, y + 3, a);
            if (f.click && inView && f.hover(x, y, w, 22)) {
                bool.toggle();
            }
        } else if (setting instanceof ModeSetting mode) {
            if (rich && mode.size() <= 4) {
                drawPills(f, mode, x, y, w, inView);
            } else {
                drawModeButton(f, mode, x, y, w, inView);
            }
        } else if (setting instanceof ColorSetting color) {
            drawColor(f, color, x, y, w, inView);
        } else if (setting instanceof KeySetting key) {
            drawKey(f, key, x, y, w, inView);
        }
        return height(setting);
    }

    private void drawNumber(Frame f, NumberSetting number, int x, int y, int w, boolean inView) {
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, number.name(), w - 60), x + 10, y + 1, ThemePalette.TEXT_DIM);
        Render2D.textRight(f.ctx, f.font, number.display(), x + w - 10, y + 1, ThemePalette.TEXT);
        int tx = x + 10;
        int ty = y + 14;
        int tw = w - 20;
        boolean hover = f.hover(tx - 2, ty - 5, tw + 4, 14);
        Render2D.roundedRect(f.ctx, tx, ty, tw, 4, 2, ThemePalette.SWITCH_OFF);
        int fill = (int) Math.round(tw * number.ratio());
        Render2D.roundedRect(f.ctx, tx, ty, Math.max(4, fill), 4, 2, ThemePalette.ACCENT_DARK);
        Render2D.roundedRect(f.ctx, tx, ty, Math.max(4, fill) / 2, 4, 2, ThemePalette.ACCENT);
        int knobX = Math.max(tx, Math.min(tx + tw - 6, tx + fill - 3));
        boolean grabbed = active == number;
        Render2D.roundedRect(f.ctx, knobX - (grabbed || hover ? 1 : 0), ty - 2 - (grabbed ? 1 : 0),
                6 + (grabbed || hover ? 2 : 0), 8 + (grabbed ? 2 : 0), 3, grabbed ? ThemePalette.ACCENT : 0xFFFFFFFF);
        if (f.click && inView && hover) {
            active = number;
            sliderX = tx;
            sliderW = tw;
            number.setFromRatio((f.mx - tx) / (double) tw);
        }
    }

    private void drawModeButton(Frame f, ModeSetting mode, int x, int y, int w, boolean inView) {
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, mode.name(), w / 2 - 12), x + 10, y + 6, ThemePalette.TEXT_DIM);
        int bw = Math.min(w / 2, 110);
        int bx = x + w - bw - 8;
        boolean hover = f.hover(bx, y + 2, bw, 18);
        Render2D.roundedPanel(f.ctx, bx, y + 2, bw, 18, 5, 0xFF0B090D, hover ? ThemePalette.ACCENT : ThemePalette.BORDER);
        Render2D.textCentered(f.ctx, f.font, "< " + Frame.fit(f.font, mode.get(), bw - 24) + " >", bx, y + 7, bw,
                hover ? ThemePalette.ACCENT : ThemePalette.TEXT);
        if (inView && hover) {
            if (f.click) {
                mode.cycle(1);
            } else if (f.rightClick) {
                mode.cycle(-1);
            }
        }
    }

    private void drawPills(Frame f, ModeSetting mode, int x, int y, int w, boolean inView) {
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, mode.name(), w - 20), x + 10, y + 3, ThemePalette.TEXT_DIM);
        int n = mode.size();
        int gap = 3;
        int total = w - 20;
        int pw = (total - gap * (n - 1)) / n;
        int py = y + 16;
        for (int i = 0; i < n; i++) {
            int px = x + 10 + i * (pw + gap);
            boolean selected = mode.index() == i;
            boolean hover = f.hover(px, py, pw, 16);
            int fill = selected ? ThemePalette.ACCENT_SOFT : (hover ? 0x14FFFFFF : 0xFF0B090D);
            int line = selected ? ThemePalette.ACCENT : (hover ? ThemePalette.ACCENT_BORDER : ThemePalette.BORDER);
            Render2D.roundedPanel(f.ctx, px, py, pw, 16, 5, fill, line);
            Render2D.textCentered(f.ctx, f.font, Frame.fit(f.font, mode.option(i), pw - 6), px, py + 4, pw,
                    selected ? ThemePalette.ACCENT : ThemePalette.TEXT_DIM);
            if (f.click && inView && hover) {
                mode.setIndex(i);
            }
        }
    }

    private void drawKey(Frame f, KeySetting key, int x, int y, int w, boolean inView) {
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, key.name(), w / 2 - 12), x + 10, y + 6, ThemePalette.TEXT_DIM);
        int bw = Math.min(w / 2, 96);
        int bx = x + w - bw - 8;
        boolean hover = f.hover(bx, y + 2, bw, 18);
        boolean wait = key.isListening();
        Render2D.roundedPanel(f.ctx, bx, y + 2, bw, 18, 5, wait ? ThemePalette.ACCENT_SOFT : 0xFF0B090D,
                wait || hover ? ThemePalette.ACCENT : ThemePalette.BORDER);
        Render2D.textCentered(f.ctx, f.font, wait ? "press a key..." : KeyNames.of(key.get()), bx, y + 7, bw,
                wait || hover ? ThemePalette.ACCENT : ThemePalette.TEXT);
        if (inView && hover) {
            if (f.click && !wait) {
                startListening(key);
            } else if (f.rightClick) {
                key.set(0);
                if (wait) {
                    key.setListening(false);
                    listening = null;
                }
            }
        }
    }

    private void drawColor(Frame f, ColorSetting color, int x, int y, int w, boolean inView) {
        float open = color.stepOpen(f.dt);
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, color.name(), w - 70), x + 10, y + 6, ThemePalette.TEXT_DIM);
        int sx = x + w - 44;
        boolean hover = f.hover(x, y, w, ROW - 2);
        Render2D.roundedPanel(f.ctx, sx, y + 3, 34, 15, 4, color.get(),
                hover || color.isOpen() ? ThemePalette.ACCENT : ThemePalette.BORDER);
        if (f.click && inView && hover) {
            color.toggleOpen();
        }
        if (open <= 0.01f) {
            return;
        }
        int pickerH = Math.round(PICKER_H * open);
        Render2D.scissor(f.ctx, x, y + ROW, w, pickerH);
        int px = x + 10;
        int pw = w - 20;
        int svY = y + ROW;
        int svH = 40;
        for (int cx = 0; cx < pw; cx += 2) {
            float s = cx / (float) pw;
            f.ctx.fillGradient(px + cx, svY, Math.min(px + pw, px + cx + 2), svY + svH,
                    ColorUtil.hsv(color.hue(), s, 1f), 0xFF000000);
        }
        int mx = px + Math.round(color.saturation() * (pw - 1));
        int my = svY + Math.round((1f - color.brightness()) * (svH - 1));
        Render2D.outline(f.ctx, mx - 2, my - 2, mx + 3, my + 3, 0xFFFFFFFF);
        int hueY = svY + svH + 4;
        for (int cx = 0; cx < pw; cx += 2) {
            f.ctx.fill(px + cx, hueY, Math.min(px + pw, px + cx + 2), hueY + 8, ColorUtil.hsv(360f * cx / pw, 1f, 1f));
        }
        int hx = px + Math.round(color.hue() / 360f * (pw - 1));
        f.ctx.fill(hx - 1, hueY - 1, hx + 1, hueY + 9, 0xFFFFFFFF);
        Render2D.textRight(f.ctx, f.font, String.format(Locale.ROOT, "#%06X", color.get() & 0xFFFFFF), x + w - 10,
                hueY + 10, ThemePalette.TEXT_DIM);
        Render2D.endScissor(f.ctx);
        if (f.click && inView && color.isOpen()) {
            if (f.hover(px, svY, pw, svH)) {
                dragColor = color;
                dragMode = 0;
                dragX = px;
                dragY = svY;
                dragW = pw;
                dragH = svH;
            } else if (f.hover(px, hueY, pw, 8)) {
                dragColor = color;
                dragMode = 1;
                dragX = px;
                dragY = hueY;
                dragW = pw;
                dragH = 8;
            }
        }
    }
}
