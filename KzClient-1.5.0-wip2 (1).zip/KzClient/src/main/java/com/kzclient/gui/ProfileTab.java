package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.auth.AccountService;
import com.kzclient.config.ClientSettings;
import com.kzclient.config.SavedAccount;
import com.kzclient.util.BrowserUtil;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import net.minecraft.client.MinecraftClient;

/**
 * Pestana PROFILE: visor de skin (arrastra para girar; con la funcion skinviewer gira 360 grados y sin ella
 * se limita a ~55), datos de la cuenta en tarjetas y Account Switcher (Microsoft, tokens cifrados).
 */
public final class ProfileTab implements GuiTab {
    private float yaw = 25f;
    private float pitch;
    private boolean dragging;
    private int lastMouseX;
    private int lastMouseY;
    private long idleSince = System.nanoTime();

    @Override
    public void draw(Frame f) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientSettings settings = KzClient.settings();
        int bx = f.x + 10;
        int by = f.y + 10;
        int bh = f.h - 20;

        // ---- visor de skin
        int sw = 150;
        boolean overViewer = f.hover(bx, by, sw, bh - 26);
        if (f.click && overViewer) {
            dragging = true;
            lastMouseX = f.mx;
            lastMouseY = f.my;
        }
        if (!f.leftDown) {
            dragging = false;
        }
        if (dragging) {
            yaw += (f.mx - lastMouseX) * 1.1f;
            pitch = Math.max(-25f, Math.min(25f, pitch - (f.my - lastMouseY) * 0.4f));
            lastMouseX = f.mx;
            lastMouseY = f.my;
            idleSince = System.nanoTime();
        } else if (System.nanoTime() - idleSince > 3_000_000_000L) {
            yaw += (float) (f.dt * 24.0); // giro lento cuando no lo tocas
        }
        Render2D.card(f.ctx, bx, by, sw, bh - 26, overViewer);
        Render2D.grid(f.ctx, bx + 1, by + 1, sw - 2, bh - 28, 12, ThemePalette.GRID);
        if (mc.player != null) {
            Render2D.scissor(f.ctx, bx + 1, by + 1, sw - 2, bh - 28);
            SkinViewer.draw(f.ctx, bx + 4, by + 4, bx + sw - 4, by + bh - 30, Math.max(30, bh / 4), yaw, pitch, mc.player);
            Render2D.endScissor(f.ctx);
        } else {
            Render2D.textCentered(f.ctx, f.font, "Join a world", bx, by + bh / 2 - 16, sw, ThemePalette.TEXT_DIM);
            Render2D.textCentered(f.ctx, f.font, "to see your skin", bx, by + bh / 2 - 4, sw, ThemePalette.TEXT_DIM);
        }
        if (f.button("RESET VIEW", bx, by + bh - 22, sw, 22)) {
            yaw = 25f;
            pitch = 0f;
        }
        Render2D.text(f.ctx, f.font, SkinViewer.is360() ? "Drag: 360" : "Drag: limited", bx + 6, by + 6,
                ThemePalette.TEXT_DIM);

        // ---- datos
        int rx = bx + sw + 14;
        int rw = f.x + f.w - 10 - rx;
        int y = by;
        String username = mc.getSession().getUsername();
        String uuid = mc.player != null ? mc.player.getUuidAsString() : "(join a world)";
        String since = settings.registeredAt == 0L ? "-" : DateTimeFormatter.ofPattern("yyyy-MM-dd")
                .format(Instant.ofEpochMilli(settings.registeredAt).atZone(ZoneId.systemDefault()));
        boolean linked = false;
        for (SavedAccount account : settings.accounts) {
            if (account.username().equals(username)) {
                linked = true;
                break;
            }
        }
        Render2D.sectionHeader(f.ctx, f.font, "PROFILE", rx, y, rw);
        Render2D.card(f.ctx, rx, y + 14, rw, 62, false);
        info(f, "USERNAME", username, ThemePalette.ACCENT, rx + 8, y + 20, rw - 16);
        info(f, "YOUR NAME", settings.displayName.isBlank() ? "-" : settings.displayName, ThemePalette.TEXT, rx + 8, y + 31, rw - 16);
        info(f, "UUID", uuid, ThemePalette.TEXT_DIM, rx + 8, y + 42, rw - 16);
        info(f, "LOCAL SINCE", since, ThemePalette.TEXT, rx + 8, y + 53, rw - 16);
        Render2D.chip(f.ctx, f.font, linked ? "LINKED" : "SESSION", rx + rw - f.font.getWidth(linked ? "LINKED" : "SESSION") - 16,
                y + 18, linked ? 0xFF55FF9A : ThemePalette.TEXT_DIM);

        // ---- switcher
        y += 86;
        Render2D.sectionHeader(f.ctx, f.font, "ACCOUNT SWITCHER", rx, y, rw);
        y += 15;
        int removeIndex = -1;
        int shown = Math.min(4, settings.accounts.size());
        boolean busy = AccountService.busy();
        for (int i = 0; i < shown; i++) {
            SavedAccount account = settings.accounts.get(i);
            boolean active = account.username().equals(username);
            Render2D.card(f.ctx, rx, y, rw, 20, active);
            Render2D.text(f.ctx, f.font, Frame.fit(f.font, account.username(), rw - 130), rx + 8, y + 6,
                    active ? ThemePalette.ACCENT : ThemePalette.TEXT);
            if (active) {
                Render2D.textRight(f.ctx, f.font, "ACTIVE", rx + rw - 84, y + 6, 0xFF55FF9A);
            }
            if (f.button("USE", rx + rw - 76, y + 2, 34, 16) && !busy && !active) {
                AccountService.switchTo(account);
            }
            if (f.button("X", rx + rw - 38, y + 2, 16, 16)) {
                removeIndex = i;
            }
            y += 24;
        }
        if (removeIndex >= 0) {
            AccountService.forget(settings.accounts.get(removeIndex));
            settings.accounts.remove(removeIndex);
            KzClient.config().save();
        }
        if (settings.accounts.isEmpty()) {
            Render2D.text(f.ctx, f.font, "No linked accounts yet.", rx, y + 4, ThemePalette.TEXT_DIM);
            y += 24;
        }
        y = Math.max(y, by + 86 + 15 + 4 * 24) + 6;

        switch (AccountService.state()) {
            case WAITING_CODE -> {
                Render2D.card(f.ctx, rx, y, rw, 44, true);
                Render2D.text(f.ctx, f.font, Frame.fit(f.font, AccountService.verificationUri(), rw - 16), rx + 8, y + 6,
                        ThemePalette.TEXT_DIM);
                Render2D.text(f.ctx, f.font, "CODE  " + AccountService.userCode(), rx + 8, y + 24, ThemePalette.ACCENT);
                int bwid = 66;
                if (f.button("OPEN", rx + rw - 3 * bwid - 14, y + 22, bwid, 16)) {
                    BrowserUtil.open(AccountService.verificationUri());
                }
                if (f.button("COPY", rx + rw - 2 * bwid - 8, y + 22, bwid, 16)) {
                    BrowserUtil.copy(AccountService.userCode());
                }
                if (f.button("CANCEL", rx + rw - bwid - 2, y + 22, bwid, 16)) {
                    AccountService.cancel();
                }
                y += 50;
            }
            case WORKING -> {
                Render2D.text(f.ctx, f.font, AccountService.message(), rx, y + 6, ThemePalette.TEXT_DIM);
                if (f.button("CANCEL", rx + rw - 72, y + 2, 70, 16)) {
                    AccountService.cancel();
                }
                y += 24;
            }
            default -> {
                if (f.button("ADD MICROSOFT ACCOUNT", rx, y, Math.min(rw, 190), 22)) {
                    AccountService.signIn(settings.msClientId);
                }
                y += 28;
            }
        }
        if (!AccountService.message().isEmpty() && !busy) {
            int color = AccountService.state() == AccountService.State.ERROR ? 0xFFFF6B6B : 0xFF55FF9A;
            Render2D.text(f.ctx, f.font, Frame.fit(f.font, AccountService.message(), rw), rx, y, color);
            y += 12;
        }
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, "Official Microsoft sign-in. Tokens are stored encrypted.", rw), rx,
                y, ThemePalette.TEXT_DIM);
    }

    private static void info(Frame f, String label, String value, int color, int x, int y, int w) {
        Render2D.text(f.ctx, f.font, label, x, y, ThemePalette.TEXT_DIM);
        int labelW = 84;
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, value, Math.max(20, w - labelW - 50)), x + labelW, y, color);
    }
}
