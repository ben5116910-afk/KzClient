package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.config.ClientSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Bienvenida: nombre local ("YOUR NAME") y eleccion de layout (Panel o Dropdown). */
public final class OnboardingScreen extends Screen {
    private TextFieldWidget nameField;
    private String nameKeep;
    private boolean panelChoice = true;
    private boolean prevLeft;
    private int px;
    private int py;
    private int pw;
    private int ph;

    public OnboardingScreen() {
        super(Text.literal("KzClient"));
    }

    @Override
    protected void init() {
        ClientSettings settings = KzClient.settings();
        if (nameKeep == null) {
            nameKeep = settings.displayName;
            panelChoice = settings.panelLayout;
        } else if (nameField != null) {
            nameKeep = nameField.getText();
        }
        pw = Math.min(440, width - 16);
        ph = Math.min(320, height - 16);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        nameField = addDrawableChild(new TextFieldWidget(MinecraftClient.getInstance().textRenderer,
                px + 30, py + 142, pw - 60, 20, Text.literal("Your name")));
        nameField.setPlaceholder(Text.literal("Type your name"));
        nameField.setMaxLength(24);
        nameField.setText(nameKeep);
        setInitialFocus(nameField);
        prevLeft = GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer font = mc.textRenderer;
        boolean leftDown = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)
                == GLFW.GLFW_PRESS;
        boolean click = leftDown && !prevLeft;
        prevLeft = leftDown;

        ctx.fill(0, 0, width, height, 0xCC000000);
        Render2D.roundedRect(ctx, px - 1, py - 1, pw + 2, ph + 2, 9, ThemePalette.ACCENT_SOFT);
        Render2D.roundedPanel(ctx, px, py, pw, ph, 8, ThemePalette.BACKGROUND, ThemePalette.BORDER);
        Render2D.grid(ctx, px + 2, py + 2, pw - 4, ph - 4, 16, ThemePalette.GRID);

        Render2D.watermarkKz(ctx, px + pw / 2, py + 52, 7, ThemePalette.ACCENT);
        Render2D.textCentered(ctx, font, "KZCLIENT", px, py + 90, pw, ThemePalette.TEXT);
        Render2D.textCentered(ctx, font, "Welcome. Set up your client.", px, py + 104, pw, ThemePalette.TEXT_DIM);

        Render2D.text(ctx, font, "YOUR NAME", px + 30, py + 128, ThemePalette.TEXT_DIM);
        nameField.render(ctx, mouseX, mouseY, delta);

        Render2D.text(ctx, font, "LAYOUT", px + 30, py + 176, ThemePalette.TEXT_DIM);
        int cardW = (pw - 60 - 8) / 2;
        for (int i = 0; i < 2; i++) {
            boolean panel = i == 0;
            int cx = px + 30 + i * (cardW + 8);
            int cy = py + 190;
            boolean hover = Render2D.inside(mouseX, mouseY, cx, cy, cardW, 62);
            boolean selected = panelChoice == panel;
            Render2D.roundedPanel(ctx, cx, cy, cardW, 62, 6, selected ? 0xFF2A1B24 : ThemePalette.CARD,
                    selected ? ThemePalette.ACCENT : (hover ? ThemePalette.ACCENT_BORDER : ThemePalette.BORDER));
            drawMiniLayout(ctx, cx + 8, cy + 8, cardW - 16, 30, panel, selected);
            Render2D.textCentered(ctx, font, panel ? "PANEL" : "DROPDOWN", cx, cy + 46, cardW,
                    selected ? ThemePalette.ACCENT : ThemePalette.TEXT);
            if (click && hover) {
                panelChoice = panel;
            }
        }

        int bw = 140;
        int bx = px + (pw - bw) / 2;
        int by = py + ph - 38;
        boolean over = Render2D.inside(mouseX, mouseY, bx, by, bw, 26);
        Render2D.roundedPanel(ctx, bx, by, bw, 26, 7, over ? ThemePalette.ACCENT : ThemePalette.ACCENT_SOFT,
                ThemePalette.ACCENT);
        Render2D.textCentered(ctx, font, "CONTINUE", bx, by + 9, bw, over ? ThemePalette.BACKGROUND : ThemePalette.ACCENT);
        if (click && over) {
            finish();
        }
    }

    private void drawMiniLayout(DrawContext ctx, int x, int y, int w, int h, boolean panel, boolean selected) {
        int color = selected ? ThemePalette.ACCENT_BORDER : 0xFF3A3340;
        if (panel) {
            Render2D.roundedRect(ctx, x, y, w / 4, h, 3, color);
            Render2D.roundedRect(ctx, x + w / 4 + 4, y, (w * 3 / 4 - 4) / 2 - 2, h, 3, color);
            Render2D.roundedRect(ctx, x + w / 4 + 4 + (w * 3 / 4 - 4) / 2 + 2, y, (w * 3 / 4 - 4) / 2 - 2, h, 3, color);
        } else {
            int col = (w - 8) / 3;
            for (int i = 0; i < 3; i++) {
                Render2D.roundedRect(ctx, x + i * (col + 4), y, col, 6, 2, color);
                Render2D.roundedRect(ctx, x + i * (col + 4), y + 9, col, 5, 2, 0xFF2A2430);
                Render2D.roundedRect(ctx, x + i * (col + 4), y + 17, col, 5, 2, 0xFF2A2430);
            }
        }
    }

    private void finish() {
        ClientSettings settings = KzClient.settings();
        settings.displayName = nameField.getText().trim();
        settings.panelLayout = panelChoice;
        settings.onboarded = true;
        if (settings.registeredAt == 0L) {
            settings.registeredAt = System.currentTimeMillis();
        }
        KzClient.config().save();
        MinecraftClient.getInstance().setScreen(new ClickGuiScreen(ClickGuiScreen.TAB_MODULES));
    }
}
