package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.hud.HudManager;
import com.kzclient.hud.HudWidget;
import com.kzclient.module.modules.HudQuickEditor;
import com.kzclient.module.setting.Setting;
import com.kzclient.util.ColorUtil;
import java.util.List;

/**
 * Editor visual del HUD: la vista previa "YOUR SCREEN" dibuja los widgets reales sobre una escena de
 * Minecraft; arrastra para mover, y el panel lateral edita escala, tamano, color, opacidad, estilo y alineacion.
 */
public final class HudTab implements GuiTab {
    private static final int RIGHT_W = 196;

    private final SettingPanel panel = new SettingPanel();
    private HudWidget dragging;
    private double grabX;
    private double grabY;
    private int selected;
    private double settingsScroll;
    private int settingsX;
    private int settingsY;
    private int settingsH;

    @Override
    public boolean scrolled(double mouseX, double mouseY, double amount) {
        if (Render2D.inside(mouseX, mouseY, settingsX, settingsY, RIGHT_W, settingsH)) {
            HudWidget widget = KzClient.hud().widgets().get(selected);
            int max = Math.max(0, widget.settings().size() * SettingPanel.ROW - settingsH);
            settingsScroll = Math.max(0, Math.min(max, settingsScroll - amount * 24.0));
            return true;
        }
        return false;
    }

    private void drawWorld(Frame f, int px, int py, int pw, int ph, double s) {
        int ix = px + 1;
        int iy = py + 1;
        int iw = pw - 2;
        int ih = ph - 2;
        int horizon = iy + (int) (ih * 0.62);
        f.ctx.fillGradient(ix, iy, ix + iw, horizon, 0xFF2F5C93, 0xFFA9D0EE);
        f.ctx.fillGradient(ix, horizon, ix + iw, iy + ih, 0xFF5E9440, 0xFF2F5A22);
        int sun = Math.max(6, (int) (28 * s));
        f.ctx.fill(ix + iw * 3 / 4, iy + ih / 8, ix + iw * 3 / 4 + sun, iy + ih / 8 + sun, 0xFFFFF3B0);
        int block = Math.max(4, (int) (16 * s));
        for (int i = 0; i < 6; i++) {
            int bx = ix + (i * 37 + 11) % Math.max(1, iw - block);
            int tall = (1 + (i % 3)) * block;
            f.ctx.fill(bx, horizon - tall, bx + block, horizon, i % 2 == 0 ? 0xFF3B2A1A : 0xFF264F1C);
            f.ctx.fill(bx - block / 2, horizon - tall - block, bx + block + block / 2, horizon - tall,
                    0xFF2E6B23);
        }
        for (int gx = ix; gx < ix + iw; gx += block * 2) {
            f.ctx.fill(gx, horizon, gx + 1, iy + ih, 0x22000000);
        }
        int cx = ix + iw / 2;
        int cy = iy + ih / 2;
        f.ctx.fill(cx - 4, cy, cx + 5, cy + 1, 0xCCFFFFFF);
        f.ctx.fill(cx, cy - 4, cx + 1, cy + 5, 0xCCFFFFFF);
        int hotbarW = (int) Math.round(182 * s);
        int hotbarH = Math.max(3, (int) Math.round(22 * s));
        int hx = ix + (iw - hotbarW) / 2;
        int hy = iy + ih - hotbarH - 2;
        f.ctx.fill(hx, hy, hx + hotbarW, hy + hotbarH, 0x99000000);
        for (int i = 0; i < 9; i++) {
            int sx = hx + (int) Math.round(i * 20 * s);
            f.ctx.fill(sx, hy, sx + 1, hy + hotbarH, 0x55FFFFFF);
        }
        int heartSize = Math.max(2, (int) (8 * s));
        for (int i = 0; i < 10; i++) {
            int hxx = hx + (int) Math.round(i * 8 * s);
            f.ctx.fill(hxx, hy - heartSize - 2, hxx + heartSize, hy - 2, 0xFFE0303A);
        }
        f.ctx.fill(ix, iy, ix + iw, iy + ih, 0x220D0812);
    }

    @Override
    public void draw(Frame f) {
        HudManager hud = KzClient.hud();
        HudQuickEditor quick = KzClient.modules().get(HudQuickEditor.class);
        List<HudWidget> widgets = hud.widgets();
        selected = Math.floorMod(selected, widgets.size());
        panel.update(f);

        int bx = f.x + 10;
        int by = f.y + 10;
        int bw = f.w - 20;
        int bh = f.h - 20;
        int areaW = bw - RIGHT_W - 12;

        double aspect = (double) f.screenH / (double) f.screenW;
        int pw = areaW;
        int ph = (int) Math.round(pw * aspect);
        if (ph > bh - 16) {
            ph = bh - 16;
            pw = (int) Math.round(ph / aspect);
        }
        int px = bx;
        int py = by + 14;
        double s = pw / (double) f.screenW;

        if (!f.leftDown) {
            dragging = null;
        }
        if (dragging != null && f.leftDown) {
            int nx = quick.snap((int) Math.round((f.mx - grabX - px) / s));
            int ny = quick.snap((int) Math.round((f.my - grabY - py) / s));
            nx = Math.max(0, Math.min(Math.max(0, f.screenW - dragging.width()), nx));
            ny = Math.max(0, Math.min(Math.max(0, f.screenH - dragging.height()), ny));
            dragging.setPosition(nx, ny);
        }

        Render2D.text(f.ctx, f.font, "YOUR SCREEN", bx, by, ThemePalette.TEXT_DIM);
        Render2D.roundedPanel(f.ctx, px, py, pw, ph, 6, 0xFF0B090D, ThemePalette.BORDER);
        drawWorld(f, px, py, pw, ph, s);

        // widgets reales, escalados a la vista previa
        Render2D.scissor(f.ctx, px + 1, py + 1, pw - 2, ph - 2);
        for (HudWidget widget : widgets) {
            if (!widget.isEnabled()) {
                continue;
            }
            int wx = Math.max(0, Math.min(Math.max(0, f.screenW - widget.width()), widget.x()));
            int wy = Math.max(0, Math.min(Math.max(0, f.screenH - widget.height()), widget.y()));
            f.ctx.getMatrices().pushMatrix();
            f.ctx.getMatrices().translate((float) px, (float) py);
            f.ctx.getMatrices().scale((float) s, (float) s);
            widget.render(f.ctx, wx, wy);
            f.ctx.getMatrices().popMatrix();
        }
        // cajas de seleccion y arrastre
        for (int i = 0; i < widgets.size(); i++) {
            HudWidget widget = widgets.get(i);
            int cw = Math.max(10, (int) Math.round(widget.width() * s));
            int ch = Math.max(8, (int) Math.round(widget.height() * s));
            int wx = Math.max(0, Math.min(Math.max(0, f.screenW - widget.width()), widget.x()));
            int wy = Math.max(0, Math.min(Math.max(0, f.screenH - widget.height()), widget.y()));
            int rx = px + (int) Math.round(wx * s);
            int ry = py + (int) Math.round(wy * s);
            boolean hover = f.hover(rx, ry, cw, ch);
            boolean isSel = i == selected;
            if (isSel || hover || !widget.isEnabled()) {
                int color = isSel ? ThemePalette.ACCENT : (hover ? ThemePalette.ACCENT_BORDER : 0x66FFFFFF);
                Render2D.outline(f.ctx, rx, ry, rx + cw, ry + ch, color);
                if (isSel || hover || !widget.isEnabled()) {
                    Render2D.text(f.ctx, f.font, widget.shortName() + (widget.isEnabled() ? "" : " (off)"), rx + 2, ry - 9,
                            color);
                }
            }
            if (f.click && dragging == null && hover && f.hover(px, py, pw, ph)) {
                dragging = widget;
                selected = i;
                settingsScroll = 0;
                grabX = f.mx - rx;
                grabY = f.my - ry;
            }
        }
        Render2D.endScissor(f.ctx);
        Render2D.text(f.ctx, f.font, "Drag elements | snapping: HudQuickEditor", px, py + ph + 3, ThemePalette.TEXT_DIM);

        // ---- panel lateral
        int lx = bx + areaW + 12;
        HudWidget current = widgets.get(selected);
        Render2D.text(f.ctx, f.font, "ELEMENT", lx, by, ThemePalette.TEXT_DIM);
        int y = by + 14;
        if (f.button("<", lx, y, 22, 20)) {
            selected = Math.floorMod(selected - 1, widgets.size());
            settingsScroll = 0;
        }
        Render2D.roundedPanel(f.ctx, lx + 26, y, RIGHT_W - 52, 20, 5, ThemePalette.CARD, ThemePalette.ACCENT_BORDER);
        Render2D.textCentered(f.ctx, f.font, current.name(), lx + 26, y + 6, RIGHT_W - 52, ThemePalette.ACCENT);
        if (f.button(">", lx + RIGHT_W - 22, y, 22, 20)) {
            selected = Math.floorMod(selected + 1, widgets.size());
            settingsScroll = 0;
        }
        y += 26;
        float a = current.anim().step(current.isEnabled(), f.dt);
        Render2D.roundedPanel(f.ctx, lx, y, RIGHT_W, 24, 6, ThemePalette.CARD,
                ColorUtil.lerp(ThemePalette.BORDER, ThemePalette.ACCENT_BORDER, a));
        Render2D.text(f.ctx, f.font, "Enabled", lx + 10, y + 8, ThemePalette.TEXT);
        Render2D.toggle(f.ctx, lx + RIGHT_W - 38, y + 5, a);
        if (f.clicked(lx, y, RIGHT_W, 24)) {
            current.setEnabled(!current.isEnabled());
        }
        y += 30;

        settingsX = lx;
        settingsY = y;
        settingsH = Math.max(SettingPanel.ROW, by + bh - 54 - y - 4);
        int total = current.settings().size() * SettingPanel.ROW;
        settingsScroll = Math.max(0, Math.min(Math.max(0, total - settingsH), settingsScroll));
        boolean inView = f.hover(settingsX, settingsY, RIGHT_W, settingsH);
        Render2D.scissor(f.ctx, settingsX, settingsY, RIGHT_W, settingsH);
        int ry = settingsY - (int) Math.round(settingsScroll);
        for (Setting setting : current.settings()) {
            panel.draw(f, setting, lx, ry, RIGHT_W, inView);
            ry += SettingPanel.ROW;
        }
        Render2D.endScissor(f.ctx);
        if (total > settingsH) {
            int thumbH = Math.max(14, settingsH * settingsH / total);
            int thumbY = settingsY + (int) ((settingsH - thumbH) * (settingsScroll / (total - settingsH)));
            Render2D.roundedRect(f.ctx, lx + RIGHT_W - 3, thumbY, 2, thumbH, 1, ThemePalette.ACCENT_BORDER);
        }

        int half = (RIGHT_W - 6) / 2;
        if (f.button("ALL ON", lx, by + bh - 50, half, 22)) {
            for (HudWidget w : widgets) {
                w.setEnabled(true);
            }
        }
        if (f.button("ALL OFF", lx + half + 6, by + bh - 50, half, 22)) {
            for (HudWidget w : widgets) {
                w.setEnabled(false);
            }
        }
        if (f.button("RESET ELEMENT", lx, by + bh - 24, half, 22)) {
            current.resetAll();
        }
        if (f.button("RESET ALL POS", lx + half + 6, by + bh - 24, half, 22)) {
            hud.resetPositions();
        }
    }
}
