package com.kzclient.gui;

import com.kzclient.util.ColorUtil;

/** Paleta de KzClient (ARGB). El acento es configurable desde SETTINGS. */
public final class ThemePalette {
    public static final int BACKGROUND = 0xFF0D0812;
    public static final int SECONDARY = 0xFF17101F;
    public static final int HEADER = 0xFF17101F;
    public static final int CARD = 0xF0211329;
    public static final int BORDER = 0xFF39213F;
    public static final int TEXT = 0xFFF5EDF3;
    public static final int TEXT_DIM = 0xFF9C91A0;
    public static final int SWITCH_OFF = 0xFF3A3340;
    public static final int DIM = 0x99000000;
    /** Rosa secundario #FF55B4. */
    public static final int ACCENT_2 = 0xFFFF55B4;
    public static final int DEFAULT_ACCENT = 0xFFFF278F;

    public static int ACCENT = DEFAULT_ACCENT;
    public static int ACCENT_DARK = 0xFFD91F79;
    public static int ACCENT_SOFT = 0x33FF278F;
    public static int ACCENT_BORDER = 0xB4FF278F;
    public static int GRID = 0x12FF278F;
    public static int WATERMARK = 0x16FF278F;

    private ThemePalette() {
    }

    public static void setAccent(int argb) {
        int rgb = argb & 0x00FFFFFF;
        ACCENT = 0xFF000000 | rgb;
        ACCENT_DARK = ColorUtil.lerp(ACCENT, 0xFF000000, 0.15f);
        ACCENT_SOFT = 0x33000000 | rgb;
        ACCENT_BORDER = 0xB4000000 | rgb;
        GRID = 0x12000000 | rgb;
        WATERMARK = 0x16000000 | rgb;
    }
}
