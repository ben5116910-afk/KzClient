package com.kzclient.gui;

public interface GuiTab {
    /** Crea los widgets de la pestana (se llama en cada init() de la pantalla). */
    default void init(ClickGuiScreen owner) {
    }

    void draw(Frame f);

    /** Se llama cada fotograma en las pestanas que no estan visibles. */
    default void hide() {
    }

    default boolean scrolled(double mouseX, double mouseY, double amount) {
        return false;
    }

    /** true mientras la pestana espera una tecla (no se debe cerrar el panel). */
    default boolean capturing() {
        return false;
    }
}
