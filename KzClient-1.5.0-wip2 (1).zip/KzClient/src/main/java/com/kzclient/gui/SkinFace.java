package com.kzclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;

/**
 * Unico punto del proyecto que dibuja la cara de un jugador. Concentra la llamada a PlayerSkinDrawer
 * (API de 1.21.x sin verificar por compilacion en este entorno) para que, si la firma cambia, solo haya
 * que tocar este archivo. Sin skin disponible (jugador offline) dibuja un avatar con la inicial.
 */
public final class SkinFace {
    private SkinFace() {
    }

    public static void draw(DrawContext ctx, TextRenderer font, PlayerListEntry entry, String name, int x, int y, int size) {
        if (entry != null) {
            PlayerSkinDrawer.draw(ctx, entry.getSkinTextures(), x, y, size);
            return;
        }
        Render2D.roundedPanel(ctx, x, y, size, size, 4, 0xFF2A1A33, ThemePalette.BORDER);
        String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        Render2D.textCentered(ctx, font, initial, x, y + (size - 8) / 2 + 1, size, ThemePalette.TEXT_DIM);
    }
}
