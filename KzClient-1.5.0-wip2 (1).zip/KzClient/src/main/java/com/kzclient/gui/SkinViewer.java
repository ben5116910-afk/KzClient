package com.kzclient.gui;

import com.kzclient.KzClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Visor del jugador. Si la funcion "skinviewer" esta compilada ofrece giro libre de 360 grados; si no,
 * recurre a InventoryScreen.drawEntity con el raton simulado (limitado a unos +-55 grados).
 */
public final class SkinViewer {
    /** Implementada por la funcion opcional skinviewer (src/features/skinviewer). */
    public interface Backend {
        void draw(DrawContext ctx, int x1, int y1, int x2, int y2, int size, float yawDegrees, float pitchDegrees,
                  ClientPlayerEntity player);
    }

    private static Backend backend;

    private SkinViewer() {
    }

    public static void setBackend(Backend value) {
        backend = value;
    }

    public static boolean is360() {
        return backend != null;
    }

    public static void draw(DrawContext ctx, int x1, int y1, int x2, int y2, int size, float yawDegrees,
                            float pitchDegrees, ClientPlayerEntity player) {
        if (backend != null) {
            try {
                backend.draw(ctx, x1, y1, x2, y2, size, yawDegrees, pitchDegrees, player);
                return;
            } catch (RuntimeException | LinkageError ex) {
                KzClient.LOGGER.error("El visor 360 fallo; se usa el visor basico", ex);
                backend = null;
            }
        }
        double sweep = MathHelper.clamp(MathHelper.wrapDegrees(yawDegrees), -55f, 55f);
        float mouseX = (float) ((x1 + x2) / 2.0 - 40.0 * Math.tan(Math.toRadians(sweep) * 0.9 / 0.7));
        float mouseY = (float) ((y1 + y2) / 2.0 - 40 + 40.0 * Math.tan(Math.toRadians(pitchDegrees) / 20.0));
        InventoryScreen.drawEntity(ctx, x1, y1, x2, y2, size, 0.0625f, mouseX, mouseY, player);
    }
}
