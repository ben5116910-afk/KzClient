package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.config.ClientSettings;
import com.kzclient.config.PlayerLists;
import com.kzclient.hud.HudManager;
import com.kzclient.input.KeyNames;
import com.kzclient.input.KeybindManager;
import com.kzclient.module.modules.Animations;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Pestana SETTINGS (con scroll): nombre, layout, apariencia, teclas, listas, integraciones y perfiles. */
public final class SettingsTab implements GuiTab {
    private TextFieldWidget nameField;
    private TextFieldWidget listField;
    private TextFieldWidget msField;
    private TextFieldWidget profileField;
    private String nameText;
    private String listText = "";
    private String msText;
    private String profileText = "";
    private String info = "";

    private final SettingPanel panel = new SettingPanel();
    private NumberSetting uiScale;
    private NumberSetting opacity;
    private NumberSetting accentHue;
    private BoolSetting customAccent;
    private BoolSetting notifications;
    private BoolSetting autosave;
    private KeybindManager.Action listening;

    private double scroll;
    private double scrollTarget;
    private int contentHeight = 600;
    private int viewX;
    private int viewY;
    private int viewW;
    private int viewH;

    private TextFieldWidget[] fields() {
        return new TextFieldWidget[] {nameField, listField, msField, profileField};
    }

    private TextFieldWidget field(String placeholder, int max, String text) {
        TextFieldWidget field = new TextFieldWidget(MinecraftClient.getInstance().textRenderer, 0, 0, 100, 18,
                Text.literal(placeholder));
        field.setPlaceholder(Text.literal(placeholder));
        field.setMaxLength(max);
        field.setText(text);
        return field;
    }

    private void sync() {
        ClientSettings s = KzClient.settings();
        uiScale = new NumberSetting("UI scale", 0.7, 1.4, 0.05, s.uiScale);
        opacity = new NumberSetting("Panel opacity %", 40, 100, 5, s.opacity);
        accentHue = new NumberSetting("Accent hue", 0, 360, 1, s.accentHue);
        customAccent = new BoolSetting("Custom accent color", s.customAccent);
        notifications = new BoolSetting("Notifications", s.notifications);
        autosave = new BoolSetting("Autosave", s.autosave);
    }

    @Override
    public void init(ClickGuiScreen owner) {
        ClientSettings s = KzClient.settings();
        if (nameText == null) {
            nameText = s.displayName;
            msText = s.msClientId;
        }
        nameField = owner.registerField(field("Your name", 24, nameText));
        listField = owner.registerField(field("Player name", 16, listText));
        msField = owner.registerField(field("Microsoft app (client) ID", 64, msText));
        profileField = owner.registerField(field("Profile name", 24, profileText));
        sync();
        hide();
    }

    @Override
    public void hide() {
        if (nameField != null) {
            nameText = nameField.getText();
            listText = listField.getText();
            msText = msField.getText();
            profileText = profileField.getText();
            for (TextFieldWidget field : fields()) {
                field.setVisible(false);
                field.setFocused(false);
            }
        }
        listening = null;
    }

    @Override
    public boolean capturing() {
        return listening != null;
    }

    @Override
    public boolean scrolled(double mouseX, double mouseY, double amount) {
        if (Render2D.inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) {
            scrollTarget = Math.max(0, Math.min(Math.max(0, contentHeight - viewH), scrollTarget - amount * 30.0));
            return true;
        }
        return false;
    }

    private void pollKeyCapture() {
        if (listening == null) {
            return;
        }
        for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
            if (!KeybindManager.isDown(key)) {
                continue;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                listening = null;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
                KzClient.keybinds().set(listening, GLFW.GLFW_KEY_UNKNOWN);
                listening = null;
            } else {
                KzClient.keybinds().set(listening, key);
                listening = null;
            }
            return;
        }
    }

    private static void place(TextFieldWidget field, int x, int y, int w, int top, int bottom) {
        field.setX(x);
        field.setY(y);
        field.setWidth(w);
        field.setVisible(y >= top && y + 18 <= bottom);
        if (!field.visible) {
            field.setFocused(false);
        }
    }

    private void header(Frame f, String text, int x, int y) {
        Render2D.sectionHeader(f.ctx, f.font, text, x, y, Math.min(440, viewW - 10));
    }

    @Override
    public void draw(Frame f) {
        ClientSettings settings = KzClient.settings();
        HudManager hud = KzClient.hud();
        pollKeyCapture();

        viewX = f.x + 10;
        viewY = f.y + 10;
        viewW = f.w - 20;
        viewH = f.h - 20;
        scrollTarget = Math.max(0, Math.min(Math.max(0, contentHeight - viewH), scrollTarget));
        scroll += (scrollTarget - scroll) * (1.0 - Math.exp(-f.dt * 14.0));
        if (Math.abs(scrollTarget - scroll) < 0.05) {
            scroll = scrollTarget;
        }
        boolean inView = f.hover(viewX, viewY, viewW, viewH);
        boolean realClick = f.click;
        f.click = realClick && inView;
        panel.update(f);

        int w = Math.min(440, viewW - 10);
        int x = viewX;
        int y = viewY - (int) Math.round(scroll);
        int top = viewY;
        int bottom = viewY + viewH;
        Render2D.scissor(f.ctx, viewX, viewY, viewW, viewH);

        // ---- identidad
        header(f, "IDENTITY", x, y);
        y += 14;
        place(nameField, x, y, w - 90, top, bottom);
        nameField.render(f.ctx, f.mx, f.my, 0f);
        if (f.button("SAVE NAME", x + w - 84, y - 1, 84, 20)) {
            settings.displayName = nameField.getText().trim();
            KzClient.config().save();
        }
        y += 28;

        // ---- layout y apariencia
        header(f, "INTERFACE", x, y);
        y += 14;
        int half = (w - 6) / 2;
        for (int i = 0; i < 2; i++) {
            boolean isPanel = i == 0;
            boolean selected = settings.panelLayout == isPanel;
            int cx = x + i * (half + 6);
            boolean hover = f.hover(cx, y, half, 22);
            Render2D.roundedPanel(f.ctx, cx, y, half, 22, 6, selected ? ThemePalette.ACCENT_SOFT : ThemePalette.CARD,
                    selected ? ThemePalette.ACCENT : (hover ? ThemePalette.ACCENT_BORDER : ThemePalette.BORDER));
            Render2D.textCentered(f.ctx, f.font, isPanel ? "PANEL" : "DROPDOWN", cx, y + 7, half,
                    selected ? ThemePalette.ACCENT : ThemePalette.TEXT);
            if (f.click && hover) {
                settings.panelLayout = isPanel;
            }
        }
        y += 28;
        y += panel.draw(f, uiScale, x, y, w, inView);
        y += panel.draw(f, opacity, x, y, w, inView);
        y += panel.draw(f, customAccent, x, y, w, inView);
        if (customAccent.get()) {
            y += panel.draw(f, accentHue, x, y, w, inView);
        }
        y += panel.draw(f, notifications, x, y, w, inView);
        y += panel.draw(f, autosave, x, y, w, inView);
        settings.uiScale = uiScale.getFloat();
        settings.opacity = opacity.getInt();
        settings.accentHue = accentHue.getInt();
        boolean accentChanged = settings.customAccent != customAccent.get();
        settings.customAccent = customAccent.get();
        settings.notifications = notifications.get();
        settings.autosave = autosave.get();
        if (accentChanged || settings.customAccent) {
            KzClient.applyTheme();
        }
        Animations animations = KzClient.modules().get(Animations.class);
        float a = animations.anim().step(animations.isEnabled(), f.dt);
        Render2D.text(f.ctx, f.font, "Animations (open/close, tab fade)", x + 10, y + 6, ThemePalette.TEXT_DIM);
        Render2D.toggle(f.ctx, x + w - 38, y + 3, a);
        if (f.clicked(x, y, w, 22)) {
            animations.toggle();
        }
        y += SettingPanel.ROW;
        float ha = hud.isEnabled() ? 1f : 0f;
        Render2D.text(f.ctx, f.font, "HUD overlay", x + 10, y + 6, ThemePalette.TEXT_DIM);
        Render2D.toggle(f.ctx, x + w - 38, y + 3, ha);
        if (f.clicked(x, y, w, 22)) {
            hud.setEnabled(!hud.isEnabled());
        }
        y += SettingPanel.ROW + 8;

        // ---- teclas
        header(f, "KEYBINDS", x, y);
        y += 14;
        for (KeybindManager.Action action : KeybindManager.Action.values()) {
            Render2D.roundedPanel(f.ctx, x, y, w, 20, 5, ThemePalette.CARD, ThemePalette.BORDER);
            Render2D.text(f.ctx, f.font, action.label(), x + 8, y + 6, ThemePalette.TEXT);
            boolean wait = listening == action;
            String label = wait ? "PRESS A KEY..." : KeyNames.of(KzClient.keybinds().key(action));
            int kw = 100;
            boolean hover = f.hover(x + w - kw - 4, y + 2, kw, 16);
            Render2D.roundedPanel(f.ctx, x + w - kw - 4, y + 2, kw, 16, 4, wait ? ThemePalette.ACCENT_SOFT : 0xFF0B090D,
                    wait || hover ? ThemePalette.ACCENT : ThemePalette.BORDER);
            Render2D.textCentered(f.ctx, f.font, label, x + w - kw - 4, y + 6, kw,
                    wait ? ThemePalette.ACCENT : ThemePalette.TEXT);
            if (f.click && hover) {
                listening = action;
            }
            y += 24;
        }
        Render2D.text(f.ctx, f.font, "Click a key box, then press the key (Delete = unbind, Esc = cancel)", x, y,
                ThemePalette.TEXT_DIM);
        y += 12;
        if (f.button("PANEL KEY: INSERT", x, y, half, 20)) {
            KzClient.keybinds().set(KeybindManager.Action.OPEN_GUI, GLFW.GLFW_KEY_INSERT);
        }
        if (f.button("PANEL KEY: RSHIFT", x + half + 6, y, half, 20)) {
            KzClient.keybinds().set(KeybindManager.Action.OPEN_GUI, GLFW.GLFW_KEY_RIGHT_SHIFT);
        }
        y += 30;

        // ---- listas
        header(f, "STAFF LIST (friends: FRIENDS tab)", x, y);
        y += 14;
        place(listField, x, y, w - 96, top, bottom);
        listField.render(f.ctx, f.mx, f.my, 0f);
        if (f.button("+ STAFF", x + w - 90, y - 1, 90, 20)) {
            if (KzClient.lists().add(PlayerLists.Kind.STAFF, listField.getText())) {
                listField.setText("");
            }
        }
        y += 26;
        for (PlayerLists.Kind kind : new PlayerLists.Kind[] {PlayerLists.Kind.STAFF}) {
            List<String> names = KzClient.lists().list(kind);
            for (String name : names) {
                Render2D.roundedPanel(f.ctx, x, y, w, 18, 5, ThemePalette.CARD, ThemePalette.BORDER);
                Render2D.text(f.ctx, f.font, name, x + 8, y + 5, ThemePalette.TEXT);
                Render2D.textRight(f.ctx, f.font, kind.name(), x + w - 30, y + 5,
                        kind == PlayerLists.Kind.STAFF ? ThemePalette.ACCENT : 0xFF55FF9A);
                if (f.button("X", x + w - 22, y + 1, 16, 16)) {
                    KzClient.lists().remove(kind, name);
                    break;
                }
                y += 21;
            }
        }
        y += 8;

        // ---- integraciones
        header(f, "ACCOUNT (Microsoft)", x, y);
        y += 14;
        place(msField, x, y, w - 90, top, bottom);
        msField.render(f.ctx, f.mx, f.my, 0f);
        if (f.button("SAVE ID", x + w - 84, y - 1, 84, 20)) {
            settings.msClientId = msField.getText().trim();
            KzClient.config().save();
        }
        y += 24;
        Render2D.text(f.ctx, f.font, "Microsoft sign-in needs your own Azure app approved by Mojang (README).", x, y,
                ThemePalette.TEXT_DIM);
        y += 18;
        y += 4;

        // ---- perfiles
        header(f, "CONFIG PROFILES", x, y);
        y += 14;
        place(profileField, x, y, w - 110, top, bottom);
        profileField.render(f.ctx, f.mx, f.my, 0f);
        if (f.button("SAVE PROFILE", x + w - 104, y - 1, 104, 20)) {
            if (KzClient.config().saveProfile(profileField.getText())) {
                info = "Profile saved.";
                profileField.setText("");
            } else {
                info = "Enter a profile name.";
            }
        }
        y += 26;
        for (String profile : KzClient.config().profiles()) {
            Render2D.roundedPanel(f.ctx, x, y, w, 18, 5, ThemePalette.CARD, ThemePalette.BORDER);
            Render2D.text(f.ctx, f.font, profile, x + 8, y + 5, ThemePalette.TEXT);
            if (f.button("REN", x + w - 112, y + 1, 36, 16)) {
                info = KzClient.config().renameProfile(profile, profileField.getText()) ? "Renamed " + profile
                        : "Type a new unused name in the box, then press REN";
                break;
            }
            if (f.button("LOAD", x + w - 70, y + 1, 44, 16)) {
                info = KzClient.config().loadProfile(profile) ? "Loaded " + profile : "Could not load " + profile;
                sync();
            }
            if (f.button("X", x + w - 22, y + 1, 16, 16)) {
                KzClient.config().deleteProfile(profile);
                break;
            }
            y += 21;
        }
        y += 8;

        // ---- utilidades
        header(f, "DATA", x, y);
        y += 14;
        int third = (w - 12) / 3;
        if (f.button("SAVE CONFIG", x, y, third, 22)) {
            KzClient.config().save();
            info = "Saved to config/kzclient/";
        }
        if (f.button("RESET ALL", x + third + 6, y, third, 22)) {
            KzClient.config().resetAll();
            sync();
            info = "Modules, HUD and appearance reset.";
        }
        if (f.button("ONBOARDING", x + 2 * (third + 6), y, third, 22)) {
            MinecraftClient.getInstance().setScreen(new OnboardingScreen());
        }
        y += 28;
        Render2D.text(f.ctx, f.font, info.isEmpty() ? "Files: config/kzclient/ (config.json, lists.json, friends.json, profiles/)" : info,
                x, y, ThemePalette.TEXT_DIM);
        y += 14;

        // ---- acerca de / funciones opcionales compiladas
        header(f, "ABOUT", x, y);
        y += 14;
        Render2D.text(f.ctx, f.font, "KzClient 1.5.0 | Minecraft 1.21.11 | Fabric", x, y, ThemePalette.TEXT_DIM);
        y += 12;
        int chipX = x;
        for (com.kzclient.feature.Feature feature : com.kzclient.feature.FeatureLoader.loaded()) {
            Render2D.chip(f.ctx, f.font, feature.id(), chipX, y, 0xFF55FF9A);
            chipX += f.font.getWidth(feature.id()) + 16;
        }
        y += 16;
        for (String failure : com.kzclient.feature.FeatureLoader.failed()) {
            Render2D.text(f.ctx, f.font, Frame.fit(f.font, "Failed: " + failure, w), x, y, 0xFFFF6B6B);
            y += 11;
        }
        Render2D.text(f.ctx, f.font, "Optional features not listed here were not compiled into this jar (README).", x, y,
                ThemePalette.TEXT_DIM);
        y += 14;

        Render2D.endScissor(f.ctx);
        f.click = realClick;
        contentHeight = y - (viewY - (int) Math.round(scroll)) + 4;
        if (contentHeight > viewH) {
            int thumbH = Math.max(16, viewH * viewH / contentHeight);
            int thumbY = viewY + (int) ((viewH - thumbH) * (scroll / (contentHeight - viewH)));
            Render2D.roundedRect(f.ctx, viewX + viewW - 3, thumbY, 2, thumbH, 1, ThemePalette.ACCENT_BORDER);
        }
    }
}
