package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.Setting;
import com.kzclient.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/**
 * Pestana MODULES. Cada modulo es una tarjeta desplegable: compacta (icono, nombre, descripcion, estado,
 * interruptor) y, al hacer clic en ella, se expande con animacion mostrando todos sus ajustes reales
 * (sliders, interruptores, selectores, colores y tecla). Dos layouts: Panel (barra lateral + 2 columnas)
 * y Dropdown (una columna por categoria).
 */
public final class ModulesTab implements GuiTab {
    private static final int SIDEBAR_W = 108;
    private static final int HEADER = 40;
    private static final int MINI_HEADER = 26;

    private Category category = Category.COMBAT;
    private double scroll;
    private double scrollTarget;
    private double maxScroll;
    private int viewX;
    private int viewY;
    private int viewW;
    private int viewH;
    private final SettingPanel panel = new SettingPanel(true);
    private TextFieldWidget search;
    private String searchText = "";
    private final List<Module> filtered = new ArrayList<>();

    @Override
    public void init(ClickGuiScreen owner) {
        search = new TextFieldWidget(MinecraftClient.getInstance().textRenderer, 0, 0, 100, 16, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Search modules..."));
        search.setMaxLength(24);
        search.setText(searchText);
        owner.registerField(search);
        hide();
    }

    @Override
    public void hide() {
        if (search != null) {
            searchText = search.getText();
            search.setVisible(false);
            search.setFocused(false);
        }
    }

    /** Modulos de la categoria elegida, o todos los que coinciden con la busqueda. */
    private List<Module> visibleModules() {
        String query = search == null ? "" : search.getText().trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) {
            return KzClient.modules().byCategory(category);
        }
        filtered.clear();
        for (Module module : KzClient.modules().all()) {
            if (module.name().toLowerCase(Locale.ROOT).contains(query)
                    || module.description().toLowerCase(Locale.ROOT).contains(query)) {
                filtered.add(module);
            }
        }
        return filtered;
    }

    @Override
    public boolean capturing() {
        return panel.capturing();
    }

    @Override
    public boolean scrolled(double mouseX, double mouseY, double amount) {
        if (Render2D.inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) {
            scrollTarget = Math.max(0.0, Math.min(maxScroll, scrollTarget - amount * 34.0));
            return true;
        }
        return false;
    }

    @Override
    public void draw(Frame f) {
        panel.update(f);
        scrollTarget = Math.max(0.0, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * (1.0 - Math.exp(-f.dt * 14.0));
        if (Math.abs(scrollTarget - scroll) < 0.05) {
            scroll = scrollTarget;
        }
        if (KzClient.settings().panelLayout) {
            drawPanel(f);
        } else {
            drawDropdown(f);
        }
    }

    // ------------------------------------------------------------- altura de una tarjeta

    private int contentHeight(Module module) {
        int total = 6;
        for (Setting setting : module.settings()) {
            if (setting != module.bind()) {
                total += panel.height(setting);
            }
        }
        return total + SettingPanel.ROW + 4;
    }

    private int cardHeight(Module module, int header, float anim) {
        return header + Math.round(contentHeight(module) * anim);
    }

    // ------------------------------------------------------------- layout Panel

    private void drawPanel(Frame f) {
        int bx = f.x + 10;
        int by = f.y + 10;
        int bh = f.h - 20;

        Render2D.roundedPanel(f.ctx, bx - 2, by - 2, SIDEBAR_W + 4, bh + 4, 7, 0x55000000, ThemePalette.BORDER);
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            Category c = categories[i];
            int cy = by + 4 + i * 30;
            boolean selected = c == category;
            boolean hover = f.hover(bx, cy, SIDEBAR_W, 26);
            if (selected) {
                Render2D.roundedRect(f.ctx, bx + 2, cy, SIDEBAR_W - 4, 26, 6, ThemePalette.ACCENT_SOFT);
                f.ctx.fillGradient(bx + 2, cy, bx + SIDEBAR_W - 2, cy + 26, 0x00000000, 0x14000000 | (ThemePalette.ACCENT & 0xFFFFFF));
                f.ctx.fill(bx + 2, cy + 6, bx + 4, cy + 20, ThemePalette.ACCENT);
            } else if (hover) {
                Render2D.roundedRect(f.ctx, bx + 2, cy, SIDEBAR_W - 4, 26, 6, 0x14FFFFFF);
            }
            Render2D.text(f.ctx, f.font, c.label(), bx + 14, cy + 9,
                    selected ? ThemePalette.ACCENT : (hover ? ThemePalette.TEXT : ThemePalette.TEXT_DIM));
            Render2D.textRight(f.ctx, f.font, enabledCount(c), bx + SIDEBAR_W - 10, cy + 9,
                    selected ? ThemePalette.ACCENT_BORDER : ThemePalette.SWITCH_OFF);
            if (f.click && hover) {
                category = c;
                scroll = 0.0;
                scrollTarget = 0.0;
            }
        }
        Render2D.text(f.ctx, f.font, "v1.4.0 | 1.21.11", bx + 8, by + bh - 12, ThemePalette.TEXT_DIM);

        viewX = bx + SIDEBAR_W + 10;
        viewW = f.x + f.w - 10 - viewX;
        if (search != null) {
            search.setX(viewX);
            search.setY(by);
            search.setWidth(viewW);
            search.setVisible(true);
            search.render(f.ctx, f.mx, f.my, 0f);
        }
        viewY = by + 22;
        viewH = bh - 22;
        boolean inView = f.hover(viewX, viewY, viewW, viewH);

        List<Module> modules = visibleModules();
        int colW = (viewW - 8 - 6) / 2;
        int[] colY = {0, 0};
        Render2D.scissor(f.ctx, viewX, viewY, viewW, viewH);
        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int col = i & 1;
            int cx = viewX + col * (colW + 8);
            int cy = viewY - (int) Math.round(scroll) + colY[col];
            colY[col] += drawCard(f, module, cx, cy, colW, inView, false) + 8;
        }
        Render2D.endScissor(f.ctx);
        finishScroll(f, Math.max(colY[0], colY[1]) - 8);
    }

    private static String enabledCount(Category c) {
        int on = 0;
        List<Module> list = KzClient.modules().byCategory(c);
        for (Module module : list) {
            if (module.isEnabled()) {
                on++;
            }
        }
        return on + "/" + list.size();
    }

    // ------------------------------------------------------------- tarjeta desplegable

    /** Dibuja la tarjeta y devuelve su altura actual (animada). */
    private int drawCard(Frame f, Module module, int x, int y, int w, boolean inView, boolean mini) {
        int header = mini ? MINI_HEADER : HEADER;
        float on = module.anim().step(module.isEnabled(), f.dt);
        float open = module.expandAnim().step(module.isExpanded(), f.dt);
        int h = cardHeight(module, header, open);
        boolean headerHover = inView && f.hover(x, y, w, header);

        int border = ColorUtil.lerp(ThemePalette.BORDER, ThemePalette.ACCENT_BORDER, Math.max(on * 0.8f, open));
        Render2D.shadow(f.ctx, x, y, w, h, 6, 2);
        Render2D.roundedPanel(f.ctx, x, y, w, h, 6, headerHover ? 0xF02A2030 : ThemePalette.CARD, border);
        if (on > 0.01f) {
            f.ctx.fillGradient(x + 2, y + 2, x + w - 2, y + header - 2, ColorUtil.scaleAlpha(0x38000000 | (ThemePalette.ACCENT & 0xFFFFFF), on),
                    0x00000000 | (ThemePalette.ACCENT & 0xFFFFFF));
        }
        Render2D.grid(f.ctx, x + 2, y + 2, w - 4, header - 4, 10, ThemePalette.GRID);

        int textX = x + 10;
        if (!mini) {
            // icono: tesela con la inicial del modulo + punto de estado
            int ix = x + 8;
            int iy = y + 8;
            Render2D.roundedPanel(f.ctx, ix, iy, 24, 24, 6, ColorUtil.lerp(0xFF1A141D, ThemePalette.ACCENT_SOFT | 0xFF000000, on * 0.4f),
                    ColorUtil.lerp(ThemePalette.BORDER, ThemePalette.ACCENT_BORDER, on));
            String letter = module.name().substring(0, 1).toUpperCase(java.util.Locale.ROOT);
            Render2D.textCentered(f.ctx, f.font, letter, ix, iy + 8, 24,
                    ColorUtil.lerp(ThemePalette.TEXT_DIM, ThemePalette.ACCENT, on));
            int dot = ColorUtil.lerp(ThemePalette.SWITCH_OFF, 0xFF55FF9A, on);
            Render2D.roundedRect(f.ctx, ix + 19, iy + 19, 6, 6, 3, 0xFF0D0812);
            Render2D.roundedRect(f.ctx, ix + 20, iy + 20, 4, 4, 2, dot);
            textX = x + 40;
        }
        int rightReserve = mini ? 40 : 84;
        Render2D.text(f.ctx, f.font, Frame.fit(f.font, module.name(), w - (textX - x) - rightReserve), textX,
                y + (mini ? 9 : 10), ColorUtil.lerp(ThemePalette.TEXT, ThemePalette.ACCENT, on));
        if (!mini) {
            Render2D.text(f.ctx, f.font, Frame.fit(f.font, module.description(), w - (textX - x) - rightReserve), textX,
                    y + 22, ThemePalette.TEXT_DIM);
        }

        // interruptor + indicador de configuracion + chevron
        int toggleX = x + w - 38;
        int toggleY = y + (mini ? 6 : 13);
        Render2D.toggle(f.ctx, toggleX, toggleY, on);
        if (!mini) {
            drawSlidersIcon(f, x + w - 62, y + 16, module.hasOwnSettings() ? ThemePalette.ACCENT : ThemePalette.SWITCH_OFF);
            drawChevron(f, x + w - 78, y + 17, open);
        }

        boolean overToggle = f.hover(toggleX - 3, toggleY - 3, 34, 20);
        if (inView && f.hover(x, y, w, header)) {
            if (f.click) {
                if (overToggle) {
                    module.toggle();
                } else {
                    module.toggleExpanded();
                }
            } else if (f.rightClick) {
                module.toggle();
            }
        }

        // contenido (solo se dibuja mientras haya algo visible)
        int visible = h - header;
        if (visible > 1) {
            f.ctx.fill(x + 6, y + header, x + w - 6, y + header + 1, ColorUtil.scaleAlpha(ThemePalette.BORDER, open));
            Render2D.scissor(f.ctx, x + 1, y + header + 1, w - 2, visible - 1);
            boolean live = inView && open > 0.98f;
            int sy = y + header + 6;
            for (Setting setting : module.settings()) {
                if (setting == module.bind()) {
                    continue;
                }
                sy += panel.draw(f, setting, x, sy, w, live);
            }
            panel.draw(f, module.bind(), x, sy, w, live);
            Render2D.endScissor(f.ctx);
        }
        return h;
    }

    private static void drawSlidersIcon(Frame f, int x, int y, int color) {
        f.ctx.fill(x, y, x + 12, y + 1, color);
        f.ctx.fill(x, y + 4, x + 12, y + 5, color);
        f.ctx.fill(x, y + 8, x + 12, y + 9, color);
        f.ctx.fill(x + 7, y - 1, x + 9, y + 2, color);
        f.ctx.fill(x + 2, y + 3, x + 4, y + 6, color);
        f.ctx.fill(x + 8, y + 7, x + 10, y + 10, color);
    }

    private static void drawChevron(Frame f, int x, int y, float open) {
        int color = ColorUtil.lerp(ThemePalette.TEXT_DIM, ThemePalette.ACCENT, open);
        for (int i = 0; i < 4; i++) {
            int row = open > 0.5f ? 3 - i : i;
            f.ctx.fill(x + i, y + row, x + i + 1, y + row + 1, color);
            f.ctx.fill(x + 6 - i, y + row, x + 7 - i, y + row + 1, color);
        }
    }

    // ---------------------------------------------------------- layout Dropdown

    private void drawDropdown(Frame f) {
        if (search != null) {
            search.setVisible(false);
            search.setFocused(false);
        }
        int bx = f.x + 10;
        int by = f.y + 10;
        viewX = bx;
        viewY = by;
        viewW = f.w - 20;
        viewH = f.h - 20;
        boolean inView = f.hover(viewX, viewY, viewW, viewH);

        Category[] categories = Category.values();
        int gap = 8;
        int colW = (viewW - gap * (categories.length - 1) - 6) / categories.length;
        int tallest = 0;
        Render2D.scissor(f.ctx, viewX, viewY, viewW, viewH);
        for (int i = 0; i < categories.length; i++) {
            int cx = bx + i * (colW + gap);
            int cy = by - (int) Math.round(scroll);
            Render2D.roundedPanel(f.ctx, cx, cy, colW, 22, 6, ThemePalette.HEADER, ThemePalette.ACCENT_BORDER);
            Render2D.textCentered(f.ctx, f.font, categories[i].label(), cx, cy + 7, colW, ThemePalette.ACCENT);
            int ry = cy + 26;
            for (Module module : KzClient.modules().byCategory(categories[i])) {
                ry += drawCard(f, module, cx, ry, colW, inView, true) + 4;
            }
            tallest = Math.max(tallest, ry - (by - (int) Math.round(scroll)));
        }
        Render2D.endScissor(f.ctx);
        finishScroll(f, tallest);
    }

    private void finishScroll(Frame f, int contentHeight) {
        maxScroll = Math.max(0.0, contentHeight - viewH);
        if (maxScroll > 0.0) {
            int thumbH = Math.max(16, (int) (viewH * (viewH / (viewH + maxScroll))));
            int thumbY = viewY + (int) ((viewH - thumbH) * (scroll / maxScroll));
            Render2D.roundedRect(f.ctx, viewX + viewW - 3, thumbY, 2, thumbH, 1, ThemePalette.ACCENT_BORDER);
        }
    }
}
