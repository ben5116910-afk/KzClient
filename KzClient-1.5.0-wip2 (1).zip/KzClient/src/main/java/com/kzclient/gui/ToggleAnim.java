package com.kzclient.gui;

/** Animacion suave 0..1 para interruptores. */
public final class ToggleAnim {
    private float value;

    public float step(boolean on, double dt) {
        float target = on ? 1f : 0f;
        value += (target - value) * (float) (1.0 - Math.exp(-dt * 18.0));
        if (Math.abs(target - value) < 0.002f) {
            value = target;
        }
        return value;
    }

    public float get() {
        return value;
    }
}
