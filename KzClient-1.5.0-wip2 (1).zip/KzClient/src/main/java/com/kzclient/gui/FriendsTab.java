package com.kzclient.gui;

import com.kzclient.KzClient;
import com.kzclient.social.FriendsManager;
import com.kzclient.social.FriendsManager.Friend;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

/**
 * Pestana FRIENDS: buscador, tarjetas con avatar/nombre/estado, menu contextual (...), confirmacion antes de
 * eliminar y alta de amigos. Estado online = el jugador figura en la lista del servidor actual; no se inventa
 * ningun dato que el servidor no publique.
 */
public final class FriendsTab implements GuiTab {
    private static final int ROW_H = 30;
    private static final int ROW_GAP = 4;
    private static final int GREEN = 0xFF3DDC84;

    private TextFieldWidget search;
    private TextFieldWidget add;
    private String searchText = "";
    private String addText = "";
    private double scroll;
    private double scrollTarget;
    private int viewX;
    private int viewY;
    private int viewW;
    private int viewH;
    private int contentH;
    private String menuFor;
    private String pendingRemove;
    private String info = "";
    private long infoUntil;
    private int uuidTimer;
    private boolean enterWasDown;

    @Override
    public void init(ClickGuiScreen owner) {
        MinecraftClient mc = MinecraftClient.getInstance();
        search = new TextFieldWidget(mc.textRenderer, 0, 0, 100, 18, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Search friends..."));
        search.setMaxLength(16);
        search.setText(searchText);
        owner.registerField(search);
        add = new TextFieldWidget(mc.textRenderer, 0, 0, 100, 18, Text.literal("Add"));
        add.setPlaceholder(Text.literal("Player name"));
        add.setMaxLength(FriendsManager.MAX_NAME);
        add.setText(addText);
        owner.registerField(add);
        hide();
    }

    @Override
    public void hide() {
        if (search != null) {
            searchText = search.getText();
            addText = add.getText();
            search.setVisible(false);
            search.setFocused(false);
            add.setVisible(false);
            add.setFocused(false);
        }
        menuFor = null;
        pendingRemove = null;
    }

    @Override
    public boolean scrolled(double mouseX, double mouseY, double amount) {
        if (Render2D.inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) {
            scrollTarget = Math.max(0, Math.min(Math.max(0, contentH - viewH), scrollTarget - amount * 28.0));
            return true;
        }
        return false;
    }

    private void say(String text) {
        info = text;
        infoUntil = System.currentTimeMillis() + 3000L;
    }

    @Override
    public void draw(Frame f) {
        FriendsManager friends = KzClient.friends();
        int pad = 12;
        int x = f.x + pad;
        int w = f.w - pad * 2;
        int y = f.y + pad;

        // ---- cabecera: buscador + contador
        search.setX(x);
        search.setY(y);
        search.setWidth(w - 90);
        search.setVisible(true);
        search.render(f.ctx, f.mx, f.my, 0f);
        int online = 0;
        for (Friend friend : friends.list()) {
            if (friends.isOnline(friend)) {
                online++;
            }
        }
        Render2D.textRight(f.ctx, f.font, online + " online / " + friends.count(), x + w, y + 5, ThemePalette.TEXT_DIM);
        y += 26;

        // ---- zona de lista
        int bottomBar = 30;
        viewX = x;
        viewY = y;
        viewW = w;
        viewH = f.h - (y - f.y) - bottomBar - pad;
        scroll += (scrollTarget - scroll) * Math.min(1.0, f.dt * 14.0);

        List<Friend> shown = new ArrayList<>();
        for (Friend friend : friends.list()) {
            if (FriendsManager.matches(friend, search.getText())) {
                shown.add(friend);
            }
        }
        contentH = shown.size() * (ROW_H + ROW_GAP);
        scrollTarget = Math.max(0, Math.min(Math.max(0, contentH - viewH), scrollTarget));

        boolean modal = pendingRemove != null;
        boolean realClick = f.click;
        if (modal) {
            f.click = false;
        }
        String openMenuRow = null;
        int menuX = 0;
        int menuY = 0;
        if (shown.isEmpty()) {
            String text = friends.count() == 0 ? "No friends yet. Type a name below and press Add Friend."
                    : "No friends match your search.";
            Render2D.textCentered(f.ctx, f.font, text, viewX, viewY + viewH / 2 - 4, viewW, ThemePalette.TEXT_DIM);
        }
        Render2D.scissor(f.ctx, viewX, viewY, viewW, viewH);
        int ry = viewY - (int) Math.round(scroll);
        uuidTimer++;
        for (Friend friend : shown) {
            if (ry + ROW_H >= viewY && ry <= viewY + viewH) {
                PlayerListEntry entry = friends.onlineEntry(friend);
                boolean isOnline = entry != null;
                boolean hover = f.hover(viewX, Math.max(ry, viewY), viewW - 2, ROW_H) && f.hover(viewX, viewY, viewW, viewH);
                Render2D.card(f.ctx, viewX, ry, viewW - 6, ROW_H, hover);
                SkinFace.draw(f.ctx, f.font, entry, friend.name(), viewX + 8, ry + 5, 20);
                Render2D.text(f.ctx, f.font, friend.name(), viewX + 36, ry + 6, ThemePalette.TEXT);
                f.ctx.fill(viewX + 36, ry + 19, viewX + 42, ry + 25, isOnline ? GREEN : 0xFF6B6270);
                Render2D.text(f.ctx, f.font, isOnline ? "Online" : "Offline", viewX + 46, ry + 18,
                        isOnline ? GREEN : ThemePalette.TEXT_DIM);
                int bx = viewX + viewW - 6 - 26;
                boolean menuHover = f.hover(bx, ry + 6, 20, 18) && f.hover(viewX, viewY, viewW, viewH);
                Render2D.roundedPanel(f.ctx, bx, ry + 6, 20, 18, 5, menuHover ? ThemePalette.ACCENT_SOFT : 0xFF0B090D,
                        menuHover ? ThemePalette.ACCENT : ThemePalette.BORDER);
                Render2D.textCentered(f.ctx, f.font, "...", bx, ry + 11, 20, ThemePalette.TEXT);
                if (f.click && menuHover) {
                    menuFor = friend.name().equals(menuFor) ? null : friend.name();
                }
                if (friend.name().equals(menuFor)) {
                    openMenuRow = friend.name();
                    menuX = bx - 70;
                    menuY = ry + 6;
                }
            }
            ry += ROW_H + ROW_GAP;
        }
        Render2D.endScissor(f.ctx);
        if (contentH > viewH) {
            int thumbH = Math.max(16, viewH * viewH / contentH);
            int thumbY = viewY + (int) ((viewH - thumbH) * (scroll / (contentH - viewH)));
            Render2D.roundedRect(f.ctx, viewX + viewW - 3, thumbY, 2, thumbH, 1, ThemePalette.ACCENT_BORDER);
        }

        // ---- menu contextual (fuera del scissor para que no se recorte)
        if (openMenuRow != null) {
            int mw = 66;
            Render2D.roundedPanel(f.ctx, menuX, menuY, mw, 44, 5, ThemePalette.SECONDARY, ThemePalette.ACCENT_BORDER);
            boolean removeHover = f.hover(menuX + 3, menuY + 3, mw - 6, 18);
            boolean closeHover = f.hover(menuX + 3, menuY + 23, mw - 6, 18);
            Render2D.textCentered(f.ctx, f.font, "Remove", menuX, menuY + 8, mw, removeHover ? 0xFFFF6B6B : ThemePalette.TEXT);
            Render2D.textCentered(f.ctx, f.font, "Close", menuX, menuY + 28, mw, closeHover ? ThemePalette.ACCENT : ThemePalette.TEXT_DIM);
            if (f.click && removeHover) {
                pendingRemove = openMenuRow;
                menuFor = null;
            } else if (f.click && closeHover) {
                menuFor = null;
            } else if (f.click && !f.hover(menuX, menuY, mw, 44) && !f.hover(menuX + mw, menuY, 40, 20)) {
                menuFor = null;
            }
        }

        // ---- barra inferior: anadir amigo
        int by = f.y + f.h - pad - 20;
        add.setX(x);
        add.setY(by);
        add.setWidth(w - 128);
        add.setVisible(!modal);
        if (!modal) {
            add.render(f.ctx, f.mx, f.my, 0f);
        }
        boolean addClick = f.button("+ Add Friend", x + w - 120, by - 1, 120, 20) && !modal;
        if (addClick || (add.isFocused() && enterPressed())) {
            FriendsManager.AddResult result = friends.add(add.getText());
            switch (result) {
                case ADDED -> {
                    add.setText("");
                    say("Friend added.");
                }
                case DUPLICATE -> say("That player is already your friend.");
                case SELF -> say("You cannot add yourself.");
                default -> say("Invalid name (1-16 letters, numbers or _).");
            }
        }
        if (System.currentTimeMillis() < infoUntil) {
            Render2D.text(f.ctx, f.font, info, x, by - 12, ThemePalette.TEXT_DIM);
        }

        // ---- confirmacion de borrado
        f.click = realClick;
        if (modal) {
            int mw = 220;
            int mh = 70;
            int mx = f.x + (f.w - mw) / 2;
            int my = f.y + (f.h - mh) / 2;
            f.ctx.fill(f.x, f.y, f.x + f.w, f.y + f.h, 0xAA000000);
            Render2D.roundedPanel(f.ctx, mx, my, mw, mh, 8, ThemePalette.SECONDARY, ThemePalette.ACCENT_BORDER);
            Render2D.textCentered(f.ctx, f.font, "Remove " + pendingRemove + " from friends?", mx, my + 14, mw, ThemePalette.TEXT);
            if (f.button("Remove", mx + 14, my + 40, 92, 20)) {
                friends.remove(pendingRemove);
                pendingRemove = null;
            } else if (f.button("Cancel", mx + mw - 106, my + 40, 92, 20)) {
                pendingRemove = null;
            }
        }
        if (uuidTimer >= 40) {
            uuidTimer = 0;
            friends.learnUuids();
        }
    }

    /** Flanco de subida de Enter (GLFW), para anadir con el teclado sin repetir al mantener la tecla. */
    private boolean enterPressed() {
        boolean now = com.kzclient.input.KeybindManager.isDown(org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER);
        boolean edge = now && !enterWasDown;
        enterWasDown = now;
        return edge;
    }
}
