package com.kzclient.gui;

import com.kzclient.util.ColorUtil;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Primitivas 2D basadas unicamente en DrawContext (sin matrices ni RenderSystem). */
public final class Render2D {
    private static final String[] GLYPH_K = {
            "10001", "10010", "10100", "11000", "10100", "10010", "10001"
    };
    private static final String[] GLYPH_Z = {
            "11111", "00001", "00010", "00100", "01000", "10000", "11111"
    };

    private Render2D() {
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        if (w <= 0 || h <= 0) {
            return;
        }
        int r = Math.min(radius, Math.min(w, h) / 2);
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    /** Rectangulo redondeado con borde de 1 px. */
    public static void roundedPanel(DrawContext ctx, int x, int y, int w, int h, int radius, int fill, int border) {
        roundedRect(ctx, x, y, w, h, radius, border);
        roundedRect(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, radius - 1), fill);
    }

    public static void grid(DrawContext ctx, int x, int y, int w, int h, int step, int color) {
        for (int gx = x; gx < x + w; gx += step) {
            ctx.fill(gx, y, gx + 1, y + h, color);
        }
        for (int gy = y; gy < y + h; gy += step) {
            ctx.fill(x, gy, x + w, gy + 1, color);
        }
    }

    /** Sombra suave: capas translucidas alrededor de un rectangulo redondeado. */
    public static void shadow(DrawContext ctx, int x, int y, int w, int h, int radius, int layers) {
        for (int i = layers; i >= 1; i--) {
            int alpha = Math.max(2, 26 / i);
            roundedRect(ctx, x - i, y - i + 2, w + i * 2, h + i * 2, radius + i, (alpha << 24));
        }
    }

    public static void toggle(DrawContext ctx, int x, int y, float anim) {
        int track = ColorUtil.lerp(ThemePalette.SWITCH_OFF, ThemePalette.ACCENT, anim);
        roundedRect(ctx, x, y, 28, 14, 7, track);
        roundedRect(ctx, x + 2 + Math.round(anim * 14f), y + 2, 10, 10, 5, 0xFFFFFFFF);
    }

    public static void text(DrawContext ctx, TextRenderer font, String text, int x, int y, int color) {
        ctx.drawText(font, text, x, y, color, false);
    }

    public static void textCentered(DrawContext ctx, TextRenderer font, String text, int x, int y, int w, int color) {
        ctx.drawText(font, text, x + (w - font.getWidth(text)) / 2, y, color, false);
    }

    public static void textRight(DrawContext ctx, TextRenderer font, String text, int right, int y, int color) {
        ctx.drawText(font, text, right - font.getWidth(text), y, color, false);
    }

    public static void scissor(DrawContext ctx, int x, int y, int w, int h) {
        ctx.enableScissor(x, y, x + w, y + h);
    }

    public static void endScissor(DrawContext ctx) {
        ctx.disableScissor();
    }

    /** Marca de agua "KZ" dibujada con celdas, centrada en (cx, cy). */
    public static void watermarkKz(DrawContext ctx, int cx, int cy, int cell, int color) {
        int totalW = (5 + 1 + 5) * cell;
        int totalH = 7 * cell;
        int left = cx - totalW / 2;
        int top = cy - totalH / 2;
        drawGlyph(ctx, GLYPH_K, left, top, cell, color);
        drawGlyph(ctx, GLYPH_Z, left + 6 * cell, top, cell, color);
    }

    public static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    /** Linea de 1 px (Bresenham) con DrawContext.fill. */
    public static void line(DrawContext ctx, int x0, int y0, int x1, int y1, int color) {
        if (Math.abs(x0) > 6000 || Math.abs(y0) > 6000 || Math.abs(x1) > 6000 || Math.abs(y1) > 6000) {
            return;
        }
        int dx = Math.abs(x1 - x0);
        int dy = -Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        int guard = 0;
        while (guard++ < 4000) {
            ctx.fill(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) {
                break;
            }
            int e2 = 2 * err;
            if (e2 >= dy) {
                err += dy;
                x0 += sx;
            }
            if (e2 <= dx) {
                err += dx;
                y0 += sy;
            }
        }
    }

    /** Titulo de seccion: texto con acento y linea degradada hasta el ancho w. */
    public static void sectionHeader(DrawContext ctx, TextRenderer font, String text, int x, int y, int w) {
        roundedRect(ctx, x, y + 1, 3, 9, 1, ThemePalette.ACCENT);
        ctx.drawText(font, text, x + 8, y + 1, ThemePalette.TEXT, false);
        int lx = x + 8 + font.getWidth(text) + 6;
        if (x + w > lx) {
            ctx.fillGradient(lx, y + 5, x + w, y + 6, ThemePalette.ACCENT_BORDER, 0x00000000);
        }
    }

    /** Tarjeta con degradado suave y borde. */
    public static void card(DrawContext ctx, int x, int y, int w, int h, boolean highlight) {
        roundedPanel(ctx, x, y, w, h, 6, ThemePalette.CARD, highlight ? ThemePalette.ACCENT_BORDER : ThemePalette.BORDER);
        ctx.fillGradient(x + 2, y + 2, x + w - 2, y + Math.min(h - 2, 14), 0x14FFFFFF, 0x00FFFFFF);
    }

    /** Pastilla de texto (etiqueta de estado). */
    public static void chip(DrawContext ctx, TextRenderer font, String text, int x, int y, int color) {
        int w = font.getWidth(text) + 10;
        roundedPanel(ctx, x, y, w, 13, 6, (color & 0x00FFFFFF) | 0x33000000, (color & 0x00FFFFFF) | 0xAA000000);
        ctx.drawText(font, text, x + 5, y + 3, color, false);
    }

    private static void drawGlyph(DrawContext ctx, String[] rows, int x, int y, int cell, int color) {
        for (int row = 0; row < rows.length; row++) {
            for (int col = 0; col < rows[row].length(); col++) {
                if (rows[row].charAt(col) == '1') {
                    ctx.fill(x + col * cell, y + row * cell, x + (col + 1) * cell, y + (row + 1) * cell, color);
                }
            }
        }
    }
}
