package com.kzclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Estado de un fotograma de la GUI: contexto de dibujo, raton y region del cuerpo. */
public final class Frame {
    public DrawContext ctx;
    public TextRenderer font;
    public int mx;
    public int my;
    public boolean click;
    public boolean rightClick;
    public boolean leftDown;
    public double dt;
    public int x;
    public int y;
    public int w;
    public int h;
    public int screenW;
    public int screenH;

    public boolean hover(int bx, int by, int bw, int bh) {
        return Render2D.inside(mx, my, bx, by, bw, bh);
    }

    public boolean clicked(int bx, int by, int bw, int bh) {
        return click && hover(bx, by, bw, bh);
    }

    /** Boton con estados normal, hover y pressed; devuelve true si se pulso en este fotograma. */
    public boolean button(String label, int bx, int by, int bw, int bh) {
        boolean over = hover(bx, by, bw, bh);
        boolean pressed = over && leftDown;
        int fill = pressed ? 0xFF3A1B2B : (over ? ThemePalette.ACCENT_SOFT : ThemePalette.CARD);
        Render2D.roundedPanel(ctx, bx, by + (pressed ? 1 : 0), bw, bh, 6, fill,
                over ? ThemePalette.ACCENT_BORDER : ThemePalette.BORDER);
        Render2D.textCentered(ctx, font, label, bx, by + (bh - 8) / 2 + 1 + (pressed ? 1 : 0), bw,
                over ? ThemePalette.ACCENT : ThemePalette.TEXT);
        return click && over;
    }

    public static String fit(TextRenderer font, String text, int maxWidth) {
        if (font.getWidth(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "...";
        return font.trimToWidth(text, Math.max(0, maxWidth - font.getWidth(ellipsis))) + ellipsis;
    }
}
