package com.kzclient.render;

import net.minecraft.util.math.Box;

public record EspTarget(Box box, int color) {
}
