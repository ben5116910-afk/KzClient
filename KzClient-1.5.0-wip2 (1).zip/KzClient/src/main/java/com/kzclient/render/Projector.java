package com.kzclient.render;

import com.kzclient.KzClient;
import com.kzclient.module.modules.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Proyeccion mundo -> pantalla (coordenadas GUI) para los overlays 2D.
 *
 * <p>Usa la camara real del fotograma ({@link FrameCamera}: posicion y angulos ya interpolados por
 * Minecraft, tambien en tercera persona) y el FOV efectivo capturado de GameRenderer.getFov. Si los mixins no
 * estuvieran activos, recurre a la camara del jugador interpolando posicion Y angulos con tickProgress
 * (el codigo anterior interpolaba solo la posicion, de ahi el retraso al girar).
 *
 * <p>No asigna objetos por fotograma: el resultado de project() se escribe en un array del llamador y
 * projectBox() reutiliza un unico array interno.
 */
public final class Projector {
    private double camX;
    private double camY;
    private double camZ;
    private double rx;
    private double rz;
    private double ux;
    private double uy;
    private double uz;
    private double fx;
    private double fy;
    private double fz;
    private double tanHalf;
    private double aspect;
    private int screenW;
    private int screenH;
    private final double[] tmp = new double[3];
    private final int[] boxOut = new int[4];

    public boolean prepare(MinecraftClient mc, float tickProgress, int sw, int sh) {
        ClientPlayerEntity player = mc.player;
        if (player == null || sw <= 0 || sh <= 0) {
            return false;
        }
        double yawDeg;
        double pitchDeg;
        double fovDeg;
        Freecam freecam = KzClient.modules().get(Freecam.class);
        if (freecam != null && freecam.isEnabled()) {
            camX = freecam.x(tickProgress);
            camY = freecam.y(tickProgress);
            camZ = freecam.z(tickProgress);
            yawDeg = freecam.yaw();
            pitchDeg = freecam.pitch();
            fovDeg = FrameCamera.fov() > 0.0 ? FrameCamera.fov() : mc.options.getFov().getValue();
        } else if (FrameCamera.fresh()) {
            camX = FrameCamera.x();
            camY = FrameCamera.y();
            camZ = FrameCamera.z();
            yawDeg = FrameCamera.yaw();
            pitchDeg = FrameCamera.pitch();
            fovDeg = FrameCamera.fov() > 0.0 ? FrameCamera.fov() : mc.options.getFov().getValue();
        } else {
            if (!mc.options.getPerspective().isFirstPerson()) {
                return false;
            }
            Vec3d cam = player.getCameraPosVec(tickProgress);
            camX = cam.x;
            camY = cam.y;
            camZ = cam.z;
            yawDeg = player.getYaw(tickProgress);
            pitchDeg = player.getPitch(tickProgress);
            fovDeg = mc.options.getFov().getValue();
        }
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double cp = Math.cos(pitch);
        fx = -Math.sin(yaw) * cp;
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * cp;
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        // up = right x forward (right.y = 0)
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
        int fbw = mc.getWindow().getFramebufferWidth();
        int fbh = mc.getWindow().getFramebufferHeight();
        // relacion de aspecto real del framebuffer (la misma que usa la matriz de proyeccion del mundo)
        aspect = fbw > 0 && fbh > 0 ? (double) fbw / (double) fbh : (double) sw / (double) sh;
        screenW = sw;
        screenH = sh;
        return true;
    }

    /**
     * out[0], out[1] = pantalla (px GUI); out[2] = profundidad en bloques (si out.length > 2).
     * Devuelve false si el punto esta detras de la camara.
     */
    public boolean project(double x, double y, double z, double[] out) {
        double dx = x - camX;
        double dy = y - camY;
        double dz = z - camZ;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) {
            return false;
        }
        double cx = dx * rx + dz * rz;
        double cy = dx * ux + dy * uy + dz * uz;
        double ndcX = cx / (depth * tanHalf * aspect);
        double ndcY = cy / (depth * tanHalf);
        out[0] = (ndcX * 0.5 + 0.5) * screenW;
        out[1] = (0.5 - ndcY * 0.5) * screenH;
        if (out.length > 2) {
            out[2] = depth;
        }
        return true;
    }

    /** Pixeles GUI que ocupa un bloque a la profundidad dada. */
    public double pixelsPerBlock(double depth) {
        return screenH / (2.0 * Math.max(0.05, depth) * tanHalf);
    }

    /**
     * Rectangulo en pantalla {minX, minY, maxX, maxY} o null si alguna esquina queda detras o fuera.
     * El array devuelto se reutiliza en la siguiente llamada: consumirlo antes de volver a proyectar.
     */
    public int[] projectBox(Box box) {
        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? box.minX : box.maxX;
            double y = (i & 2) == 0 ? box.minY : box.maxY;
            double z = (i & 4) == 0 ? box.minZ : box.maxZ;
            if (!project(x, y, z, tmp)) {
                return null;
            }
            minX = Math.min(minX, tmp[0]);
            minY = Math.min(minY, tmp[1]);
            maxX = Math.max(maxX, tmp[0]);
            maxY = Math.max(maxY, tmp[1]);
        }
        if (maxX < -50 || minX > screenW + 50 || maxY < -50 || minY > screenH + 50) {
            return null;
        }
        boxOut[0] = (int) minX;
        boxOut[1] = (int) minY;
        boxOut[2] = (int) maxX;
        boxOut[3] = (int) maxY;
        return boxOut;
    }

    public int screenW() {
        return screenW;
    }

    public int screenH() {
        return screenH;
    }
}
