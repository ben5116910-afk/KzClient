package com.kzclient.render;

import com.kzclient.KzClient;
import com.kzclient.gui.Render2D;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.BlockEsp;
import com.kzclient.module.modules.Hitbox;
import com.kzclient.module.modules.Nametags;
import com.kzclient.module.modules.PlayerEsp;
import com.kzclient.module.modules.StorageEsp;
import com.kzclient.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Dibuja los ESP (cajas, relleno y lineas 2D proyectadas) y las nametags sobre el HUD. */
public final class WorldOverlay {
    private final Projector projector = new Projector();

    public void render(DrawContext ctx, float hudTickProgress) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) {
            return;
        }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof ChatScreen)) {
            return;
        }
        ModuleManager modules = KzClient.modules();
        PlayerEsp playerEsp = modules.get(PlayerEsp.class);
        Hitbox hitbox = modules.get(Hitbox.class);
        StorageEsp storage = modules.get(StorageEsp.class);
        BlockEsp blocks = modules.get(BlockEsp.class);
        Nametags nametags = modules.get(Nametags.class);
        boolean drawHitbox = hitbox.isEnabled() && hitbox.visualize();
        if (!playerEsp.isEnabled() && !drawHitbox && !storage.isEnabled() && !blocks.isEnabled()
                && !nametags.isEnabled()) {
            return;
        }
        // Se interpola con el MISMO tickProgress con el que Minecraft dibujo el mundo en este fotograma
        // (capturado en Camera.update). Con otro valor las cajas y etiquetas se desfasan al moverse o girar.
        float tickProgress = FrameCamera.tickProgress(hudTickProgress);
        if (!projector.prepare(mc, tickProgress, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight())) {
            return;
        }

        if (playerEsp.isEnabled() && playerEsp.boxes()) {
            for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
                if (!playerEsp.valid(player)) {
                    continue;
                }
                int[] r = drawBox(ctx, lerped(player, tickProgress), playerEsp.colorFor(player), playerEsp.fill(),
                        playerEsp.tracers());
                if (r != null && playerEsp.distance()) {
                    String text = Math.round(mc.player.distanceTo(player)) + "m";
                    Render2D.textCentered(ctx, mc.textRenderer, text, r[0], r[1] - 10, r[2] - r[0], 0xFFF5EDF3);
                }
            }
        }
        if (drawHitbox) {
            for (Entity entity : mc.world.getEntities()) {
                if (hitbox.applies(entity) && mc.player.distanceTo(entity) < 48f) {
                    drawBox(ctx, lerped(entity, tickProgress).expand(hitbox.margin(entity)), 0xFFFFB02E, false, false);
                }
            }
        }
        if (storage.isEnabled()) {
            for (EspTarget target : storage.targets()) {
                drawBox(ctx, target.box(), target.color(), storage.fill(), storage.tracers());
            }
        }
        if (blocks.isEnabled()) {
            for (EspTarget target : blocks.targets()) {
                drawBox(ctx, target.box(), target.color(), blocks.fill(), blocks.tracers());
            }
        }
        if (nametags.isEnabled()) {
            nametags.render(ctx, projector, tickProgress);
        }
    }

    private static Box lerped(Entity entity, float tickProgress) {
        Vec3d p = entity.getLerpedPos(tickProgress);
        return entity.getBoundingBox().offset(p.x - entity.getX(), p.y - entity.getY(), p.z - entity.getZ());
    }

    private int[] drawBox(DrawContext ctx, Box box, int color, boolean fill, boolean tracer) {
        int[] r = projector.projectBox(box);
        if (r == null) {
            return null;
        }
        if (fill) {
            ctx.fill(r[0], r[1], r[2], r[3], ColorUtil.withAlpha(color, 0x26));
        }
        Render2D.outline(ctx, r[0], r[1], r[2], r[3], color);
        if (tracer) {
            Render2D.line(ctx, projector.screenW() / 2, projector.screenH(), (r[0] + r[2]) / 2, r[3], color);
        }
        return r;
    }
}
