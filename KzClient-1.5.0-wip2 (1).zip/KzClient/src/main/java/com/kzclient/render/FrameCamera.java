package com.kzclient.render;

/**
 * Camara real del fotograma actual, capturada por CameraMixin (Camera.update) y GameRendererMixin (getFov).
 * Contiene la posicion y rotacion YA interpoladas por Minecraft para este fotograma, de modo que los overlays
 * se proyectan con exactamente la misma camara que el mundo. Solo se accede desde el hilo de render.
 */
public final class FrameCamera {
    private static double x;
    private static double y;
    private static double z;
    private static float yaw;
    private static float pitch;
    private static float tickProgress;
    private static double fov = -1.0;
    private static boolean valid;
    private static long stamp;

    private FrameCamera() {
    }

    private static double pendingX;
    private static double pendingY;
    private static double pendingZ;
    private static boolean pending;

    /** Ultima posicion fijada con Camera.setPos (la usa captureFrame al terminar Camera.update). */
    public static void pendingPos(double px, double py, double pz) {
        pendingX = px;
        pendingY = py;
        pendingZ = pz;
        pending = true;
    }

    /** Cierra la captura del fotograma; sin posicion pendiente se ignora para no mezclar datos viejos. */
    public static void captureFrame(float cyaw, float cpitch, float ctick) {
        if (pending) {
            capture(pendingX, pendingY, pendingZ, cyaw, cpitch, ctick);
        }
    }

    public static void capture(double cx, double cy, double cz, float cyaw, float cpitch, float ctick) {
        tickProgress = ctick;
        x = cx;
        y = cy;
        z = cz;
        yaw = cyaw;
        pitch = cpitch;
        valid = true;
        stamp = System.nanoTime();
    }

    public static void captureFov(double degrees) {
        if (degrees > 1.0 && degrees < 179.0) {
            fov = degrees;
        }
    }

    /** true si la camara se capturo hace menos de 250 ms (el mixin esta funcionando). */
    public static boolean fresh() {
        return valid && System.nanoTime() - stamp < 250_000_000L;
    }

    /**
     * tickProgress exacto con el que el mundo se dibujo en este fotograma (el argumento de Camera.update).
     * Interpolar las entidades con este mismo valor es lo que mantiene las etiquetas pegadas al jugador.
     */
    public static float tickProgress(float fallback) {
        return fresh() ? tickProgress : fallback;
    }

    public static double x() {
        return x;
    }

    public static double y() {
        return y;
    }

    public static double z() {
        return z;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }

    /** FOV efectivo en grados del ultimo getFov(changingFov=true), o -1 si no se pudo capturar. */
    public static double fov() {
        return fov;
    }
}
