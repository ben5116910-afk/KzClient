package com.kzclient.auth;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kzclient.config.ListFiles;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Almacen cifrado de tokens de refresco (config/kzclient/tokens.vault). Nunca escribe en claro. */
public final class TokenVault {
    private static final Path FILE = ListFiles.dir().resolve("tokens.vault");

    private TokenVault() {
    }

    private static synchronized JsonObject read() throws IOException {
        if (!Files.exists(FILE)) {
            return new JsonObject();
        }
        String plain = SecureStore.unprotect(Files.readString(FILE, StandardCharsets.UTF_8).trim());
        return JsonParser.parseString(plain).getAsJsonObject();
    }

    private static synchronized void write(JsonObject object) throws IOException {
        Files.createDirectories(FILE.getParent());
        Files.writeString(FILE, SecureStore.protect(object.toString()), StandardCharsets.UTF_8);
    }

    public static synchronized String get(String key) {
        try {
            JsonObject object = read();
            return object.has(key) ? object.get(key).getAsString() : null;
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }

    public static synchronized void put(String key, String value) throws IOException {
        JsonObject object;
        try {
            object = read();
        } catch (IOException | RuntimeException ex) {
            object = new JsonObject();
        }
        object.addProperty(key, value);
        write(object);
    }

    public static synchronized void remove(String key) {
        try {
            JsonObject object = read();
            object.remove(key);
            write(object);
        } catch (IOException | RuntimeException ex) {
            // nada que borrar
        }
    }
}
