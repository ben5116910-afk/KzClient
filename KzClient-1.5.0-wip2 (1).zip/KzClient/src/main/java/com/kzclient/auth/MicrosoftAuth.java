package com.kzclient.auth;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Cadena oficial de autenticacion de Minecraft Java: Microsoft (device code) -> Xbox Live ->
 * XSTS -> Minecraft Services. Requiere una aplicacion de Azure (client id) aprobada por Mojang.
 */
public final class MicrosoftAuth {
    private static final String SCOPE = "XboxLive.signin offline_access";
    private static final String TENANT = "https://login.microsoftonline.com/consumers/oauth2/v2.0/";

    public record DeviceCode(String userCode, String verificationUri, String deviceCode, int interval, int expiresIn) {
    }

    public record MsTokens(String access, String refresh) {
    }

    public record McSession(String token, String uuid, String name) {
    }

    private MicrosoftAuth() {
    }

    private static String text(JsonObject object, String key) {
        return object.has(key) && !object.get(key).isJsonNull() ? object.get(key).getAsString() : "";
    }

    public static DeviceCode requestDeviceCode(String clientId) throws IOException {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("client_id", clientId);
        form.put("scope", SCOPE);
        Http.Response response = Http.postForm(TENANT + "devicecode", form);
        if (response.status() != 200) {
            throw new IOException(text(response.json(), "error_description").isEmpty()
                    ? "Device code request failed (" + response.status() + ")"
                    : text(response.json(), "error_description"));
        }
        JsonObject json = response.json();
        return new DeviceCode(text(json, "user_code"), text(json, "verification_uri"), text(json, "device_code"),
                json.has("interval") ? json.get("interval").getAsInt() : 5,
                json.has("expires_in") ? json.get("expires_in").getAsInt() : 900);
    }

    /** Espera a que el usuario autorice el codigo (bloqueante). */
    public static MsTokens pollToken(String clientId, DeviceCode code) throws IOException {
        long deadline = System.currentTimeMillis() + code.expiresIn() * 1000L;
        int interval = Math.max(2, code.interval());
        while (System.currentTimeMillis() < deadline) {
            try {
                Thread.sleep(interval * 1000L);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                throw new IOException("Cancelled", ex);
            }
            Map<String, String> form = new LinkedHashMap<>();
            form.put("grant_type", "urn:ietf:params:oauth:grant-type:device_code");
            form.put("client_id", clientId);
            form.put("device_code", code.deviceCode());
            Http.Response response = Http.postForm(TENANT + "token", form);
            JsonObject json = response.json();
            if (response.status() == 200 && json.has("access_token")) {
                return new MsTokens(text(json, "access_token"), text(json, "refresh_token"));
            }
            String error = text(json, "error");
            if (error.equals("authorization_pending")) {
                continue;
            }
            if (error.equals("slow_down")) {
                interval += 5;
                continue;
            }
            throw new IOException(error.isEmpty() ? "Login failed" : error);
        }
        throw new IOException("The code expired");
    }

    public static MsTokens refresh(String clientId, String refreshToken) throws IOException {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("grant_type", "refresh_token");
        form.put("client_id", clientId);
        form.put("refresh_token", refreshToken);
        form.put("scope", SCOPE);
        Http.Response response = Http.postForm(TENANT + "token", form);
        if (response.status() != 200 || !response.json().has("access_token")) {
            throw new IOException("Session expired, sign in again");
        }
        JsonObject json = response.json();
        String newRefresh = text(json, "refresh_token");
        return new MsTokens(text(json, "access_token"), newRefresh.isEmpty() ? refreshToken : newRefresh);
    }

    public static McSession minecraftSession(String msAccessToken) throws IOException {
        JsonObject xblProps = new JsonObject();
        xblProps.addProperty("AuthMethod", "RPS");
        xblProps.addProperty("SiteName", "user.auth.xboxlive.com");
        xblProps.addProperty("RpsTicket", "d=" + msAccessToken);
        JsonObject xblBody = new JsonObject();
        xblBody.add("Properties", xblProps);
        xblBody.addProperty("RelyingParty", "http://auth.xboxlive.com");
        xblBody.addProperty("TokenType", "JWT");
        Http.Response xbl = Http.postJson("https://user.auth.xboxlive.com/user/authenticate", xblBody);
        if (xbl.status() != 200) {
            throw new IOException("Xbox Live authentication failed (" + xbl.status() + ")");
        }
        String xblToken = text(xbl.json(), "Token");

        JsonArray userTokens = new JsonArray();
        userTokens.add(xblToken);
        JsonObject xstsProps = new JsonObject();
        xstsProps.addProperty("SandboxId", "RETAIL");
        xstsProps.add("UserTokens", userTokens);
        JsonObject xstsBody = new JsonObject();
        xstsBody.add("Properties", xstsProps);
        xstsBody.addProperty("RelyingParty", "rp://api.minecraftservices.com/");
        xstsBody.addProperty("TokenType", "JWT");
        Http.Response xsts = Http.postJson("https://xsts.auth.xboxlive.com/xsts/authorize", xstsBody);
        if (xsts.status() != 200) {
            throw new IOException(xsts.status() == 401
                    ? "This Microsoft account has no Xbox profile or is restricted"
                    : "XSTS authorization failed (" + xsts.status() + ")");
        }
        String uhs = xsts.json().getAsJsonObject("DisplayClaims").getAsJsonArray("xui").get(0).getAsJsonObject()
                .get("uhs").getAsString();

        JsonObject mcBody = new JsonObject();
        mcBody.addProperty("identityToken", "XBL3.0 x=" + uhs + ";" + text(xsts.json(), "Token"));
        Http.Response login = Http.postJson("https://api.minecraftservices.com/authentication/login_with_xbox", mcBody);
        if (login.status() != 200 || !login.json().has("access_token")) {
            throw new IOException("Minecraft login failed (" + login.status() + "). The app may not be approved by Mojang.");
        }
        String mcToken = text(login.json(), "access_token");

        Http.Response profile = Http.get("https://api.minecraftservices.com/minecraft/profile", mcToken);
        if (profile.status() == 404) {
            throw new IOException("This account does not own Minecraft Java Edition");
        }
        if (profile.status() != 200) {
            throw new IOException("Could not read the Minecraft profile (" + profile.status() + ")");
        }
        return new McSession(mcToken, text(profile.json(), "id"), text(profile.json(), "name"));
    }
}
