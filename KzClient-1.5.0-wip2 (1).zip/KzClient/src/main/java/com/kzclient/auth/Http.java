package com.kzclient.auth;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

/** Cliente HTTP minimo para las integraciones (JSON y formularios). */
final class Http {
    record Response(int status, JsonObject json) {
    }

    private static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();

    private Http() {
    }

    static String form(Map<String, String> values) {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, String> entry : values.entrySet()) {
            if (builder.length() > 0) {
                builder.append('&');
            }
            builder.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8)).append('=')
                    .append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8));
        }
        return builder.toString();
    }

    private static Response send(HttpRequest request) throws IOException {
        try {
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject json = new JsonObject();
            String body = response.body();
            if (body != null && !body.isBlank()) {
                try {
                    JsonElement parsed = JsonParser.parseString(body);
                    if (parsed.isJsonObject()) {
                        json = parsed.getAsJsonObject();
                    }
                } catch (RuntimeException ignored) {
                    // cuerpo no JSON
                }
            }
            return new Response(response.statusCode(), json);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted", ex);
        }
    }

    static Response postForm(String url, Map<String, String> values) throws IOException {
        return send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form(values))).build());
    }

    static Response postJson(String url, JsonObject body) throws IOException {
        return send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("Content-Type", "application/json").header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString())).build());
    }

    static Response get(String url, String bearer) throws IOException {
        return send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("Authorization", "Bearer " + bearer).GET().build());
    }
}
