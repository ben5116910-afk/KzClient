package com.kzclient.auth;

import com.kzclient.KzClient;
import com.kzclient.config.SavedAccount;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

/** Inicio de sesion Microsoft y cambio de cuenta (en segundo plano, con estado observable por la GUI). */
public final class AccountService {
    public enum State {
        IDLE,
        WAITING_CODE,
        WORKING,
        DONE,
        ERROR
    }

    private static volatile State state = State.IDLE;
    private static volatile String message = "";
    private static volatile String userCode = "";
    private static volatile String verificationUri = "";
    private static volatile Thread worker;

    private AccountService() {
    }

    public static State state() {
        return state;
    }

    public static String message() {
        return message;
    }

    public static String userCode() {
        return userCode;
    }

    public static String verificationUri() {
        return verificationUri;
    }

    public static boolean busy() {
        return state == State.WAITING_CODE || state == State.WORKING;
    }

    public static void cancel() {
        Thread thread = worker;
        if (thread != null) {
            thread.interrupt();
        }
        state = State.IDLE;
        message = "";
    }

    /** Alta de una cuenta nueva con el flujo de codigo de dispositivo. */
    public static void signIn(String clientId) {
        if (busy()) {
            return;
        }
        if (clientId == null || clientId.isBlank()) {
            state = State.ERROR;
            message = "Set your Microsoft app (client) ID in SETTINGS > Integrations first.";
            return;
        }
        run(() -> {
            MicrosoftAuth.DeviceCode code = MicrosoftAuth.requestDeviceCode(clientId.trim());
            userCode = code.userCode();
            verificationUri = code.verificationUri();
            message = "Open the link and enter the code.";
            state = State.WAITING_CODE;
            MicrosoftAuth.MsTokens tokens = MicrosoftAuth.pollToken(clientId.trim(), code);
            state = State.WORKING;
            message = "Signing in to Minecraft...";
            MicrosoftAuth.McSession session = MicrosoftAuth.minecraftSession(tokens.access());
            TokenVault.put("ms:" + session.uuid(), tokens.refresh());
            finish(session, true);
        });
    }

    /** Cambia a una cuenta ya vinculada usando su token de refresco cifrado. */
    public static void switchTo(SavedAccount account) {
        if (busy()) {
            return;
        }
        String clientId = KzClient.settings().msClientId;
        run(() -> {
            state = State.WORKING;
            message = "Switching to " + account.username() + "...";
            String refresh = TokenVault.get("ms:" + account.uuid());
            if (refresh == null || clientId.isBlank()) {
                throw new IOException("No stored session for this account. Add it again.");
            }
            MicrosoftAuth.MsTokens tokens = MicrosoftAuth.refresh(clientId.trim(), refresh);
            TokenVault.put("ms:" + account.uuid(), tokens.refresh());
            finish(MicrosoftAuth.minecraftSession(tokens.access()), false);
        });
    }

    public static void forget(SavedAccount account) {
        TokenVault.remove("ms:" + account.uuid());
    }

    private interface Job {
        void run() throws IOException;
    }

    private static void run(Job job) {
        state = State.WORKING;
        message = "Contacting Microsoft...";
        userCode = "";
        verificationUri = "";
        Thread thread = new Thread(() -> {
            try {
                job.run();
            } catch (IOException | RuntimeException ex) {
                if (state != State.IDLE) {
                    state = State.ERROR;
                    message = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                }
            }
        }, "KzClient-Auth");
        thread.setDaemon(true);
        worker = thread;
        thread.start();
    }

    private static void finish(MicrosoftAuth.McSession session, boolean remember) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            String error = applySession(session.name(), session.uuid(), session.token());
            if (error != null) {
                state = State.ERROR;
                message = "Could not apply the session: " + error;
                return;
            }
            if (remember) {
                KzClient.settings().accounts.removeIf(a -> a.uuid().equals(session.uuid()));
                KzClient.settings().accounts.add(new SavedAccount(session.name(), session.uuid()));
                KzClient.config().save();
            }
            state = State.DONE;
            message = "Signed in as " + session.name();
        });
    }

    /**
     * Reemplaza la sesion del cliente. El constructor de Session se resuelve por reflexion
     * (cambia entre versiones): usa (nombre, uuid, token, ...) y rellena el resto.
     */
    public static String applySession(String username, String undashedUuid, String token) {
        try {
            String clean = undashedUuid.replace("-", "");
            UUID uuid = UUID.fromString(clean.replaceFirst(
                    "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));
            for (Constructor<?> constructor : Session.class.getDeclaredConstructors()) {
                Class<?>[] types = constructor.getParameterTypes();
                if (types.length < 3 || types[0] != String.class || types[1] != UUID.class || types[2] != String.class) {
                    continue;
                }
                Object[] args = new Object[types.length];
                args[0] = username;
                args[1] = uuid;
                args[2] = token;
                for (int i = 3; i < types.length; i++) {
                    if (types[i] == Optional.class) {
                        args[i] = Optional.empty();
                    } else if (types[i].isEnum()) {
                        args[i] = pickEnum(types[i]);
                    }
                }
                constructor.setAccessible(true);
                Session session = (Session) constructor.newInstance(args);
                ((SessionSetter) (Object) MinecraftClient.getInstance()).kz$setSession(session);
                return null;
            }
            return "No compatible Session constructor";
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
            return ex.getClass().getSimpleName();
        }
    }

    private static Object pickEnum(Class<?> type) {
        Object[] constants = type.getEnumConstants();
        for (Object constant : constants) {
            if (constant.toString().equals("MSA")) {
                return constant;
            }
        }
        return constants[0];
    }
}
