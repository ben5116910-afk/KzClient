package com.kzclient.auth;

import net.minecraft.client.session.Session;

/** Interfaz que MinecraftClientMixin anade a MinecraftClient (fuera del paquete de mixins a proposito). */
public interface SessionSetter {
    void kz$setSession(Session session);
}
