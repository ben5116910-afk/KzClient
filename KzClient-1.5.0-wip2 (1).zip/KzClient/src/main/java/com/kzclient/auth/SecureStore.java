package com.kzclient.auth;

import com.kzclient.config.ListFiles;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Cifrado de secretos. En Windows usa DPAPI (CurrentUser) via PowerShell: solo tu usuario de
 * Windows puede descifrarlo. En otros sistemas usa AES-GCM con una clave local (.vault.key,
 * permisos 600), que protege de lecturas casuales pero no de malware con tu mismo usuario.
 */
public final class SecureStore {
    private static final String PROTECT = "Add-Type -AssemblyName System.Security; "
            + "$in=[Console]::In.ReadToEnd().Trim(); $b=[Convert]::FromBase64String($in); "
            + "$e=[System.Security.Cryptography.ProtectedData]::Protect($b,$null,"
            + "[System.Security.Cryptography.DataProtectionScope]::CurrentUser); [Convert]::ToBase64String($e)";
    private static final String UNPROTECT = "Add-Type -AssemblyName System.Security; "
            + "$in=[Console]::In.ReadToEnd().Trim(); $b=[Convert]::FromBase64String($in); "
            + "$e=[System.Security.Cryptography.ProtectedData]::Unprotect($b,$null,"
            + "[System.Security.Cryptography.DataProtectionScope]::CurrentUser); [Convert]::ToBase64String($e)";

    private SecureStore() {
    }

    private static boolean windows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    public static String protect(String plain) throws IOException {
        byte[] data = plain.getBytes(StandardCharsets.UTF_8);
        if (windows()) {
            return "dpapi:" + powershell(PROTECT, Base64.getEncoder().encodeToString(data));
        }
        try {
            byte[] iv = new byte[12];
            new SecureRandom().nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key(), "AES"), new GCMParameterSpec(128, iv));
            byte[] encrypted = cipher.doFinal(data);
            byte[] all = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(encrypted, 0, all, iv.length, encrypted.length);
            return "aes:" + Base64.getEncoder().encodeToString(all);
        } catch (GeneralSecurityException ex) {
            throw new IOException("Encryption failed", ex);
        }
    }

    public static String unprotect(String stored) throws IOException {
        if (stored.startsWith("dpapi:")) {
            String out = powershell(UNPROTECT, stored.substring(6));
            return new String(Base64.getDecoder().decode(out), StandardCharsets.UTF_8);
        }
        if (stored.startsWith("aes:")) {
            try {
                byte[] all = Base64.getDecoder().decode(stored.substring(4));
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key(), "AES"),
                        new GCMParameterSpec(128, all, 0, 12));
                return new String(cipher.doFinal(all, 12, all.length - 12), StandardCharsets.UTF_8);
            } catch (GeneralSecurityException ex) {
                throw new IOException("Decryption failed", ex);
            }
        }
        throw new IOException("Unknown vault format");
    }

    private static byte[] key() throws IOException {
        Path file = ListFiles.dir().resolve(".vault.key");
        if (Files.exists(file)) {
            return Base64.getDecoder().decode(Files.readString(file, StandardCharsets.UTF_8).trim());
        }
        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);
        Files.createDirectories(file.getParent());
        Files.writeString(file, Base64.getEncoder().encodeToString(key), StandardCharsets.UTF_8);
        try {
            Files.setPosixFilePermissions(file, PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException ignored) {
            // sistemas de archivos sin permisos POSIX
        }
        return key;
    }

    private static String powershell(String script, String stdin) throws IOException {
        Process process = new ProcessBuilder("powershell", "-NoProfile", "-NonInteractive", "-Command", script)
                .redirectErrorStream(true).start();
        try (OutputStream out = process.getOutputStream()) {
            out.write(stdin.getBytes(StandardCharsets.UTF_8));
        }
        try {
            if (!process.waitFor(20, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                throw new IOException("PowerShell timed out");
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted", ex);
        }
        String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        if (process.exitValue() != 0 || output.isEmpty()) {
            throw new IOException("DPAPI failed");
        }
        return output;
    }
}
