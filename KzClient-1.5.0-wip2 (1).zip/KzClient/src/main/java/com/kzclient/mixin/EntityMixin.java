package com.kzclient.mixin;

import com.kzclient.KzClient;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.Freecam;
import com.kzclient.module.modules.Hitbox;
import com.kzclient.module.modules.PlayerEsp;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** Hitboxes: amplia el margen de seleccion de la entidad. */
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void kz$targetingMargin(CallbackInfoReturnable<Float> cir) {
        ModuleManager manager = KzClient.modules();
        if (manager == null) {
            return;
        }
        Hitbox hitbox = manager.get(Hitbox.class);
        if (hitbox != null && hitbox.isEnabled()) {
            cir.setReturnValue(cir.getReturnValue() + hitbox.margin((Entity) (Object) this));
        }
    }

    /** PlayerESP: contorno brillante en el cliente. */
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void kz$glowing(CallbackInfoReturnable<Boolean> cir) {
        ModuleManager manager = KzClient.modules();
        if (manager == null) {
            return;
        }
        PlayerEsp esp = manager.get(PlayerEsp.class);
        if (esp != null && esp.isEnabled() && esp.shouldGlow((Entity) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void kz$teamColor(CallbackInfoReturnable<Integer> cir) {
        ModuleManager manager = KzClient.modules();
        if (manager == null) {
            return;
        }
        PlayerEsp esp = manager.get(PlayerEsp.class);
        if (esp != null && esp.isEnabled() && esp.shouldGlow((Entity) (Object) this)) {
            cir.setReturnValue(esp.colorFor((Entity) (Object) this));
        }
    }

    /** Freecam: el raton gira la camara en lugar del jugador. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void kz$lookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        ModuleManager manager = KzClient.modules();
        if (manager == null) {
            return;
        }
        Freecam freecam = manager.get(Freecam.class);
        if (freecam != null && freecam.isEnabled() && (Object) this == MinecraftClient.getInstance().player) {
            freecam.rotate(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }
}
