package com.kzclient.mixin;

import com.kzclient.KzClient;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.CustomBlockOutline;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private int kz$outlineColor(int color) {
        CustomBlockOutline outline = outline();
        return outline != null && outline.isEnabled() ? outline.argb() : color;
    }

    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float kz$outlineWidth(float width) {
        CustomBlockOutline outline = outline();
        return outline != null && outline.isEnabled() ? outline.lineWidth() : width;
    }

    private static CustomBlockOutline outline() {
        ModuleManager manager = KzClient.modules();
        return manager == null ? null : manager.get(CustomBlockOutline.class);
    }
}
