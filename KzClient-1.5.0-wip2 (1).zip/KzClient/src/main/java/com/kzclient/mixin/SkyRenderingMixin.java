package com.kzclient.mixin;

import com.kzclient.KzClient;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.Sky;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * En 1.21.11 ClientWorld.getSkyColor ya no existe: el color del cielo se calcula en
 * SkyRendering.updateRenderState(ClientWorld, float, Camera, SkyRenderState) (verificado en Yarn 1.21.11)
 * y se guarda en SkyRenderState.skyColor. Se sobrescribe al final de esa actualizacion.
 */
@Mixin(SkyRendering.class)
public abstract class SkyRenderingMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void kz$skyColor(ClientWorld world, float tickProgress, Camera camera, SkyRenderState state,
                             CallbackInfo ci) {
        ModuleManager manager = KzClient.modules();
        if (manager == null) {
            return;
        }
        Sky sky = manager.get(Sky.class);
        if (sky != null && sky.isEnabled()) {
            state.skyColor = sky.argb();
        }
    }
}
