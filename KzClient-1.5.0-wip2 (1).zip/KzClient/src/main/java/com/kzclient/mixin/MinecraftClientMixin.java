package com.kzclient.mixin;

import com.kzclient.auth.SessionSetter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

/** Permite al Account Switcher reemplazar la sesion de MinecraftClient (campo "session"). */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin implements SessionSetter {
    @Shadow
    @Final
    @Mutable
    private Session session;

    @Override
    public void kz$setSession(Session value) {
        this.session = value;
    }
}
