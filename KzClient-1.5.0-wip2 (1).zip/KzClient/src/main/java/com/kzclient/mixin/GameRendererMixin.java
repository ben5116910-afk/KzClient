package com.kzclient.mixin;

import com.kzclient.render.FrameCamera;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Captura el FOV efectivo del mundo (incluye sprint, pociones y zoom). Se acepta Object como retorno
 * para no depender de si getFov devuelve float o double en esta version.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"))
    private void kz$captureFov(Camera camera, float tickProgress, boolean changingFov,
                               CallbackInfoReturnable<Object> cir) {
        if (changingFov && cir.getReturnValue() instanceof Number number) {
            FrameCamera.captureFov(number.doubleValue());
        }
    }
}
