package com.kzclient.mixin;

import com.kzclient.KzClient;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.Freecam;
import com.kzclient.render.FrameCamera;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    /**
     * Camera.getPos() no existe con ese nombre en 1.21.11, asi que la posicion se toma de la propia llamada a
     * setPos (Camera.update la usa para fijar la posicion final y Freecam tambien). El ultimo valor recibido
     * es la posicion de la camara de este fotograma.
     */
    @Inject(method = "setPos", at = @At("HEAD"))
    private void kz$trackPos(double x, double y, double z, CallbackInfo ci) {
        FrameCamera.pendingPos(x, y, z);
    }

    /** Aplica Freecam y despues captura la camara FINAL del fotograma (posicion, angulos y tickProgress). */
    @Inject(method = "update", at = @At("TAIL"))
    private void kz$afterUpdate(World area, Entity focusedEntity, boolean thirdPerson, boolean inverseView,
                                float tickProgress, CallbackInfo ci) {
        ModuleManager manager = KzClient.modules();
        if (manager != null) {
            Freecam freecam = manager.get(Freecam.class);
            if (freecam != null && freecam.isEnabled()) {
                setPos(freecam.x(tickProgress), freecam.y(tickProgress), freecam.z(tickProgress));
                setRotation(freecam.yaw(), freecam.pitch());
            }
        }
        FrameCamera.captureFrame(getYaw(), getPitch(), tickProgress);
    }
}
