package com.kzclient.input;

import com.kzclient.KzClient;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Teclas del cliente (leidas por GLFW; solo se disparan sin pantalla abierta). */
public final class KeybindManager {
    public enum Action {
        OPEN_GUI("Open panel", GLFW.GLFW_KEY_RIGHT_SHIFT),
        PANIC("Panic", GLFW.GLFW_KEY_END),
        HUD_EDITOR("HUD editor", GLFW.GLFW_KEY_UNKNOWN);

        private final String label;
        private final int defaultKey;

        Action(String label, int defaultKey) {
            this.label = label;
            this.defaultKey = defaultKey;
        }

        public String label() {
            return label;
        }
    }

    private final Map<Action, Integer> keys = new EnumMap<>(Action.class);
    private final Map<Action, Boolean> down = new EnumMap<>(Action.class);

    public KeybindManager() {
        for (Action action : Action.values()) {
            keys.put(action, action.defaultKey);
            down.put(action, Boolean.FALSE);
        }
    }

    public int key(Action action) {
        return keys.get(action);
    }

    public void set(Action action, int key) {
        keys.put(action, key);
    }

    public static boolean isDown(int key) {
        if (key <= 0) {
            return false;
        }
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
    }

    public void tick(MinecraftClient mc) {
        boolean free = mc.currentScreen == null && mc.getWindow() != null;
        for (Action action : Action.values()) {
            boolean now = isDown(keys.get(action));
            boolean before = down.get(action);
            down.put(action, now);
            if (free && now && !before) {
                KzClient.fire(action);
            }
        }
        // teclas de los modulos (KeySetting "Keybind" de cada tarjeta)
        for (com.kzclient.module.Module module : KzClient.modules().all()) {
            com.kzclient.module.setting.KeySetting bind = module.bind();
            boolean pressed = bind.edge(isDown(bind.get()));
            if (free && pressed) {
                module.toggle();
            }
        }
    }
}
