package com.kzclient;

import com.kzclient.config.ClientSettings;
import com.kzclient.config.ConfigManager;
import com.kzclient.config.PlayerLists;
import com.kzclient.social.FriendsManager;
import com.kzclient.event.ClientTickEvent;
import com.kzclient.event.DisconnectEvent;
import com.kzclient.event.EventBus;
import com.kzclient.gui.ClickGuiScreen;
import com.kzclient.gui.OnboardingScreen;
import com.kzclient.hud.HudManager;
import com.kzclient.input.KeybindManager;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.modules.HitParticles;
import com.kzclient.gui.ThemePalette;
import com.kzclient.module.modules.NameChanger;
import com.kzclient.util.ColorUtil;
import com.kzclient.notify.NotificationManager;
import com.kzclient.render.WorldOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class KzClient implements ClientModInitializer {
    public static final String MOD_ID = "kzclient";
    public static final Logger LOGGER = LoggerFactory.getLogger("KzClient");

    private static EventBus bus;
    private static ModuleManager modules;
    private static HudManager hud;
    private static ConfigManager config;
    private static ClientSettings settings;
    private static KeybindManager keybinds;
    private static NotificationManager notifications;
    private static FriendsManager friends;
    private static WorldOverlay overlay;
    private static PlayerLists lists;
    private static int autosaveTicks;

    public static EventBus bus() {
        return bus;
    }

    public static ModuleManager modules() {
        return modules;
    }

    public static HudManager hud() {
        return hud;
    }

    public static ConfigManager config() {
        return config;
    }

    public static ClientSettings settings() {
        return settings;
    }

    public static KeybindManager keybinds() {
        return keybinds;
    }

    public static NotificationManager notifications() {
        return notifications;
    }

    public static FriendsManager friends() {
        return friends;
    }

    public static PlayerLists lists() {
        return lists;
    }

    /** Aplica el color de acento elegido en SETTINGS. */
    public static void applyTheme() {
        if (settings.customAccent) {
            ThemePalette.setAccent(ColorUtil.hsv(settings.accentHue, 0.7f, 1f));
        } else {
            ThemePalette.setAccent(ThemePalette.DEFAULT_ACCENT);
        }
    }

    /** Nombre del cliente mostrado en la UI (NameChanger lo sustituye por "YOUR NAME"). */
    public static String brand(boolean watermark) {
        if (modules != null && settings != null && !settings.displayName.isBlank()) {
            NameChanger changer = modules.get(NameChanger.class);
            if (changer != null && changer.isEnabled()) {
                String custom = changer.apply(settings.displayName, watermark);
                if (custom != null) {
                    return custom;
                }
            }
        }
        return "KzClient";
    }

    public static void openGui(int tab) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.setScreen(settings.onboarded ? new ClickGuiScreen(tab) : new OnboardingScreen());
    }

    public static void fire(KeybindManager.Action action) {
        MinecraftClient mc = MinecraftClient.getInstance();
        switch (action) {
            case OPEN_GUI -> openGui(ClickGuiScreen.TAB_MODULES);
            case HUD_EDITOR -> openGui(ClickGuiScreen.TAB_HUD);
            case PANIC -> modules.panic().toggle();
            default -> {
            }
        }
    }

    @Override
    public void onInitializeClient() {
        bus = new EventBus();
        notifications = new NotificationManager();
        settings = new ClientSettings();
        keybinds = new KeybindManager();
        overlay = new WorldOverlay();
        hud = new HudManager();
        lists = new PlayerLists();
        lists.load();
        friends = new FriendsManager();
        friends.load();
        modules = new ModuleManager(bus);
        com.kzclient.feature.FeatureLoader.initAll();
        config = new ConfigManager(modules, hud, settings, keybinds);
        config.load();
        applyTheme();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            keybinds.tick(client);
            bus.post(new ClientTickEvent(client));
            if (settings.autosave && ++autosaveTicks >= 2400) {
                autosaveTicks = 0;
                config.save();
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> bus.post(new DisconnectEvent()));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> config.save());

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient()) {
                HitParticles particles = modules.get(HitParticles.class);
                if (particles.isEnabled()) {
                    particles.burst(entity);
                }
            }
            return ActionResult.PASS;
        });

        HudElementRegistry.addLast(Identifier.of(MOD_ID, "hud"), (context, tickCounter) -> {
            overlay.render(context, tickCounter.getTickProgress(false));
            hud.render(context);
            modules.panic().renderIndicator(context);
        });

        LOGGER.info("KzClient inicializado para Minecraft 1.21.11");
    }
}
