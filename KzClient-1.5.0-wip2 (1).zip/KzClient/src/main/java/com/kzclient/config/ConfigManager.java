package com.kzclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kzclient.KzClient;
import com.kzclient.hud.HudManager;
import com.kzclient.hud.HudWidget;
import com.kzclient.input.KeybindManager;
import com.kzclient.module.Module;
import com.kzclient.module.ModuleManager;
import com.kzclient.module.setting.Setting;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/**
 * Guarda y carga todo en config/kzclient/config.json y permite perfiles con nombre en
 * config/kzclient/profiles/. Los perfiles guardan modulos, HUD y apariencia; no cuentas ni claves.
 */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final ModuleManager modules;
    private final HudManager hud;
    private final ClientSettings settings;
    private final KeybindManager keybinds;
    private final Path file = ListFiles.dir().resolve("config.json");
    private final Path profileDir = ListFiles.dir().resolve("profiles");

    public ConfigManager(ModuleManager modules, HudManager hud, ClientSettings settings, KeybindManager keybinds) {
        this.modules = modules;
        this.hud = hud;
        this.settings = settings;
        this.keybinds = keybinds;
    }

    // ------------------------------------------------------------ escritura

    private JsonObject build(boolean full) {
        JsonObject root = new JsonObject();

        JsonObject client = new JsonObject();
        client.addProperty("panelLayout", settings.panelLayout);
        client.addProperty("uiScale", settings.uiScale);
        client.addProperty("opacity", settings.opacity);
        client.addProperty("customAccent", settings.customAccent);
        client.addProperty("accentHue", settings.accentHue);
        client.addProperty("notifications", settings.notifications);
        client.addProperty("autosave", settings.autosave);
        if (full) {
            client.addProperty("displayName", settings.displayName);
            client.addProperty("onboarded", settings.onboarded);
            client.addProperty("registeredAt", settings.registeredAt);
            client.addProperty("msClientId", settings.msClientId);
            JsonObject keys = new JsonObject();
            for (KeybindManager.Action action : KeybindManager.Action.values()) {
                keys.addProperty(action.name(), keybinds.key(action));
            }
            client.add("keys", keys);
            JsonArray accounts = new JsonArray();
            for (SavedAccount account : settings.accounts) {
                JsonObject entry = new JsonObject();
                entry.addProperty("username", account.username());
                entry.addProperty("uuid", account.uuid());
                accounts.add(entry);
            }
            client.add("accounts", accounts);
        }
        root.add("client", client);

        JsonObject moduleObject = new JsonObject();
        for (Module module : modules.all()) {
            JsonObject entry = new JsonObject();
            entry.addProperty("enabled", module.isPersistent() && modules.panic().persistedEnabled(module));
            JsonObject values = new JsonObject();
            for (Setting setting : module.settings()) {
                values.add(setting.name(), setting.save());
            }
            entry.add("settings", values);
            moduleObject.add(module.name(), entry);
        }
        root.add("modules", moduleObject);

        JsonObject hudObject = new JsonObject();
        hudObject.addProperty("enabled", modules.panic().persistedHud(hud.isEnabled()));
        JsonObject widgets = new JsonObject();
        for (HudWidget widget : hud.widgets()) {
            JsonObject entry = new JsonObject();
            entry.addProperty("enabled", widget.isEnabled());
            entry.addProperty("x", widget.x());
            entry.addProperty("y", widget.y());
            JsonObject values = new JsonObject();
            for (Setting setting : widget.settings()) {
                values.add(setting.name(), setting.save());
            }
            entry.add("settings", values);
            widgets.add(widget.id(), entry);
        }
        hudObject.add("widgets", widgets);
        root.add("hud", hudObject);
        return root;
    }

    private void write(Path target, JsonObject root) {
        try {
            Files.createDirectories(target.getParent());
            // escritura atomica: primero un temporal y despues se reemplaza, para no dejar un archivo a medias
            Path temp = target.resolveSibling(target.getFileName() + ".tmp");
            try (Writer writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
            try {
                Files.move(temp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(temp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            KzClient.LOGGER.error("No se pudo guardar {}", target, ex);
        }
    }

    public void save() {
        write(file, build(true));
    }

    // -------------------------------------------------------------- lectura

    public void load() {
        read(file, true);
    }

    private boolean read(Path source, boolean full) {
        if (!Files.exists(source)) {
            return false;
        }
        try (Reader reader = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) {
                return false;
            }
            JsonObject root = parsed.getAsJsonObject();
            applyClient(root, full);
            applyModules(root);
            applyHud(root);
            return true;
        } catch (IOException | RuntimeException ex) {
            KzClient.LOGGER.error("No se pudo leer {}", source, ex);
            backupCorrupt(source);
            return false;
        }
    }

    /** Un archivo ilegible se conserva como .corrupt-<fecha> para que el siguiente guardado no lo destruya. */
    private static void backupCorrupt(Path source) {
        try {
            Path copy = source.resolveSibling(source.getFileName() + ".corrupt-" + System.currentTimeMillis());
            Files.copy(source, copy, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            KzClient.LOGGER.warn("Copia del archivo corrupto en {}", copy);
        } catch (IOException | RuntimeException ignored) {
            // si ni siquiera se puede copiar, se continua con los valores por defecto
        }
    }

    private static JsonObject object(JsonObject parent, String key) {
        return parent.has(key) && parent.get(key).isJsonObject() ? parent.getAsJsonObject(key) : null;
    }

    private void applyClient(JsonObject root, boolean full) {
        JsonObject client = object(root, "client");
        if (client == null) {
            return;
        }
        if (client.has("panelLayout")) {
            settings.panelLayout = client.get("panelLayout").getAsBoolean();
        }
        if (client.has("uiScale")) {
            settings.uiScale = Math.max(0.7f, Math.min(1.4f, client.get("uiScale").getAsFloat()));
        }
        if (client.has("opacity")) {
            settings.opacity = Math.max(40, Math.min(100, client.get("opacity").getAsInt()));
        }
        if (client.has("customAccent")) {
            settings.customAccent = client.get("customAccent").getAsBoolean();
        }
        if (client.has("accentHue")) {
            settings.accentHue = client.get("accentHue").getAsInt();
        }
        if (client.has("notifications")) {
            settings.notifications = client.get("notifications").getAsBoolean();
        }
        if (client.has("autosave")) {
            settings.autosave = client.get("autosave").getAsBoolean();
        }
        if (!full) {
            return;
        }
        if (client.has("displayName")) {
            settings.displayName = client.get("displayName").getAsString();
        }
        if (client.has("onboarded")) {
            settings.onboarded = client.get("onboarded").getAsBoolean();
        }
        if (client.has("registeredAt")) {
            settings.registeredAt = client.get("registeredAt").getAsLong();
        }
        if (client.has("msClientId")) {
            settings.msClientId = client.get("msClientId").getAsString();
        }
        JsonObject keys = object(client, "keys");
        if (keys != null) {
            for (KeybindManager.Action action : KeybindManager.Action.values()) {
                if (keys.has(action.name())) {
                    keybinds.set(action, keys.get(action.name()).getAsInt());
                }
            }
        }
        if (client.has("accounts") && client.get("accounts").isJsonArray()) {
            settings.accounts.clear();
            for (JsonElement element : client.getAsJsonArray("accounts")) {
                if (element.isJsonObject()) {
                    JsonObject entry = element.getAsJsonObject();
                    if (entry.has("username") && entry.has("uuid")) {
                        settings.accounts.add(new SavedAccount(entry.get("username").getAsString(),
                                entry.get("uuid").getAsString()));
                    }
                }
            }
        }
    }

    private void applyModules(JsonObject root) {
        JsonObject moduleObject = object(root, "modules");
        if (moduleObject == null) {
            return;
        }
        for (Module module : modules.all()) {
            JsonObject entry = object(moduleObject, module.name());
            if (entry == null) {
                continue;
            }
            if (module.isPersistent() && entry.has("enabled") && entry.get("enabled").isJsonPrimitive()) {
                module.restoreEnabled(entry.get("enabled").getAsBoolean());
            }
            JsonObject values = object(entry, "settings");
            if (values != null) {
                for (Setting setting : module.settings()) {
                    if (values.has(setting.name())) {
                        setting.load(values.get(setting.name()));
                    }
                }
            }
        }
    }

    private void applyHud(JsonObject root) {
        JsonObject hudObject = object(root, "hud");
        if (hudObject == null) {
            return;
        }
        if (hudObject.has("enabled") && hudObject.get("enabled").isJsonPrimitive()) {
            hud.setEnabled(hudObject.get("enabled").getAsBoolean());
        }
        JsonObject widgets = object(hudObject, "widgets");
        if (widgets == null) {
            return;
        }
        for (HudWidget widget : hud.widgets()) {
            JsonObject entry = object(widgets, widget.id());
            if (entry == null) {
                continue;
            }
            if (entry.has("enabled") && entry.get("enabled").isJsonPrimitive()) {
                widget.setEnabled(entry.get("enabled").getAsBoolean());
            }
            if (entry.has("x") && entry.has("y")) {
                widget.setPosition(entry.get("x").getAsInt(), entry.get("y").getAsInt());
            }
            JsonObject values = object(entry, "settings");
            if (values != null) {
                for (Setting setting : widget.settings()) {
                    if (values.has(setting.name())) {
                        setting.load(values.get(setting.name()));
                    }
                }
            }
        }
    }

    // ------------------------------------------------------ reset y perfiles

    /** Restablece modulos, HUD y apariencia (conserva nombre, cuentas, claves e integraciones). */
    public void resetAll() {
        for (Module module : modules.all()) {
            module.resetToDefaults();
        }
        hud.resetAll();
        settings.resetVisuals();
        KzClient.applyTheme();
        save();
    }

    private static String clean(String name) {
        return name.replaceAll("[^A-Za-z0-9_\\- ]", "").trim();
    }

    public boolean saveProfile(String name) {
        String clean = clean(name);
        if (clean.isEmpty()) {
            return false;
        }
        write(profileDir.resolve(clean + ".json"), build(false));
        return true;
    }

    public boolean loadProfile(String name) {
        String clean = clean(name);
        if (clean.isEmpty()) {
            return false;
        }
        for (Module module : modules.all()) {
            module.resetToDefaults();
        }
        boolean ok = read(profileDir.resolve(clean + ".json"), false);
        KzClient.applyTheme();
        save();
        return ok;
    }

    /** Renombra un perfil; false si el origen no existe, el nombre es invalido o el destino ya existe. */
    public boolean renameProfile(String from, String to) {
        String a = clean(from);
        String b = clean(to);
        if (a.isEmpty() || b.isEmpty() || a.equals(b)) {
            return false;
        }
        Path source = profileDir.resolve(a + ".json");
        Path target = profileDir.resolve(b + ".json");
        if (!Files.exists(source) || Files.exists(target)) {
            return false;
        }
        try {
            Files.move(source, target);
            return true;
        } catch (IOException ex) {
            KzClient.LOGGER.error("No se pudo renombrar el perfil", ex);
            return false;
        }
    }

    public void deleteProfile(String name) {
        try {
            Files.deleteIfExists(profileDir.resolve(clean(name) + ".json"));
        } catch (IOException ex) {
            KzClient.LOGGER.error("No se pudo borrar el perfil", ex);
        }
    }

    public List<String> profiles() {
        List<String> names = new ArrayList<>();
        if (Files.isDirectory(profileDir)) {
            try (Stream<Path> stream = Files.list(profileDir)) {
                stream.map(path -> path.getFileName().toString()).filter(n -> n.endsWith(".json"))
                        .forEach(n -> names.add(n.substring(0, n.length() - 5)));
            } catch (IOException ex) {
                return names;
            }
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return names;
    }
}
