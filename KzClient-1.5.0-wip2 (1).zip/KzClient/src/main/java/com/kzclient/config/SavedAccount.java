package com.kzclient.config;

/** Cuenta Microsoft vinculada (el token de refresco vive cifrado en TokenVault, nunca aqui). */
public record SavedAccount(String username, String uuid) {
}
