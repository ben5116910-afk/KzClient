package com.kzclient.config;

import java.util.ArrayList;
import java.util.List;

/** Ajustes globales del cliente (no pertenecen a ningun modulo). */
public final class ClientSettings {
    public String displayName = "";
    public boolean panelLayout = true;
    public boolean onboarded = false;
    public long registeredAt = 0L;
    public float uiScale = 1.0f;
    public int opacity = 96;
    public boolean customAccent = false;
    public int accentHue = 335;
    public boolean notifications = true;
    public boolean autosave = true;
    public String msClientId = "";
    public final List<SavedAccount> accounts = new ArrayList<>();

    /** Restablece lo visual y de comportamiento; conserva identidad, cuentas e integraciones. */
    public void resetVisuals() {
        panelLayout = true;
        uiScale = 1.0f;
        opacity = 96;
        customAccent = false;
        accentHue = 335;
        notifications = true;
        autosave = true;
    }
}
