package com.kzclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Listas de staff y amigos (config/kzclient/lists.json). */
public final class PlayerLists {
    public enum Kind {
        STAFF,
        FRIEND
    }

    private final Set<String> staff = new LinkedHashSet<>();
    private final Set<String> friends = new LinkedHashSet<>();
    private final Path file = ListFiles.dir().resolve("lists.json");

    private Set<String> set(Kind kind) {
        return kind == Kind.STAFF ? staff : friends;
    }

    public boolean isStaff(String name) {
        return contains(staff, name);
    }

    public boolean isFriend(String name) {
        return contains(friends, name);
    }

    private static boolean contains(Set<String> set, String name) {
        for (String entry : set) {
            if (entry.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean add(Kind kind, String name) {
        String clean = name.trim();
        if (clean.isEmpty() || clean.length() > 16 || contains(set(kind), clean)) {
            return false;
        }
        set(kind).add(clean);
        save();
        return true;
    }

    public void remove(Kind kind, String name) {
        set(kind).removeIf(entry -> entry.equalsIgnoreCase(name));
        save();
    }

    public List<String> list(Kind kind) {
        List<String> copy = new ArrayList<>(set(kind));
        Collections.sort(copy, String.CASE_INSENSITIVE_ORDER);
        return copy;
    }

    public void load() {
        staff.clear();
        friends.clear();
        if (!Files.exists(file)) {
            return;
        }
        try {
            JsonElement parsed = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8));
            if (parsed.isJsonObject()) {
                read(parsed.getAsJsonObject(), "staff", staff);
                read(parsed.getAsJsonObject(), "friends", friends);
            }
        } catch (IOException | RuntimeException ex) {
            staff.clear();
            friends.clear();
        }
    }

    private static void read(JsonObject root, String key, Set<String> target) {
        if (root.has(key) && root.get(key).isJsonArray()) {
            for (JsonElement element : root.getAsJsonArray(key)) {
                if (element.isJsonPrimitive()) {
                    target.add(element.getAsString().toLowerCase(Locale.ROOT).equals(element.getAsString())
                            ? element.getAsString() : element.getAsString());
                }
            }
        }
    }

    public void save() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject root = new JsonObject();
        JsonArray s = new JsonArray();
        staff.forEach(s::add);
        JsonArray f = new JsonArray();
        friends.forEach(f::add);
        root.add("staff", s);
        root.add("friends", f);
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, gson.toJson(root), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            // la lista sigue en memoria; se reintentara en el siguiente cambio
        }
    }
}
