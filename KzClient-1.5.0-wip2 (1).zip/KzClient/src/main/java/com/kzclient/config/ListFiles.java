package com.kzclient.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.loader.api.FabricLoader;

/** Listas editables por el usuario dentro de config/kzclient/. */
public final class ListFiles {
    private ListFiles() {
    }

    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("kzclient");
    }

    /** Lee un archivo de texto (una entrada por linea, # = comentario); lo crea con ayuda si no existe. */
    public static List<String> read(String fileName, String header) {
        Path file = dir().resolve(fileName);
        List<String> result = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            if (!Files.exists(file)) {
                Files.writeString(file, header + System.lineSeparator(), StandardCharsets.UTF_8);
                return result;
            }
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String trimmed = line.trim();
                if (!trimmed.isEmpty() && !trimmed.startsWith("#")) {
                    result.add(trimmed.toLowerCase(Locale.ROOT));
                }
            }
        } catch (IOException ex) {
            return result;
        }
        return result;
    }
}
