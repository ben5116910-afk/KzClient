package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.NumberSetting;

/** Fija el campo de vision (limite del juego: 30-110). */
public final class CustomFov extends Module {
    private final NumberSetting fov = add(new NumberSetting("FOV", 30, 110, 1, 90));
    private int previous = 70;

    public CustomFov() {
        super("CustomFOV", "Custom field of view.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        previous = mc.options.getFov().getValue();
    }

    @Override
    public void onTick() {
        if (mc.options.getFov().getValue() != fov.getInt()) {
            mc.options.getFov().setValue(fov.getInt());
        }
    }

    @Override
    protected void onDisable() {
        mc.options.getFov().setValue(previous);
    }
}
