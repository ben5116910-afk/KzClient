package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;

/** Cambia el color del cielo y de las nubes (SkyRenderingMixin). */
public final class Sky extends Module {
    private final NumberSetting hue = add(new NumberSetting("Hue", 0, 360, 1, 320));
    private final NumberSetting saturation = add(new NumberSetting("Saturation", 0.0, 1.0, 0.05, 0.6));
    private final NumberSetting brightness = add(new NumberSetting("Brightness", 0.1, 1.0, 0.05, 0.8));
    private final BoolSetting cycle = add(new BoolSetting("Color cycle", false));

    public Sky() {
        super("Sky", "Custom sky and atmosphere color.", Category.VISUALS);
    }

    public int argb() {
        float h = cycle.get() ? (System.currentTimeMillis() % 20000L) / 20000f * 360f : hue.getFloat();
        return ColorUtil.hsv(h, saturation.getFloat(), brightness.getFloat());
    }
}
