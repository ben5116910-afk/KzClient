package com.kzclient.module.modules;

import com.kzclient.KzClient;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;

/**
 * Ajustes de Panic. La logica vive en {@link com.kzclient.module.PanicController}. Este modulo es un disparador:
 * al activarlo (tecla propia de su tarjeta o la accion PANIC de Settings > Keybinds) inicia/termina Panic y
 * vuelve a quedar apagado.
 */
public final class Panic extends Module {
    private final BoolSetting allowed = add(new BoolSetting("Panic enabled", true));
    private final NumberSetting duration = add(new NumberSetting("Duration (s)", 5, 300, 5, 30));
    private final BoolSetting modules = add(new BoolSetting("Disable modules", true));
    private final BoolSetting hud = add(new BoolSetting("Hide HUD", true));
    private final BoolSetting toasts = add(new BoolSetting("Clear notifications", true));
    private final BoolSetting indicator = add(new BoolSetting("Show indicator", true));
    private final BoolSetting counter = add(new BoolSetting("Show countdown", true));

    public Panic() {
        super("Panic", "Temporarily disables modules and overlays, then restores them automatically.", Category.MISC);
        setSilent(true);
    }

    public boolean isAllowed() {
        return allowed.get();
    }

    public int durationSeconds() {
        return duration.getInt();
    }

    public boolean disableModules() {
        return modules.get();
    }

    public boolean hideHud() {
        return hud.get();
    }

    public boolean clearNotifications() {
        return toasts.get();
    }

    public boolean showIndicator() {
        return indicator.get();
    }

    public boolean showCounter() {
        return counter.get();
    }

    @Override
    public boolean isPersistent() {
        return false;
    }

    @Override
    protected void onEnable() {
        KzClient.modules().panic().toggle();
        setEnabled(false);
    }
}
