package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;

/** Controla las animaciones de apertura/cierre del panel y el fundido entre pestanas. */
public final class Animations extends Module {
    private final BoolSetting openClose = add(new BoolSetting("Open / close", true));
    private final BoolSetting tabFade = add(new BoolSetting("Tab fade", true));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 3.0, 0.5, 2.0));

    public Animations() {
        super("Animations", "Panel open/close and tab transitions.", Category.CLIENT);
        enableByDefault();
    }

    public boolean openClose() {
        return isEnabled() && openClose.get();
    }

    public boolean tabFade() {
        return isEnabled() && tabFade.get();
    }

    public double speed() {
        return speed.get() * 6.0;
    }
}
