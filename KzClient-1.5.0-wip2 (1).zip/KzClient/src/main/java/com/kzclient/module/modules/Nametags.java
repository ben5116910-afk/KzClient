package com.kzclient.module.modules;

import com.kzclient.gui.Render2D;
import com.kzclient.gui.ThemePalette;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ColorSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.render.Projector;
import com.kzclient.util.ColorUtil;
import com.kzclient.util.Targets;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Etiquetas sobre los jugadores. Cada fotograma se recalcula la posicion de pantalla desde la posicion
 * interpolada de la entidad (getLerpedPos(tickProgress)) con la camara real del fotograma (ver Projector),
 * sin guardar coordenadas de pantalla entre fotogramas. Solo se cachean textos y anchos (no posiciones).
 */
public final class Nametags extends Module {
    private static final int GOLD = 0xFFFFD04D;

    // ---- general
    private final ModeSetting style = add(new ModeSetting("Style", 0, "Modern", "Compact", "Minimal", "Neon"));
    private final NumberSetting range = add(new NumberSetting("Range", 8, 128, 8, 64));
    private final NumberSetting scale = add(new NumberSetting("Scale", 0.5, 2.5, 0.1, 1.0));
    private final NumberSetting fontSize = add(new NumberSetting("Font size", 0.7, 1.6, 0.1, 1.0));
    private final BoolSetting distScaling = add(new BoolSetting("Distance scaling", true));
    private final NumberSetting minScale = add(new NumberSetting("Min scale", 0.3, 1.0, 0.1, 0.6));
    private final NumberSetting height = add(new NumberSetting("Height offset", 0.0, 1.0, 0.05, 0.4));
    private final BoolSetting self = add(new BoolSetting("Own tag (3rd person)", false));

    // ---- informacion
    private final BoolSetting showName = add(new BoolSetting("Name", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final BoolSetting healthBar = add(new BoolSetting("Health bar", true));
    private final BoolSetting healthText = add(new BoolSetting("Health text", true));
    private final BoolSetting healthGradient = add(new BoolSetting("Health gradient", true));
    private final BoolSetting armor = add(new BoolSetting("Armor", true));
    private final BoolSetting durability = add(new BoolSetting("Durability", true));
    private final BoolSetting enchants = add(new BoolSetting("Enchants", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", false));
    private final BoolSetting sneakTag = add(new BoolSetting("Sneak tag", false));
    private final BoolSetting friendTint = add(new BoolSetting("Friends green", true));

    // ---- armadura por pieza (cada pieza se inspecciona y se dibuja por separado)
    private final BoolSetting showHeld = add(new BoolSetting("Held item row", true));
    private final BoolSetting pieceIcons = add(new BoolSetting("Piece icons", true));
    private final BoolSetting emptyPieces = add(new BoolSetting("Show pieces without enchants", true));
    private final BoolSetting levels = add(new BoolSetting("Enchant levels", true));
    private final ModeSetting levelFormat = add(new ModeSetting("Level format", 0, "Roman", "Number"));
    private final ModeSetting enchantNames = add(new ModeSetting("Enchant names", 0, "Abbreviated", "Full"));
    private final NumberSetting maxEnchants = add(new NumberSetting("Max enchants per piece", 1, 10, 1, 5));
    private final ModeSetting durabilityStyle = add(new ModeSetting("Durability style", 0, "Bar", "Percent", "Bar + percent"));
    private final NumberSetting armorScale = add(new NumberSetting("Armor scale", 0.5, 2.0, 0.1, 1.0));
    private final NumberSetting armorSpacing = add(new NumberSetting("Armor spacing", 0, 8, 1, 2));
    private final NumberSetting armorFont = add(new NumberSetting("Armor font size", 0.5, 1.5, 0.1, 0.8));

    // ---- apariencia
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 20, 100, 5, 90));
    private final BoolSetting background = add(new BoolSetting("Background", true));
    private final ColorSetting bgColor = add(new ColorSetting("Background color", 0x0D0812));
    private final BoolSetting border = add(new BoolSetting("Border", true));
    private final ColorSetting borderColor = add(new ColorSetting("Border color", 0xFF278F));
    private final NumberSetting radius = add(new NumberSetting("Corner radius", 0, 8, 1, 4));
    private final ColorSetting nameColor = add(new ColorSetting("Name color", 0xFF278F));
    private final ColorSetting friendColor = add(new ColorSetting("Friend color", 0x55FF9A));
    private final ColorSetting barColor = add(new ColorSetting("Bar color (no gradient)", 0x55FF9A));
    private final NumberSetting spacing = add(new NumberSetting("Spacing", 0, 6, 1, 2));

    // ---- animaciones y colocacion
    private final BoolSetting animate = add(new BoolSetting("Animations", true));
    private final BoolSetting fadeEdge = add(new BoolSetting("Fade at range edge", true));
    private final BoolSetting avoidOverlap = add(new BoolSetting("Avoid overlap", false));

    private final Map<UUID, State> states = new HashMap<>();
    private final List<State> visible = new ArrayList<>();
    private final double[] screen = new double[3];
    private long lastNanos;
    private int frame;

    /** Cache por jugador: textos, anchos y estado de animacion. Nunca guarda posiciones de pantalla persistentes. */
    private static final class State {
        String name = "";
        int nameW;
        String distText = "";
        int distW;
        int lastDist = -1;
        String pingText = "";
        int pingW;
        int lastPing = -2;
        String hpText = "";
        int hpW;
        float lastHp = -1f;
        float lastAbs = -1f;
        /** 0 = objeto en mano, 1..4 = casco, pechera, pantalones, botas. Cada una con SUS propios datos. */
        final Piece[] pieces = {new Piece(), new Piece(), new Piece(), new Piece(), new Piece()};
        float blockW;
        float blockH;
        float shownHealth = -1f;
        float appear;
        int seenFrame;
        int nameFrame = -1000;
        // valores de ESTE fotograma
        double sx;
        double sy;
        double depth;
        float s;
        float alpha;
        float w;
        float h;
        PlayerEntity player;
    }

    /** Un encantamiento de UNA pieza, ya con el texto formateado. */
    private static final class Ench {
        final String text;
        final int width;
        final int color;

        Ench(String text, int width, int color) {
            this.text = text;
            this.width = width;
            this.color = color;
        }
    }

    /** Datos de una pieza (o del objeto en mano). Se reconstruyen solo desde SU ItemStack cuando este cambia. */
    private static final class Piece {
        ItemStack stack = ItemStack.EMPTY;
        Item item;
        ItemEnchantmentsComponent component;
        int signature = -1;
        final List<Ench> list = new ArrayList<>(4);
        String more = "";
        int moreW;
        String durText = "";
        int durW;
        int lastDurPct = -1;
        boolean present;
        boolean hasEnchants;
        boolean shown;
        float rowW;
        float rowH;
        float textW;

        void clear() {
            stack = ItemStack.EMPTY;
            item = null;
            component = null;
            signature = -1;
            list.clear();
            more = "";
            moreW = 0;
            durText = "";
            durW = 0;
            lastDurPct = -1;
            present = false;
            hasEnchants = false;
            shown = false;
        }
    }

    public Nametags() {
        super("Nametags", "Health, armor, enchants and distance above players.", Category.VISUALS);
    }

    @Override
    protected void onDisable() {
        states.clear();
        visible.clear();
    }

    // ------------------------------------------------------------------ utilidades de encantamientos

    private static String shortName(String path) {
        return switch (path) {
            case "protection" -> "Prot";
            case "fire_protection" -> "FireP";
            case "blast_protection" -> "BlastP";
            case "projectile_protection" -> "ProjP";
            case "sharpness" -> "Sharp";
            case "unbreaking" -> "Unb";
            case "mending" -> "Mend";
            case "thorns" -> "Thorns";
            case "feather_falling" -> "FFall";
            case "efficiency" -> "Eff";
            case "power" -> "Power";
            case "sweeping_edge" -> "Sweep";
            case "fire_aspect" -> "FireA";
            case "knockback" -> "KB";
            case "looting" -> "Loot";
            case "density" -> "Dens";
            case "breach" -> "Breach";
            case "respiration" -> "Resp";
            case "aqua_affinity" -> "Aqua";
            case "depth_strider" -> "Depth";
            case "frost_walker" -> "Frost";
            case "soul_speed" -> "Soul";
            case "swift_sneak" -> "Swift";
            case "binding_curse" -> "Bind";
            case "vanishing_curse" -> "Van";
            case "silk_touch" -> "Silk";
            case "fortune" -> "Fort";
            case "smite" -> "Smite";
            case "bane_of_arthropods" -> "Bane";
            case "luck_of_the_sea" -> "Luck";
            case "lure" -> "Lure";
            case "riptide" -> "Ript";
            case "loyalty" -> "Loyal";
            case "impaling" -> "Impal";
            case "punch" -> "Punch";
            case "quick_charge" -> "QChrg";
            case "piercing" -> "Pierc";
            case "lunge" -> "Lunge";
            default -> path.length() > 5 ? Character.toUpperCase(path.charAt(0)) + path.substring(1, 5) : path;
        };
    }

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Map<String, String> FULL_NAMES = new HashMap<>();
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final int CURSE = 0xFFFF6B6B;

    /** Encantamientos de nivel unico en vanilla: no se muestra su nivel. */
    private static boolean singleLevel(String path) {
        return switch (path) {
            case "mending", "aqua_affinity", "silk_touch", "infinity", "flame", "channeling", "multishot",
                 "binding_curse", "vanishing_curse" -> true;
            default -> false;
        };
    }

    private static String fullName(String id, String path) {
        return FULL_NAMES.computeIfAbsent(id, key -> {
            int colon = key.indexOf(':');
            String ns = colon < 0 ? "minecraft" : key.substring(0, colon);
            String translationKey = "enchantment." + ns + "." + path;
            String translated = Text.translatable(translationKey).getString();
            if (!translated.equals(translationKey) && !translated.isBlank()) {
                return translated;
            }
            StringBuilder out = new StringBuilder();
            for (String word : path.split("_")) {
                if (word.isEmpty()) {
                    continue;
                }
                if (out.length() > 0) {
                    out.append(' ');
                }
                out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
            }
            return out.toString();
        });
    }

    private static String levelText(int level, boolean roman) {
        if (roman && level >= 1 && level < ROMAN.length) {
            return ROMAN[level];
        }
        return Integer.toString(level);
    }

    private static int sortKey(String path) {
        if (path.contains("protection")) {
            return 0;
        }
        if (path.equals("unbreaking") || path.equals("mending")) {
            return 2;
        }
        if (path.endsWith("_curse")) {
            return 3;
        }
        return 1;
    }

    /** Un encantamiento ya resuelto (ruta, id y nivel) leido de UN solo ItemStack. */
    private record RawEnchant(String id, String path, int level) {
    }

    /** Lee los encantamientos de ESTE ItemStack unicamente; devuelve una lista nueva y ordenada. */
    private static List<RawEnchant> readEnchants(ItemEnchantmentsComponent component) {
        List<RawEnchant> out = new ArrayList<>(4);
        for (Object2IntMap.Entry<RegistryEntry<net.minecraft.enchantment.Enchantment>> entry
                : component.getEnchantmentEntries()) {
            String id = entry.getKey().getIdAsString();
            String path = id.substring(id.indexOf(':') + 1).toLowerCase(Locale.ROOT);
            out.add(new RawEnchant(id, path, entry.getIntValue()));
        }
        out.sort(Comparator.<RawEnchant>comparingInt(e -> sortKey(e.path())).thenComparing(RawEnchant::path));
        return out;
    }

    // ------------------------------------------------------------------ refresco de cache

    private void refreshStrings(State st, PlayerEntity player, TextRenderer font, float dist, long worldTime) {
        if (frame - st.nameFrame > 40 || st.name.isEmpty()) {
            String n = player.getName().getString();
            if (!n.equals(st.name)) {
                st.name = n;
                st.nameW = font.getWidth(n);
            }
            st.nameFrame = frame;
        }
        int d = Math.round(dist);
        if (d != st.lastDist) {
            st.lastDist = d;
            st.distText = d + "m";
            st.distW = font.getWidth(st.distText);
        }
        if (ping.get()) {
            PlayerListEntry entry = mc.getNetworkHandler() == null ? null
                    : mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            int latency = entry == null ? -1 : entry.getLatency();
            if (latency != st.lastPing) {
                st.lastPing = latency;
                st.pingText = latency < 0 ? "" : latency + "ms";
                st.pingW = font.getWidth(st.pingText);
            }
        }
        float hp = player.getHealth();
        float abs = player.getAbsorptionAmount();
        if (hp != st.lastHp || abs != st.lastAbs) {
            st.lastHp = hp;
            st.lastAbs = abs;
            String text = String.format(Locale.ROOT, "%.1f", hp);
            if (abs > 0.01f) {
                text += "+" + Math.round(abs);
            }
            st.hpText = text;
            st.hpW = font.getWidth(text);
        }
    }

    // ------------------------------------------------------------------ piezas (una por una)

    private int signature() {
        return (enchantNames.index() == 0 ? 1 : 0) | (levels.get() ? 2 : 0) | (levelFormat.index() == 0 ? 4 : 0)
                | (maxEnchants.getInt() << 4);
    }

    /**
     * Inspecciona CADA ranura de equipo por separado: cada Piece guarda unicamente los encantamientos de su propio
     * ItemStack. No existe ninguna lista compartida entre piezas. Se compara en cada fotograma el objeto, sus
     * encantamientos y el formato; si algo cambio se reconstruye solo esa pieza, asi nunca queda informacion antigua.
     */
    private void refreshPieces(State st, PlayerEntity player, TextRenderer font) {
        int sig = signature();
        boolean abbreviate = enchantNames.index() == 0;
        boolean showLevels = levels.get();
        boolean roman = levelFormat.index() == 0;
        int cap = maxEnchants.getInt();
        for (int i = 0; i < 5; i++) {
            Piece piece = st.pieces[i];
            ItemStack stack = i == 0 ? player.getMainHandStack() : player.getEquippedStack(ARMOR_SLOTS[i - 1]);
            if (stack.isEmpty() || (i == 0 && !showHeld.get())) {
                if (piece.present) {
                    piece.clear();
                }
                continue;
            }
            piece.stack = stack; // referencia viva: la durabilidad se lee de la pieza actual
            piece.present = true;
            ItemEnchantmentsComponent component = stack.getEnchantments();
            if (piece.item != stack.getItem() || piece.signature != sig || !Objects.equals(piece.component, component)) {
                piece.item = stack.getItem();
                piece.signature = sig;
                piece.component = component;
                piece.list.clear();
                piece.more = "";
                piece.moreW = 0;
                List<RawEnchant> raw = readEnchants(component);
                piece.hasEnchants = !raw.isEmpty();
                int count = 0;
                for (RawEnchant e : raw) {
                    if (count >= cap) {
                        break;
                    }
                    String name = abbreviate ? shortName(e.path()) : fullName(e.id(), e.path());
                    String text = showLevels && !singleLevel(e.path()) ? name + " " + levelText(e.level(), roman) : name;
                    int color = e.path().endsWith("_curse") ? CURSE : ThemePalette.TEXT;
                    piece.list.add(new Ench(text, font.getWidth(text), color));
                    count++;
                }
                if (raw.size() > cap) {
                    piece.more = "+" + (raw.size() - cap);
                    piece.moreW = font.getWidth(piece.more);
                }
                piece.lastDurPct = -1;
            }
            if (stack.isDamageable()) {
                int pct = Math.round(100f * (1f - stack.getDamage() / (float) Math.max(1, stack.getMaxDamage())));
                if (pct != piece.lastDurPct) {
                    piece.lastDurPct = pct;
                    piece.durText = pct + "%";
                    piece.durW = font.getWidth(piece.durText);
                }
            } else {
                piece.durText = "";
                piece.durW = 0;
                piece.lastDurPct = -1;
            }
        }
    }

    /** Mide el bloque de piezas de este jugador con los ajustes actuales (no dibuja nada). */
    private void layoutPieces(State st) {
        float fs = armorFont.getFloat();
        float scale = armorScale.getFloat();
        float iconSize = pieceIcons.get() ? 16f * scale : 0f;
        float textH = 8f * fs;
        boolean bar = durability.get() && durabilityStyle.index() != 1;
        boolean pct = durability.get() && durabilityStyle.index() != 0;
        boolean showEnchants = enchants.get();
        int gap = armorSpacing.getInt();
        float w = 0f;
        float h = 0f;
        int rows = 0;
        for (Piece piece : st.pieces) {
            piece.shown = false;
            if (!piece.present) {
                continue;
            }
            if (!emptyPieces.get() && !piece.hasEnchants) {
                continue;
            }
            float tw = 0f;
            if (showEnchants) {
                for (Ench e : piece.list) {
                    tw += (tw > 0 ? 4f : 0f) + e.width * fs;
                }
                if (!piece.more.isEmpty()) {
                    tw += (tw > 0 ? 4f : 0f) + piece.moreW * fs;
                }
            }
            if (pct && piece.durW > 0) {
                tw += (tw > 0 ? 5f : 0f) + piece.durW * fs;
            }
            piece.textW = tw;
            float rw = iconSize + (iconSize > 0f && tw > 0f ? 4f : 0f) + tw;
            float rh = Math.max(iconSize + (bar && piece.durW > 0 && iconSize > 0f ? 2f : 0f), tw > 0f ? textH : 0f);
            if (rw <= 0f || rh <= 0f) {
                continue;
            }
            piece.rowW = rw;
            piece.rowH = rh;
            piece.shown = true;
            w = Math.max(w, rw);
            h += (rows > 0 ? gap : 0) + rh;
            rows++;
        }
        st.blockW = w;
        st.blockH = h;
    }

    // ------------------------------------------------------------------ render

    public void render(DrawContext ctx, Projector projector, float tickProgress) {
        if (mc.world == null || mc.player == null) {
            return;
        }
        long now = System.nanoTime();
        double dt = lastNanos == 0L ? 0.016 : Math.min(0.1, (now - lastNanos) / 1.0e9);
        lastNanos = now;
        frame++;
        TextRenderer font = mc.textRenderer;
        long worldTime = mc.world.getTime();
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        double maxRange = range.get();
        double maxSq = maxRange * maxRange;
        int sw = projector.screenW();
        int sh = projector.screenH();
        float baseScale = scale.getFloat();
        float fs = fontSize.getFloat();
        boolean dScale = distScaling.get();
        float minS = minScale.getFloat();
        double offset = height.get();

        visible.clear();
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (!player.isAlive()) {
                continue;
            }
            boolean isSelf = player == mc.player;
            if (isSelf && (firstPerson || !self.get())) {
                continue;
            }
            double sq = player.squaredDistanceTo(mc.player);
            if (sq > maxSq) {
                continue;
            }
            // Posicion interpolada de ESTE fotograma, proyectada con la camara real de ESTE fotograma.
            Vec3d pos = player.getLerpedPos(tickProgress);
            if (!projector.project(pos.x, pos.y + player.getHeight() + offset, pos.z, screen)) {
                continue;
            }
            State st = states.computeIfAbsent(player.getUuid(), k -> new State());
            st.seenFrame = frame;
            st.player = player;
            st.sx = screen[0];
            st.sy = screen[1];
            st.depth = screen[2];
            float dist = (float) Math.sqrt(sq);
            refreshStrings(st, player, font, dist, worldTime);
            if (armor.get()) {
                refreshPieces(st, player, font);
            }

            // alpha: aparicion + desvanecido en el borde del rango
            st.appear = animate.get() ? Math.min(1f, st.appear + (float) (dt * 6.0)) : 1f;
            float edge = 1f;
            if (fadeEdge.get()) {
                double start = maxRange * 0.85;
                edge = dist <= start ? 1f : (float) Math.max(0.0, 1.0 - (dist - start) / (maxRange - start));
            }
            st.alpha = st.appear * edge * (opacity.getFloat() / 100f);
            if (st.alpha < 0.02f) {
                continue;
            }
            float shown = player.getHealth();
            if (animate.get() && st.shownHealth >= 0f) {
                st.shownHealth += (shown - st.shownHealth) * (float) (1.0 - Math.exp(-dt * 10.0));
            } else {
                st.shownHealth = shown;
            }
            st.s = baseScale * (dScale ? (float) MathHelper.clamp(14.0 / st.depth, minS, 1.0) : 1f);
            computeSize(st, fs);
            if (st.sx < -st.w * st.s || st.sx > sw + st.w * st.s || st.sy < -st.h * st.s || st.sy > sh + st.h * st.s * 2) {
                continue;
            }
            visible.add(st);
        }

        // cercanos primero para reservar su sitio; se dibujan al reves (lejanos debajo)
        visible.sort((a, b) -> Double.compare(a.depth, b.depth));
        if (avoidOverlap.get()) {
            resolveOverlap();
        }
        for (int i = visible.size() - 1; i >= 0; i--) {
            drawTag(ctx, font, visible.get(i), fs);
        }

        if ((frame & 127) == 0) {
            Iterator<State> it = states.values().iterator();
            while (it.hasNext()) {
                if (frame - it.next().seenFrame > 120) {
                    it.remove();
                }
            }
        }
    }

    // ------------------------------------------------------------------ layout

    private int pad() {
        return style.index() == 1 ? 3 : 5;
    }

    private boolean compact() {
        return style.index() == 1;
    }

    private void computeSize(State st, float fs) {
        int pad = pad();
        int sp = spacing.getInt();
        float textH = 8f * fs;
        float headerW = 0f;
        int gap = 4;
        boolean any = false;
        if (showName.get()) {
            headerW += st.nameW * fs;
            any = true;
        }
        if (distance.get()) {
            headerW += (any ? gap : 0) + st.distW * fs;
            any = true;
        }
        if (ping.get() && !st.pingText.isEmpty()) {
            headerW += (any ? gap : 0) + st.pingW * fs;
            any = true;
        }
        if (sneakTag.get() && st.player.isSneaking()) {
            headerW += (any ? gap : 0) + 5 * 6 * fs;
            any = true;
        }
        float w = headerW;
        float h = any ? textH + 1 : 0f;
        if (healthBar.get()) {
            float barRow = Math.max(compact() ? 3f : 4f, healthText.get() ? textH : 0f);
            float need = 56f + (healthText.get() ? st.hpW * fs + 4 : 0f);
            w = Math.max(w, need);
            h += (h > 0 ? sp : 0) + barRow;
        }
        if (armor.get()) {
            layoutPieces(st);
            if (st.blockH > 0f) {
                w = Math.max(w, st.blockW);
                h += (h > 0 ? sp : 0) + st.blockH;
            }
        }
        boolean boxed = style.index() != 2;
        st.w = w + (boxed ? pad * 2 : 0);
        st.h = h + (boxed ? pad * 2 - 2 : 0);
        if (st.w < 40f) {
            st.w = 40f;
        }
    }

    /** Desplaza hacia arriba las etiquetas que se solapan con otras mas cercanas (solo si esta activado). */
    private void resolveOverlap() {
        for (int i = 1; i < visible.size(); i++) {
            State a = visible.get(i);
            for (int pass = 0; pass < 6; pass++) {
                boolean moved = false;
                for (int j = 0; j < i; j++) {
                    State b = visible.get(j);
                    double aw = a.w * a.s;
                    double ah = a.h * a.s;
                    double bw = b.w * b.s;
                    double bh = b.h * b.s;
                    boolean overlapX = Math.abs(a.sx - b.sx) < (aw + bw) / 2.0;
                    boolean overlapY = a.sy > b.sy - bh && a.sy - ah < b.sy;
                    if (overlapX && overlapY) {
                        a.sy = b.sy - bh - 2;
                        moved = true;
                    }
                }
                if (!moved) {
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ dibujo

    private void text(DrawContext ctx, TextRenderer font, String s, float x, float y, int color, float fs,
                      boolean shadow) {
        if (s.isEmpty() || (color >>> 24) < 8) {
            return;
        }
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(fs, fs);
        ctx.drawText(font, s, 0, 0, color, shadow);
        ctx.getMatrices().popMatrix();
    }

    private int healthColor(float ratio) {
        if (!healthGradient.get()) {
            return barColor.get();
        }
        int red = 0xFFFF4D4D;
        int yellow = 0xFFFFC83D;
        int green = 0xFF55FF9A;
        return ratio > 0.5f ? ColorUtil.lerp(yellow, green, (ratio - 0.5f) * 2f) : ColorUtil.lerp(red, yellow, ratio * 2f);
    }

    private void drawTag(DrawContext ctx, TextRenderer font, State st, float fs) {
        PlayerEntity player = st.player;
        float a = st.alpha;
        int sty = style.index();
        boolean boxed = sty != 2;
        int pad = pad();
        int sp = spacing.getInt();
        float textH = 8f * fs;
        int radiusPx = radius.getInt();
        boolean friend = friendTint.get() && Targets.isFriend(player);

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) st.sx, (float) st.sy);
        ctx.getMatrices().scale(st.s, st.s);
        int x = -Math.round(st.w / 2f);
        int y = -Math.round(st.h);
        int w = Math.round(st.w);
        int h = Math.round(st.h);

        if (boxed) {
            int accent = borderColor.get();
            if (sty == 3) {
                for (int i = 3; i >= 1; i--) {
                    Render2D.roundedRect(ctx, x - i, y - i, w + i * 2, h + i * 2, radiusPx + i,
                            ColorUtil.scaleAlpha(accent, a * 0.07f * (4 - i)));
                }
            }
            if (background.get() || sty == 3) {
                int fill = ColorUtil.scaleAlpha(sty == 3 ? 0xFF0A070C : bgColor.get(), a);
                if (border.get() || sty == 3) {
                    Render2D.roundedPanel(ctx, x, y, w, h, radiusPx, fill, ColorUtil.scaleAlpha(accent, a));
                } else {
                    Render2D.roundedRect(ctx, x, y, w, h, radiusPx, fill);
                }
            } else if (border.get()) {
                Render2D.roundedPanel(ctx, x, y, w, h, radiusPx, 0x00000000, ColorUtil.scaleAlpha(accent, a));
            }
        }

        float cy = y + (boxed ? pad - 1 : 0);
        int left = x + (boxed ? pad : 0);
        int inner = w - (boxed ? pad * 2 : 0);
        boolean shadowText = sty == 2;

        // ---- cabecera: nombre, distancia, ping, sneak
        boolean sneaking = sneakTag.get() && player.isSneaking();
        boolean hasPing = ping.get() && !st.pingText.isEmpty();
        if (showName.get() || distance.get() || hasPing || sneaking) {
            float hw = 0f;
            int gap = 4;
            boolean any = false;
            if (showName.get()) {
                hw += st.nameW * fs;
                any = true;
            }
            if (distance.get()) {
                hw += (any ? gap : 0) + st.distW * fs;
                any = true;
            }
            if (hasPing) {
                hw += (any ? gap : 0) + st.pingW * fs;
                any = true;
            }
            if (sneaking) {
                hw += (any ? gap : 0) + 30 * fs;
            }
            float hx = left + (inner - hw) / 2f;
            int nc = ColorUtil.scaleAlpha(friend ? friendColor.get() : nameColor.get(), a);
            int dim = ColorUtil.scaleAlpha(ThemePalette.TEXT_DIM, a);
            boolean first = true;
            if (showName.get()) {
                text(ctx, font, st.name, hx, cy, nc, fs, shadowText);
                hx += st.nameW * fs;
                first = false;
            }
            if (distance.get()) {
                hx += first ? 0 : gap;
                text(ctx, font, st.distText, hx, cy, dim, fs, shadowText);
                hx += st.distW * fs;
                first = false;
            }
            if (hasPing) {
                hx += first ? 0 : gap;
                text(ctx, font, st.pingText, hx, cy, dim, fs, shadowText);
                hx += st.pingW * fs;
                first = false;
            }
            if (sneaking) {
                hx += first ? 0 : gap;
                text(ctx, font, "SNEAK", hx, cy, ColorUtil.scaleAlpha(0xFFFFB02E, a), fs, shadowText);
            }
            cy += textH + 1 + sp;
        }

        // ---- barra de vida
        if (healthBar.get()) {
            float maxHp = Math.max(1f, player.getMaxHealth());
            float ratio = MathHelper.clamp(st.shownHealth / maxHp, 0f, 1f);
            float barH = compact() ? 3f : 4f;
            float rowH = Math.max(barH, healthText.get() ? textH : 0f);
            float textW = healthText.get() ? st.hpW * fs + 4f : 0f;
            int barW = Math.max(10, Math.round(inner - textW));
            int by = Math.round(cy + (rowH - barH) / 2f);
            Render2D.roundedRect(ctx, left, by, barW, Math.round(barH), 1,
                    ColorUtil.scaleAlpha(ThemePalette.SWITCH_OFF, a));
            int fillW = Math.round(barW * ratio);
            if (fillW > 0) {
                Render2D.roundedRect(ctx, left, by, Math.max(2, fillW), Math.round(barH), 1,
                        ColorUtil.scaleAlpha(healthColor(ratio), a));
            }
            float abs = player.getAbsorptionAmount();
            if (abs > 0.01f) {
                int absW = Math.round(barW * MathHelper.clamp(abs / maxHp, 0f, 1f));
                if (absW > 0) {
                    ctx.fill(left + barW - absW, by, left + barW, by + Math.round(barH), ColorUtil.scaleAlpha(GOLD, a));
                }
            }
            if (healthText.get()) {
                text(ctx, font, st.hpText, left + barW + 4, cy + (rowH - textH) / 2f, ColorUtil.scaleAlpha(ThemePalette.TEXT, a),
                        fs, shadowText);
            }
            cy += rowH + sp;
        }

        // ---- piezas: icono + durabilidad + SUS encantamientos, una fila por pieza
        if (armor.get() && st.blockH > 0f) {
            float blockX = left + (inner - st.blockW) / 2f;
            float afs = armorFont.getFloat();
            float scale = armorScale.getFloat();
            float iconSize = pieceIcons.get() ? 16f * scale : 0f;
            float atextH = 8f * afs;
            boolean bar = durability.get() && durabilityStyle.index() != 1;
            boolean pct = durability.get() && durabilityStyle.index() != 0;
            boolean showEnchants = enchants.get();
            int gap = armorSpacing.getInt();
            boolean firstRow = true;
            for (Piece piece : st.pieces) {
                if (!piece.shown) {
                    continue;
                }
                if (!firstRow) {
                    cy += gap;
                }
                firstRow = false;
                float rx = blockX;
                if (iconSize > 0f) {
                    if (a > 0.45f) {
                        ctx.getMatrices().pushMatrix();
                        ctx.getMatrices().translate(rx, cy);
                        ctx.getMatrices().scale(scale, scale);
                        ctx.drawItem(piece.stack, 0, 0);
                        ctx.getMatrices().popMatrix();
                    }
                    if (bar && piece.durW > 0) {
                        float d = MathHelper.clamp(piece.lastDurPct / 100f, 0f, 1f);
                        int bx = Math.round(rx);
                        int byy = Math.round(cy + iconSize + 1);
                        int full = Math.round(iconSize);
                        ctx.fill(bx, byy, bx + full, byy + 1, ColorUtil.scaleAlpha(0xFF2A2430, a));
                        ctx.fill(bx, byy, bx + Math.max(1, Math.round(full * d)), byy + 1,
                                ColorUtil.scaleAlpha(healthColor(d), a));
                    }
                    rx += iconSize + (piece.textW > 0f ? 4f : 0f);
                }
                if (piece.textW > 0f) {
                    float ty = cy + (piece.rowH - atextH) / 2f;
                    float tx = rx;
                    boolean any = false;
                    if (showEnchants) {
                        for (Ench e : piece.list) {
                            tx += any ? 4f : 0f;
                            text(ctx, font, e.text, tx, ty, ColorUtil.scaleAlpha(e.color, a), afs, shadowText);
                            tx += e.width * afs;
                            any = true;
                        }
                        if (!piece.more.isEmpty()) {
                            tx += any ? 4f : 0f;
                            text(ctx, font, piece.more, tx, ty, ColorUtil.scaleAlpha(ThemePalette.TEXT_DIM, a), afs,
                                    shadowText);
                            tx += piece.moreW * afs;
                            any = true;
                        }
                    }
                    if (pct && piece.durW > 0) {
                        tx += any ? 5f : 0f;
                        float d = MathHelper.clamp(piece.lastDurPct / 100f, 0f, 1f);
                        text(ctx, font, piece.durText, tx, ty, ColorUtil.scaleAlpha(healthColor(d), a), afs, shadowText);
                    }
                }
                cy += piece.rowH;
            }
        }
        ctx.getMatrices().popMatrix();
    }
}
