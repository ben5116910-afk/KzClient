package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;

/** Edicion rapida del HUD: ajuste a cuadricula al arrastrar y acceso directo por tecla. */
public final class HudQuickEditor extends Module {
    private final BoolSetting snap = add(new BoolSetting("Snap to grid", true));
    private final NumberSetting grid = add(new NumberSetting("Grid size", 2, 20, 2, 4));

    public HudQuickEditor() {
        super("HudQuickEditor", "Grid snapping for the HUD editor (hotkey in Settings).", Category.CLIENT);
        enableByDefault();
    }

    public int snap(int value) {
        if (!isEnabled() || !snap.get()) {
            return value;
        }
        int step = grid.getInt();
        return Math.round(value / (float) step) * step;
    }
}
