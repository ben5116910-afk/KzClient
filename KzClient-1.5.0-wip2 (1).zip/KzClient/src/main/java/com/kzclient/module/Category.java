package com.kzclient.module;

public enum Category {
    COMBAT("COMBAT"),
    MOVEMENT("MOVEMENT"),
    RENDER("RENDER"),
    MISC("MISC"),
    VISUALS("VISUALS"),
    CLIENT("CLIENT");

    private final String label;

    Category(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
