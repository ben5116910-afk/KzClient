package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;

public final class Flight extends Module {
    private static final float VANILLA_FLY_SPEED = 0.05f;
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.5, 10.0, 0.5, 2.0));
    private boolean prevAllow;
    private boolean prevFlying;
    private float prevSpeed = VANILLA_FLY_SPEED;

    public Flight() {
        super("Flight", "Creative-style flight with adjustable speed.", Category.MISC);
    }

    @Override
    public boolean isPersistent() {
        return false;
    }

    @Override
    protected void onEnable() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        PlayerAbilities abilities = player.getAbilities();
        prevAllow = abilities.allowFlying;
        prevFlying = abilities.flying;
        prevSpeed = abilities.getFlySpeed();
        abilities.allowFlying = true;
        abilities.flying = true;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        PlayerAbilities abilities = player.getAbilities();
        abilities.allowFlying = true;
        abilities.setFlySpeed(VANILLA_FLY_SPEED * speed.getFloat());
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        PlayerAbilities abilities = player.getAbilities();
        abilities.setFlySpeed(prevSpeed);
        boolean keep = prevAllow || player.isCreative() || player.isSpectator();
        abilities.allowFlying = keep;
        if (!keep) {
            abilities.flying = false;
        } else {
            abilities.flying = prevFlying && keep;
        }
    }
}
