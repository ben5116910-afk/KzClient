package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.ModeSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Brillo maximo: efecto de vision nocturna del lado cliente o gamma al maximo permitido. */
public final class Fullbright extends Module {
    private final ModeSetting method = add(new ModeSetting("Method", 0, "Night vision", "Gamma"));
    private boolean applied;
    private double previousGamma = 1.0;
    private boolean gammaSaved;

    public Fullbright() {
        super("Fullbright", "Maximum brightness.", Category.RENDER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (method.is("Gamma")) {
            clearEffect();
            if (!gammaSaved) {
                previousGamma = mc.options.getGamma().getValue();
                gammaSaved = true;
            }
            mc.options.getGamma().setValue(1.0);
            return;
        }
        restoreGamma();
        if (player == null) {
            applied = false;
            return;
        }
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            applied = true;
        } else if (applied && current.getDuration() < 400) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
        }
    }

    private void clearEffect() {
        if (applied && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        applied = false;
    }

    private void restoreGamma() {
        if (gammaSaved) {
            mc.options.getGamma().setValue(previousGamma);
            gammaSaved = false;
        }
    }

    @Override
    protected void onDisable() {
        clearEffect();
        restoreGamma();
    }
}
