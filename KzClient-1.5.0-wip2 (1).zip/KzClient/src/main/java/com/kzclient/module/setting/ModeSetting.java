package com.kzclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Selector de una opcion entre varias. */
public final class ModeSetting extends Setting {
    private final String[] options;
    private final int defaultIndex;
    private int index;

    public ModeSetting(String name, int defaultIndex, String... options) {
        super(name);
        this.options = options.clone();
        this.defaultIndex = Math.max(0, Math.min(options.length - 1, defaultIndex));
        this.index = this.defaultIndex;
    }

    public String get() {
        return options[index];
    }

    public int size() {
        return options.length;
    }

    public String option(int i) {
        return options[i];
    }

    public void setIndex(int i) {
        index = Math.max(0, Math.min(options.length - 1, i));
    }

    public int index() {
        return index;
    }

    public boolean is(String option) {
        return options[index].equalsIgnoreCase(option);
    }

    public void cycle(int direction) {
        index = Math.floorMod(index + direction, options.length);
    }

    @Override
    public void reset() {
        index = defaultIndex;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(options[index]);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            String text = element.getAsString();
            for (int i = 0; i < options.length; i++) {
                if (options[i].equalsIgnoreCase(text)) {
                    index = i;
                    return;
                }
            }
        }
    }
}
