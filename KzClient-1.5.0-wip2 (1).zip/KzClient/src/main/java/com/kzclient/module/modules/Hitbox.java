package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Amplia el margen de seleccion (EntityMixin) y puede dibujar la caja ampliada. */
public final class Hitbox extends Module {
    private final NumberSetting expand = add(new NumberSetting("Expand", 0.0, 1.5, 0.1, 0.3));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting visualize = add(new BoolSetting("Visualize", true));

    public Hitbox() {
        super("Hitboxes", "Expand and display entity hitboxes.", Category.COMBAT);
    }

    public boolean applies(Entity entity) {
        if (mc.player == null || entity == mc.player || !(entity instanceof LivingEntity)
                || entity instanceof ArmorStandEntity) {
            return false;
        }
        return entity instanceof PlayerEntity ? players.get() : mobs.get();
    }

    public float margin(Entity entity) {
        return applies(entity) ? expand.getFloat() : 0f;
    }

    public boolean visualize() {
        return visualize.get();
    }
}
