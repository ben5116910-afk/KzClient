package com.kzclient.module.modules;

import com.kzclient.KzClient;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.world.GameMode;

/**
 * Solo informa de hechos observables: jugadores en modo espectador segun la lista de jugadores o
 * cerca de ti, y staff que deja de aparecer en la lista (puede ser una salida normal). No confirma vanish.
 */
public final class AntiVanish extends Module {
    private final NumberSetting range = add(new NumberSetting("Nearby range", 8, 64, 4, 32));
    private final BoolSetting staffOnly = add(new BoolSetting("Staff only", false));
    private final BoolSetting spectatorList = add(new BoolSetting("Spectators in list", true));
    private final BoolSetting disappeared = add(new BoolSetting("Staff disappeared", true));
    private final NumberSetting cooldown = add(new NumberSetting("Notice cooldown (s)", 5, 60, 5, 15));
    private final Map<String, Long> last = new HashMap<>();
    private Set<String> seenStaff = new HashSet<>();
    private int timer;

    public AntiVanish() {
        super("AntiVanish", "Reports observable spectator/vanish indicators.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        seenStaff = new HashSet<>();
        last.clear();
        timer = 0;
    }

    private void notice(String key, String text) {
        long now = System.currentTimeMillis();
        Long before = last.get(key);
        if (before == null || now - before > cooldown.get() * 1000L) {
            last.put(key, now);
            KzClient.notifications().push(text);
        }
    }

    @Override
    public void onTick() {
        if (timer-- > 0 || mc.world == null || mc.player == null) {
            return;
        }
        timer = 10;
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) {
            return;
        }
        String self = mc.player.getName().getString();
        Set<String> listed = new HashSet<>();
        for (PlayerListEntry entry : handler.getPlayerList()) {
            String name = entry.getProfile().name();
            String lower = name.toLowerCase(Locale.ROOT);
            listed.add(lower);
            boolean staff = KzClient.lists().isStaff(name);
            if (staff) {
                seenStaff.add(lower);
            }
            if (spectatorList.get() && entry.getGameMode() == GameMode.SPECTATOR && !name.equals(self)
                    && (!staffOnly.get() || staff)) {
                notice("spec:" + lower, name + " is in spectator mode");
            }
        }
        if (disappeared.get()) {
            for (String name : seenStaff) {
                if (!listed.contains(name)) {
                    notice("gone:" + name, name + " is no longer listed (left or hidden, unconfirmed)");
                }
            }
        }
        seenStaff.retainAll(listed);

        for (AbstractClientPlayerEntity other : mc.world.getPlayers()) {
            if (other != mc.player && other.isSpectator() && mc.player.distanceTo(other) <= range.get()) {
                String name = other.getName().getString();
                if (!staffOnly.get() || KzClient.lists().isStaff(name)) {
                    notice("near:" + name, name + " (spectator) is within " + range.getInt() + " blocks");
                }
            }
        }
    }
}
