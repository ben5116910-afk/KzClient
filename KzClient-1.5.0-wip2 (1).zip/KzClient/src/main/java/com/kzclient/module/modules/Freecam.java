package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Camara libre: la camara se desacopla del jugador (CameraMixin), el raton gira
 * la camara (EntityMixin) y el jugador real queda inmovil en su posicion.
 */
public final class Freecam extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.2, 5.0, 0.1, 1.0));
    private double x;
    private double y;
    private double z;
    private double prevX;
    private double prevY;
    private double prevZ;
    private float yaw;
    private float pitch;
    private Vec3d lock = Vec3d.ZERO;

    public Freecam() {
        super("Freecam", "Detach the camera and fly around freely.", Category.MISC);
    }

    @Override
    public boolean isPersistent() {
        return false;
    }

    @Override
    protected boolean canEnable() {
        return mc.player != null;
    }

    @Override
    protected void onEnable() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        Vec3d eye = player.getEyePos();
        x = eye.x;
        y = eye.y;
        z = eye.z;
        prevX = x;
        prevY = y;
        prevZ = z;
        yaw = player.getYaw();
        pitch = player.getPitch();
        lock = new Vec3d(player.getX(), player.getY(), player.getZ());
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            setEnabled(false);
            return;
        }
        prevX = x;
        prevY = y;
        prevZ = z;

        double forward = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double strafe = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double vertical = (mc.options.jumpKey.isPressed() ? 1 : 0) - (mc.options.sneakKey.isPressed() ? 1 : 0);

        double rad = Math.toRadians(yaw);
        double sin = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = -sin * forward + cos * strafe;
        double dz = cos * forward + sin * strafe;
        double length = Math.sqrt(dx * dx + vertical * vertical + dz * dz);
        if (length > 0.0) {
            double step = speed.get() * 0.5;
            x += dx / length * step;
            y += vertical / length * step;
            z += dz / length * step;
        }

        player.setVelocity(0.0, 0.0, 0.0);
        player.setPosition(lock.x, lock.y, lock.z);
    }

    public void rotate(double deltaX, double deltaY) {
        yaw += (float) (deltaX * 0.15);
        pitch = (float) Math.max(-90.0, Math.min(90.0, pitch + deltaY * 0.15));
    }

    public double x(float tickProgress) {
        return prevX + (x - prevX) * tickProgress;
    }

    public double y(float tickProgress) {
        return prevY + (y - prevY) * tickProgress;
    }

    public double z(float tickProgress) {
        return prevZ + (z - prevZ) * tickProgress;
    }

    public float yaw() {
        return yaw;
    }

    public float pitch() {
        return pitch;
    }
}
