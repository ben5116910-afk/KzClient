package com.kzclient.module;

import com.kzclient.KzClient;
import com.kzclient.gui.Render2D;
import com.kzclient.gui.ThemePalette;
import com.kzclient.module.modules.Panic;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Estado de Panic (una sola instancia, creada por ModuleManager).
 *
 * Reglas que corrigen el panic de 1.4.0:
 *  - Se guarda el conjunto EXACTO de modulos que estaban activos; solo esos se restauran.
 *  - Mientras Panic esta activo, config.json sigue guardando el estado ORIGINAL (persistedEnabled/persistedHud),
 *    asi que un autosave o cerrar el juego durante Panic ya no deja los modulos apagados para siempre.
 *  - Mientras Panic esta activo ningun modulo puede encenderse (blocksEnable).
 *  - Se restaura de forma automatica al terminar el contador, o antes con la misma tecla. El contador avanza
 *    por ticks del cliente y no hay hilos ni listeners nuevos por activacion, asi que no se duplican tareas.
 */
public final class PanicController {
    private final ModuleManager manager;
    private final Set<Module> snapshot = new LinkedHashSet<>();
    private boolean active;
    private boolean hudWasEnabled = true;
    private int totalTicks;
    private int remainingTicks;

    PanicController(ModuleManager manager) {
        this.manager = manager;
    }

    public boolean isActive() {
        return active;
    }

    /** Segundos restantes (redondeado hacia arriba). */
    public int secondsLeft() {
        return (remainingTicks + 19) / 20;
    }

    public float progress() {
        return totalTicks <= 0 ? 0f : Math.max(0f, Math.min(1f, remainingTicks / (float) totalTicks));
    }

    /** Estado de "enabled" que debe escribirse en config.json (el original si hay Panic en curso). */
    public boolean persistedEnabled(Module module) {
        return active && snapshot.contains(module) || module.isEnabled();
    }

    public boolean persistedHud(boolean currentHud) {
        return active ? hudWasEnabled : currentHud;
    }

    /** Mientras dura Panic no se permite encender modulos (ni por tecla ni desde la GUI). */
    public boolean blocksEnable(Module module) {
        return active && !(module instanceof Panic);
    }

    public void toggle() {
        if (active) {
            end();
        } else {
            start();
        }
    }

    public void start() {
        Panic panic = manager.get(Panic.class);
        if (active || !panic.isAllowed()) {
            return;
        }
        snapshot.clear();
        if (panic.disableModules()) {
            for (Module module : manager.all()) {
                if (module.isEnabled() && !(module instanceof Panic)) {
                    snapshot.add(module);
                }
            }
        }
        hudWasEnabled = KzClient.hud().isEnabled();
        active = true;
        totalTicks = Math.max(20, panic.durationSeconds() * 20);
        remainingTicks = totalTicks;
        // se apagan DESPUES de marcar active para que cualquier lectura de estado ya vea Panic en curso
        for (Module module : new ArrayList<>(snapshot)) {
            module.suspend();
        }
        if (panic.hideHud()) {
            KzClient.hud().setEnabled(false);
        }
        if (panic.clearNotifications()) {
            KzClient.notifications().clear();
        }
    }

    /** Restaura los modulos y el HUD que estaban activos. Idempotente. */
    public void end() {
        if (!active) {
            return;
        }
        active = false;
        remainingTicks = 0;
        List<Module> restore = new ArrayList<>(snapshot);
        snapshot.clear();
        for (Module module : restore) {
            module.restoreEnabled(true);
        }
        KzClient.hud().setEnabled(hudWasEnabled);
    }

    void tick() {
        if (!active) {
            return;
        }
        if (--remainingTicks <= 0) {
            end();
        }
    }

    /** Al desconectar, los modulos no persistentes se apagan solos y no deben reactivarse al terminar Panic. */
    void onDisconnect() {
        snapshot.removeIf(module -> !module.isPersistent());
    }

    /** Indicador en pantalla (se dibuja aunque el HUD este oculto). */
    public void renderIndicator(DrawContext ctx) {
        Panic panic = manager.get(Panic.class);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!active || !panic.showIndicator() || mc.options.hudHidden) {
            return;
        }
        TextRenderer font = mc.textRenderer;
        String label = panic.showCounter() ? "PANIC  " + secondsLeft() + "s" : "PANIC";
        int w = Math.max(96, font.getWidth(label) + 28);
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = 6;
        Render2D.roundedPanel(ctx, x, y, w, 22, 6, 0xE017101F, ThemePalette.ACCENT_BORDER);
        Render2D.textCentered(ctx, font, label, x, y + 4, w, ThemePalette.ACCENT);
        ctx.fill(x + 6, y + 16, x + w - 6, y + 18, 0xFF39213F);
        ctx.fill(x + 6, y + 16, x + 6 + Math.round((w - 12) * progress()), y + 18, ThemePalette.ACCENT);
    }
}
