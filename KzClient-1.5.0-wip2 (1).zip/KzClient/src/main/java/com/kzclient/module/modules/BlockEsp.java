package com.kzclient.module.modules;

import com.kzclient.config.ListFiles;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.render.EspTarget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Resalta bloques elegidos (interruptores + lista extra en config/kzclient/blocks.txt). */
public final class BlockEsp extends Module {
    private final BoolSetting diamond = add(new BoolSetting("Diamond", true));
    private final BoolSetting debris = add(new BoolSetting("Ancient Debris", true));
    private final BoolSetting gold = add(new BoolSetting("Gold", false));
    private final BoolSetting emerald = add(new BoolSetting("Emerald", false));
    private final BoolSetting spawner = add(new BoolSetting("Spawner", false));
    private final BoolSetting custom = add(new BoolSetting("blocks.txt", false));
    private final BoolSetting fill = add(new BoolSetting("Fill", true));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", false));
    private final NumberSetting range = add(new NumberSetting("Range", 6, 24, 2, 14));
    private List<EspTarget> targets = new ArrayList<>();
    private int timer;
    private Map<Block, Integer> wantedCache = new HashMap<>();
    private int wantedSignature = -1;
    private long customStamp = Long.MIN_VALUE;

    public BlockEsp() {
        super("BlockESP", "Highlights the blocks you pick.", Category.RENDER);
    }

    public boolean fill() {
        return fill.get();
    }

    public boolean tracers() {
        return tracers.get();
    }

    public List<EspTarget> targets() {
        return Collections.unmodifiableList(targets);
    }

    @Override
    protected void onEnable() {
        timer = 0;
        wantedSignature = -1;
    }

    @Override
    protected void onDisable() {
        targets = new ArrayList<>();
    }

    /**
     * Mapa de bloques buscados. Se reconstruye solo si cambian los interruptores o, cada ~10 s, el contenido
     * de blocks.txt (antes se leia el disco y se creaba un mapa nuevo cada 2 s).
     */
    private Map<Block, Integer> wanted() {
        int signature = (diamond.get() ? 1 : 0) | (debris.get() ? 2 : 0) | (gold.get() ? 4 : 0)
                | (emerald.get() ? 8 : 0) | (spawner.get() ? 16 : 0) | (custom.get() ? 32 : 0);
        long now = System.currentTimeMillis();
        boolean customStale = custom.get() && now - customStamp > 10_000L;
        if (signature == wantedSignature && !customStale) {
            return wantedCache;
        }
        wantedSignature = signature;
        customStamp = now;
        wantedCache = buildWanted();
        return wantedCache;
    }

    private Map<Block, Integer> buildWanted() {
        Map<Block, Integer> map = new HashMap<>();
        if (diamond.get()) {
            map.put(Blocks.DIAMOND_ORE, 0xFF4DE8FF);
            map.put(Blocks.DEEPSLATE_DIAMOND_ORE, 0xFF4DE8FF);
        }
        if (debris.get()) {
            map.put(Blocks.ANCIENT_DEBRIS, 0xFFC28A4A);
        }
        if (gold.get()) {
            map.put(Blocks.GOLD_ORE, 0xFFFFD34D);
            map.put(Blocks.DEEPSLATE_GOLD_ORE, 0xFFFFD34D);
            map.put(Blocks.NETHER_GOLD_ORE, 0xFFFFD34D);
        }
        if (emerald.get()) {
            map.put(Blocks.EMERALD_ORE, 0xFF4DFF88);
            map.put(Blocks.DEEPSLATE_EMERALD_ORE, 0xFF4DFF88);
        }
        if (spawner.get()) {
            map.put(Blocks.SPAWNER, 0xFFFF278F);
        }
        if (custom.get()) {
            for (String id : ListFiles.read("blocks.txt", "# One block id per line, e.g. minecraft:iron_ore")) {
                Identifier identifier = Identifier.tryParse(id);
                if (identifier != null && Registries.BLOCK.containsId(identifier)) {
                    map.put(Registries.BLOCK.get(identifier), 0xFFFFFFFF);
                }
            }
        }
        return map;
    }

    @Override
    public void onTick() {
        if (timer-- > 0) {
            return;
        }
        timer = 40;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null) {
            return;
        }
        Map<Block, Integer> wanted = wanted();
        List<EspTarget> found = new ArrayList<>();
        if (!wanted.isEmpty()) {
            BlockPos center = player.getBlockPos();
            int r = range.getInt();
            BlockPos.Mutable pos = new BlockPos.Mutable();
            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    int worldY = center.getY() + y;
                    if (mc.world.isOutOfHeightLimit(worldY)) {
                        continue;
                    }
                    for (int z = -r; z <= r; z++) {
                        pos.set(center.getX() + x, worldY, center.getZ() + z);
                        Integer color = wanted.get(mc.world.getBlockState(pos).getBlock());
                        if (color != null && found.size() < 400) {
                            found.add(new EspTarget(new Box(pos), color));
                        }
                    }
                }
            }
        }
        targets = found;
    }
}
