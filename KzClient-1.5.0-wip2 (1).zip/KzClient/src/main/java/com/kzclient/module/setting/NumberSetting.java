package com.kzclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting {
    private final double min;
    private final double max;
    private final double step;
    private final double defaultValue;
    private double value;

    public NumberSetting(String name, double min, double max, double step, double value) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = clamp(value);
        this.defaultValue = this.value;
    }

    private double clamp(double v) {
        double snapped = Math.round((v - min) / step) * step + min;
        return Math.max(min, Math.min(max, snapped));
    }

    @Override
    public void reset() {
        value = defaultValue;
    }

    public double get() {
        return value;
    }

    public float getFloat() {
        return (float) value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public void set(double v) {
        this.value = clamp(v);
    }

    public void setFromRatio(double ratio) {
        double r = Math.max(0.0, Math.min(1.0, ratio));
        set(min + (max - min) * r);
    }

    public double ratio() {
        return max == min ? 0.0 : (value - min) / (max - min);
    }

    public String display() {
        if (step >= 1.0) {
            return Integer.toString((int) Math.round(value));
        }
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            set(element.getAsDouble());
        }
    }
}
