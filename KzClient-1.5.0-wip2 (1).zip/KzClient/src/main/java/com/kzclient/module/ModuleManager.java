package com.kzclient.module;

import com.kzclient.KzClient;
import com.kzclient.event.ClientTickEvent;
import com.kzclient.event.DisconnectEvent;
import com.kzclient.event.EventBus;
import com.kzclient.feature.Feature;
import com.kzclient.feature.FeatureLoader;
import com.kzclient.module.modules.AimAssist;
import com.kzclient.module.modules.Animations;
import com.kzclient.module.modules.AntiAfk;
import com.kzclient.module.modules.AntiVanish;
import com.kzclient.module.modules.AutoTool;
import com.kzclient.module.modules.AutoTotem;
import com.kzclient.module.modules.BlockEsp;
import com.kzclient.module.modules.Cosmetics;
import com.kzclient.module.modules.CustomBlockOutline;
import com.kzclient.module.modules.CustomFov;
import com.kzclient.module.modules.Flight;
import com.kzclient.module.modules.Freecam;
import com.kzclient.module.modules.Fullbright;
import com.kzclient.module.modules.Hitbox;
import com.kzclient.module.modules.HitParticles;
import com.kzclient.module.modules.HudQuickEditor;
import com.kzclient.module.modules.NameChanger;
import com.kzclient.module.modules.Nametags;
import com.kzclient.module.modules.Panic;
import com.kzclient.module.modules.PlayerEsp;
import com.kzclient.module.modules.ToggleSprint;
import com.kzclient.module.modules.Sky;
import com.kzclient.module.modules.StaffList;
import com.kzclient.module.modules.StorageEsp;
import com.kzclient.module.modules.TriggerBot;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    private final Map<Class<? extends Module>, Module> modules = new LinkedHashMap<>();
    private final List<Module> ordered = new ArrayList<>();
    private final List<Module> orderedView = Collections.unmodifiableList(ordered);
    private final Map<Category, List<Module>> categoryLists = new java.util.EnumMap<>(Category.class);
    private final PanicController panic = new PanicController(this);

    public ModuleManager(EventBus bus) {
        register(new AutoTotem());
        register(new Hitbox());
        register(new AimAssist());
        register(new TriggerBot());
        register(new AutoTool());

        register(new ToggleSprint());
        register(new Flight());
        register(new Freecam());
        register(new AntiAfk());

        register(new PlayerEsp());
        register(new StorageEsp());
        register(new BlockEsp());
        register(new Fullbright());

        register(new NameChanger());
        register(new StaffList());
        register(new CustomFov());
        register(new AntiVanish());
        register(new Panic());

        register(new CustomBlockOutline());
        register(new Cosmetics());
        register(new Sky());
        register(new Nametags());
        register(new HitParticles());

        register(new HudQuickEditor());
        register(new Animations());

        // modulos aportados por las funciones opcionales compiladas en este jar (src/features/*)
        for (Feature feature : FeatureLoader.load()) {
            for (Module module : feature.modules()) {
                register(module);
            }
        }

        for (Category category : Category.values()) {
            List<Module> list = new ArrayList<>();
            for (Module module : ordered) {
                if (module.category() == category) {
                    list.add(module);
                }
            }
            categoryLists.put(category, Collections.unmodifiableList(list));
        }
        bus.subscribe(ClientTickEvent.class, e -> {
            panic.tick();
            tick();
        });
        bus.subscribe(DisconnectEvent.class, e -> {
            panic.onDisconnect();
            onDisconnect();
        });
    }

    private void register(Module module) {
        modules.put(module.getClass(), module);
        ordered.add(module);
    }

    public <T extends Module> T get(Class<T> type) {
        return type.cast(modules.get(type));
    }

    public List<Module> all() {
        return orderedView;
    }

    public List<Module> byCategory(Category category) {
        return categoryLists.get(category);
    }

    public void disableAll() {
        for (Module module : modules.values()) {
            module.setEnabled(false);
        }
    }

    public PanicController panic() {
        return panic;
    }

    private void tick() {
        for (Module module : modules.values()) {
            if (!module.isEnabled()) {
                continue;
            }
            try {
                module.onTick();
            } catch (RuntimeException ex) {
                KzClient.LOGGER.error("Error en el modulo {}", module.name(), ex);
                module.setEnabled(false);
            }
        }
    }

    private void onDisconnect() {
        for (Module module : modules.values()) {
            if (module.isEnabled() && !module.isPersistent()) {
                module.setEnabled(false);
            }
        }
    }
}
