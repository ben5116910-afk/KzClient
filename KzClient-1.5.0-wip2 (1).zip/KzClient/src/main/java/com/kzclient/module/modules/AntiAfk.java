package com.kzclient.module.modules;

import com.kzclient.KzClient;
import com.kzclient.event.DisconnectEvent;
import com.kzclient.input.KeybindManager;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

/**
 * AntiAFK: realiza una accion de movimiento corta cada cierto tiempo (configurable) para que el jugador no
 * quede completamente inactivo. Solo actua cuando el jugador esta en condiciones (mundo cargado, sin pantallas,
 * sin escribir, vivo, en suelo, sin Freecam...) y se detiene al instante si el usuario toca el teclado o el raton.
 *
 * <p>Las teclas se pulsan con KeyBinding.setPressed durante el tick final del cliente (evento de Fabric) y siempre
 * se devuelven al estado fisico real de la tecla al terminar o abortar, de modo que nunca se queda una tecla "pegada".
 * La tecla para activarlo/desactivarlo es el "Keybind" de su tarjeta (KeybindManager).
 */
public final class AntiAfk extends Module {
    private static final int TICKS_PER_SECOND = 20;

    // ---- cuando
    private final NumberSetting interval = add(new NumberSetting("Interval (s)", 5, 600, 1, 30));
    private final NumberSetting minInterval = add(new NumberSetting("Min interval (s)", 5, 600, 1, 15));
    private final NumberSetting maxInterval = add(new NumberSetting("Max interval (s)", 5, 600, 1, 45));
    private final BoolSetting randomize = add(new BoolSetting("Randomize between min and max", true));

    // ---- que
    private final ModeSetting movement = add(new ModeSetting("Movement", 0,
            "Walk", "Strafe", "Jump", "Sneak", "Look around", "Random"));
    private final NumberSetting duration = add(new NumberSetting("Duration (ticks)", 2, 40, 1, 8));
    private final NumberSetting lookAngle = add(new NumberSetting("Look angle", 5, 90, 5, 25));
    private final BoolSetting returnBack = add(new BoolSetting("Return to start", true));
    private final BoolSetting safeWalk = add(new BoolSetting("Safe walk (avoid drops/liquids)", true));

    // ---- seguridad
    private final BoolSetting pauseOnInput = add(new BoolSetting("Pause on your input", true));
    private final NumberSetting resumeAfter = add(new NumberSetting("Resume after (s)", 1, 60, 1, 5));

    // ---- avisos
    private final BoolSetting notify = add(new BoolSetting("Notifications", true));
    private final BoolSetting hudIndicator = add(new BoolSetting("HUD indicator", true));

    private enum Kind { WALK, STRAFE, JUMP, SNEAK, LOOK }

    /** Fase de una accion: teclas a mantener y/o giro por tick durante "ticks" ticks. */
    private record Phase(KeyBinding[] keys, int ticks, float yawPerTick) {
    }

    private final List<Phase> phases = new ArrayList<>();
    private final List<KeyBinding> held = new ArrayList<>();
    private boolean scheduled;
    private long tick;
    private long nextAt;
    private int phaseIndex;
    private int phaseTick;
    private boolean running;
    private String runningLabel = "";
    private String pauseReason = "";
    private String lastPauseNotice = "";
    private long lastNoticeTick = Long.MIN_VALUE;
    private float lastYaw;
    private float lastPitch;
    private boolean haveLook;

    public AntiAfk() {
        super("AntiAFK", "Moves a little now and then so you are never fully idle.", Category.MISC);
        if (KzClient.bus() != null) {
            KzClient.bus().subscribe(DisconnectEvent.class, e -> reset());
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onEnable() {
        reset();
    }

    @Override
    protected void onDisable() {
        reset();
    }

    /** Cancela cualquier accion y suelta las teclas que mantuviera este modulo. */
    private void reset() {
        abort();
        scheduled = false;
        pauseReason = "";
        lastPauseNotice = "";
        haveLook = false;
    }

    private void abort() {
        releaseAll();
        phases.clear();
        running = false;
        phaseIndex = 0;
        phaseTick = 0;
    }

    // ------------------------------------------------------------------ teclas

    private void hold(KeyBinding key) {
        key.setPressed(true);
        if (!held.contains(key)) {
            held.add(key);
        }
    }

    private void releaseAll() {
        for (KeyBinding key : held) {
            // se devuelve al estado fisico real: si el usuario mantiene la tecla, no se suelta.
            key.setPressed(physicalDown(key));
        }
        held.clear();
    }

    private boolean physicalDown(KeyBinding key) {
        try {
            String translation = key.getBoundKeyTranslationKey();
            if (mc.getWindow() == null) {
                return false;
            }
            long handle = mc.getWindow().getHandle();
            if (translation.startsWith("key.keyboard.")) {
                return KeybindManager.isDown(InputUtil.fromTranslationKey(translation).getCode());
            }
            if (translation.startsWith("key.mouse.")) {
                int button = InputUtil.fromTranslationKey(translation).getCode();
                return GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
            }
        } catch (RuntimeException ignored) {
            // tecla desconocida: se considera suelta
        }
        return false;
    }

    /** true si el usuario esta pulsando una tecla de accion o ha movido la camara. */
    private boolean userActive(ClientPlayerEntity player) {
        boolean rotated = false;
        if (haveLook) {
            rotated = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(player.getYaw() - lastYaw)) > 0.05f
                    || Math.abs(player.getPitch() - lastPitch) > 0.05f;
        }
        lastYaw = player.getYaw();
        lastPitch = player.getPitch();
        haveLook = true;
        if (rotated) {
            return true;
        }
        return physicalDown(mc.options.forwardKey) || physicalDown(mc.options.backKey)
                || physicalDown(mc.options.leftKey) || physicalDown(mc.options.rightKey)
                || physicalDown(mc.options.jumpKey) || physicalDown(mc.options.sneakKey)
                || physicalDown(mc.options.attackKey) || physicalDown(mc.options.useKey);
    }

    // ------------------------------------------------------------------ condiciones

    /** null si puede actuar; si no, el motivo de la pausa. */
    private String blocker(ClientPlayerEntity player) {
        if (mc.world == null || mc.getNetworkHandler() == null) {
            return "no world";
        }
        if (mc.currentScreen != null) {
            return "menu or chat open";
        }
        if (player.isDead() || !player.isAlive()) {
            return "dead";
        }
        Freecam freecam = KzClient.modules().get(Freecam.class);
        if (freecam != null && freecam.isEnabled()) {
            return "Freecam active";
        }
        if (player.isSleeping()) {
            return "sleeping";
        }
        if (player.hasVehicle()) {
            return "riding";
        }
        if (player.isUsingItem()) {
            return "using item";
        }
        if (player.isClimbing() || player.isTouchingWater() || player.isInLava()) {
            return "climbing or in liquid";
        }
        if (player.getAbilities().flying) {
            return "flying";
        }
        if (player.hurtTime > 0) {
            return "taking damage";
        }
        if (!player.isOnGround()) {
            return "in the air";
        }
        return null;
    }

    // ------------------------------------------------------------------ planificacion

    private int delayTicks() {
        double lo = Math.min(minInterval.get(), maxInterval.get());
        double hi = Math.max(minInterval.get(), maxInterval.get());
        double seconds;
        if (randomize.get()) {
            seconds = lo + ThreadLocalRandom.current().nextDouble() * (hi - lo);
        } else {
            seconds = Math.max(lo, Math.min(hi, interval.get()));
        }
        return Math.max(20, (int) Math.round(seconds * TICKS_PER_SECOND));
    }

    private void schedule(int delay) {
        nextAt = tick + delay;
        scheduled = true;
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            abort();
            scheduled = false;
            return;
        }
        tick++;
        if (!scheduled) {
            schedule(delayTicks());
        }

        String block = blocker(player);
        if (block != null) {
            if (running) {
                abort();
            }
            haveLook = false;
            pause(block);
            // mientras esta bloqueado el reloj no corre: al volver espera el intervalo completo.
            nextAt = Math.max(nextAt, tick + 20);
            return;
        }

        boolean user = pauseOnInput.get() && userActive(player);
        if (user) {
            if (running) {
                abort();
            }
            pause("your input");
            schedule(Math.max(delayTicks() / 4, resumeAfter.getInt() * TICKS_PER_SECOND));
            return;
        }
        resumed();

        if (running) {
            stepAction(player);
            return;
        }
        if (tick >= nextAt) {
            start(player);
        }
    }

    private void pause(String reason) {
        pauseReason = reason;
        if (notify.get() && !reason.equals(lastPauseNotice) && tick - lastNoticeTick > 100
                && !reason.equals("your input") && !reason.equals("no world")) {
            KzClient.notifications().push("AntiAFK paused: " + reason);
            lastNoticeTick = tick;
        }
        lastPauseNotice = reason;
    }

    private void resumed() {
        if (!pauseReason.isEmpty()) {
            pauseReason = "";
            lastPauseNotice = "";
        }
    }

    // ------------------------------------------------------------------ acciones

    private void start(ClientPlayerEntity player) {
        Kind kind = switch (movement.index()) {
            case 0 -> Kind.WALK;
            case 1 -> Kind.STRAFE;
            case 2 -> Kind.JUMP;
            case 3 -> Kind.SNEAK;
            case 4 -> Kind.LOOK;
            default -> Kind.values()[ThreadLocalRandom.current().nextInt(Kind.values().length)];
        };
        if ((kind == Kind.WALK || kind == Kind.STRAFE) && safeWalk.get()) {
            kind = pickSafeDirectionKind(player, kind);
        }
        phases.clear();
        int d = duration.getInt();
        boolean back = returnBack.get();
        boolean flip = ThreadLocalRandom.current().nextBoolean();
        switch (kind) {
            case WALK -> {
                boolean forward = walkDirectionForward(player, true, flip);
                KeyBinding out = forward ? mc.options.forwardKey : mc.options.backKey;
                KeyBinding in = forward ? mc.options.backKey : mc.options.forwardKey;
                phases.add(new Phase(new KeyBinding[] {out}, d, 0f));
                if (back) {
                    phases.add(new Phase(new KeyBinding[0], 2, 0f));
                    phases.add(new Phase(new KeyBinding[] {in}, d, 0f));
                }
                runningLabel = "walking";
            }
            case STRAFE -> {
                boolean left = walkDirectionForward(player, false, flip);
                KeyBinding out = left ? mc.options.leftKey : mc.options.rightKey;
                KeyBinding in = left ? mc.options.rightKey : mc.options.leftKey;
                phases.add(new Phase(new KeyBinding[] {out}, d, 0f));
                if (back) {
                    phases.add(new Phase(new KeyBinding[0], 2, 0f));
                    phases.add(new Phase(new KeyBinding[] {in}, d, 0f));
                }
                runningLabel = "strafing";
            }
            case JUMP -> {
                phases.add(new Phase(new KeyBinding[] {mc.options.jumpKey}, 1, 0f));
                runningLabel = "jumping";
            }
            case SNEAK -> {
                phases.add(new Phase(new KeyBinding[] {mc.options.sneakKey}, d, 0f));
                runningLabel = "sneaking";
            }
            default -> {
                float angle = lookAngle.getFloat() * (flip ? 1f : -1f);
                phases.add(new Phase(new KeyBinding[0], d, angle / d));
                if (back) {
                    phases.add(new Phase(new KeyBinding[0], d, -angle / d));
                }
                runningLabel = "looking around";
            }
        }
        phaseIndex = 0;
        phaseTick = 0;
        running = true;
        if (notify.get()) {
            KzClient.notifications().push("AntiAFK: " + runningLabel);
        }
        applyPhase(player);
    }

    /** true = delante/izquierda segun el eje; en modo seguro prefiere el lado con suelo. */
    private boolean walkDirectionForward(ClientPlayerEntity player, boolean forwardAxis, boolean flip) {
        if (!safeWalk.get()) {
            return flip;
        }
        Direction dir = axisDirection(player, forwardAxis, true);
        Direction opposite = axisDirection(player, forwardAxis, false);
        boolean first = pathSafe(player, dir);
        boolean second = pathSafe(player, opposite);
        if (first && second) {
            return flip;
        }
        return first;
    }

    /** Direccion de mundo de la tecla "positiva" (delante / izquierda) o de la contraria. */
    private static Direction axisDirection(ClientPlayerEntity player, boolean forwardAxis, boolean positive) {
        Direction facing = player.getHorizontalFacing();
        Direction base = forwardAxis ? facing : facing.rotateYCounterclockwise();
        return positive ? base : base.getOpposite();
    }

    private Kind pickSafeDirectionKind(ClientPlayerEntity player, Kind wanted) {
        boolean forwardAxis = wanted == Kind.WALK;
        boolean ok = pathSafe(player, axisDirection(player, forwardAxis, true))
                || pathSafe(player, axisDirection(player, forwardAxis, false));
        return ok ? wanted : Kind.LOOK;
    }

    /** Comprueba que los bloques por los que se avanzaria tienen suelo y no hay liquidos. */
    private boolean pathSafe(ClientPlayerEntity player, Direction dir) {
        World world = mc.world;
        if (world == null) {
            return false;
        }
        int blocks = Math.min(6, (int) Math.ceil(duration.getInt() * 0.3) + 1);
        BlockPos origin = player.getBlockPos();
        for (int i = 1; i <= blocks; i++) {
            BlockPos foot = origin.offset(dir, i);
            BlockPos ground = foot.down();
            if (world.getBlockState(ground).isAir() || !world.getFluidState(ground).isEmpty()
                    || !world.getFluidState(foot).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private void applyPhase(ClientPlayerEntity player) {
        releaseAll();
        Phase phase = phases.get(phaseIndex);
        for (KeyBinding key : phase.keys()) {
            hold(key);
        }
    }

    private void stepAction(ClientPlayerEntity player) {
        Phase phase = phases.get(phaseIndex);
        if (phase.yawPerTick() != 0f) {
            player.setYaw(player.getYaw() + phase.yawPerTick());
            lastYaw = player.getYaw();
            lastPitch = player.getPitch();
        }
        phaseTick++;
        if (phaseTick >= phase.ticks()) {
            phaseIndex++;
            phaseTick = 0;
            if (phaseIndex >= phases.size()) {
                abort();
                schedule(delayTicks());
                return;
            }
            applyPhase(player);
        }
    }

    // ------------------------------------------------------------------ estado para el HUD

    public boolean showHud() {
        return hudIndicator.get();
    }

    public boolean isRunning() {
        return running;
    }

    public String pauseReason() {
        return pauseReason;
    }

    /** Segundos hasta la proxima accion (0 si esta en marcha o pausado). */
    public int secondsUntilNext() {
        return running || !scheduled ? 0 : (int) Math.max(0, (nextAt - tick + TICKS_PER_SECOND - 1) / TICKS_PER_SECOND);
    }

    public String statusText() {
        if (running) {
            return "AntiAFK " + runningLabel;
        }
        if (!pauseReason.isEmpty()) {
            return "AntiAFK paused (" + pauseReason + ")";
        }
        return "AntiAFK next " + secondsUntilNext() + "s";
    }
}
