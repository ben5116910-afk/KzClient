package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;

/** Contorno de bloque personalizable y animado (WorldRendererMixin). */
public final class CustomBlockOutline extends Module {
    private final NumberSetting hue = add(new NumberSetting("Hue", 0, 360, 1, 335));
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 1.0, 10.0, 0.5, 3.0));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final BoolSetting pulse = add(new BoolSetting("Pulse", true));
    private final BoolSetting neon = add(new BoolSetting("Neon glow", true));

    public CustomBlockOutline() {
        super("CustomBlockOutline", "Animated neon block outline.", Category.VISUALS);
    }

    public int argb() {
        long t = System.currentTimeMillis();
        float h = rainbow.get() ? (t % 4000L) / 4000f * 360f : hue.getFloat();
        float wave = (float) (0.5 + 0.5 * Math.sin(t / 260.0));
        float saturation = neon.get() ? 0.55f + 0.35f * (1f - wave) : 0.72f;
        float value = neon.get() ? 0.8f + 0.2f * wave : 1.0f;
        return ColorUtil.hsv(h, saturation, value);
    }

    public float lineWidth() {
        float base = thickness.getFloat();
        if (pulse.get()) {
            base *= 1f + 0.35f * (float) Math.sin(System.currentTimeMillis() / 300.0);
        }
        return Math.max(1f, base);
    }
}
