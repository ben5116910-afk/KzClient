package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;

/** Sustituye localmente el nombre del cliente por tu nombre ("YOUR NAME") en la interfaz. */
public final class NameChanger extends Module {
    private final ModeSetting format = add(new ModeSetting("Format", 0, "Name", "Name | KZ", "KZ | Name"));
    private final BoolSetting watermark = add(new BoolSetting("In watermark", true));
    private final BoolSetting header = add(new BoolSetting("In panel header", true));

    public NameChanger() {
        super("NameChanger", "Shows your own name as the client name.", Category.MISC);
    }

    public String apply(String name, boolean forWatermark) {
        if (forWatermark ? !watermark.get() : !header.get()) {
            return null;
        }
        return switch (format.index()) {
            case 1 -> name + " | KZ";
            case 2 -> "KZ | " + name;
            default -> name;
        };
    }
}
