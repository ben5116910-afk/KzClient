package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;
import com.kzclient.util.ParticleUtil;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Cosmeticos locales dibujados con particulas del cliente: alas animadas, Aura (anillos o cinta),
 * halo flotante y estela. Solo los ves tu y solo en tercera persona; no hay sincronizacion.
 */
public final class Cosmetics extends Module {
    private final BoolSetting wings = add(new BoolSetting("Wings", true));
    private final BoolSetting aura = add(new BoolSetting("Aura", true));
    private final ModeSetting auraStyle = add(new ModeSetting("Aura style", 0, "Rings", "Ribbon"));
    private final BoolSetting halo = add(new BoolSetting("Floating halo", false));
    private final BoolSetting trail = add(new BoolSetting("Trail", false));
    private final NumberSetting hue = add(new NumberSetting("Hue", 0, 360, 1, 335));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final NumberSetting density = add(new NumberSetting("Density", 1, 3, 1, 2));
    private long ticks;

    public Cosmetics() {
        super("Cosmetics", "Local particle wings, aura, halo and trail.", Category.VISUALS);
    }

    @Override
    public void onTick() {
        ticks++;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.options.getPerspective().isFirstPerson() || ticks % 2 != 0) {
            return;
        }
        float h = rainbow.get() ? (ticks % 200L) / 200f * 360f : hue.getFloat();
        int rgb = ColorUtil.hsv(h, 0.75f, 1f);
        double yaw = Math.toRadians(player.getBodyYaw());
        double rightX = -Math.cos(yaw);
        double rightZ = -Math.sin(yaw);
        double backX = Math.sin(yaw);
        double backZ = -Math.cos(yaw);
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();
        if (wings.get()) {
            spawnWings(px, py, pz, rightX, rightZ, backX, backZ, rgb);
        }
        if (aura.get()) {
            spawnAura(px, py, pz, rgb);
        }
        if (halo.get()) {
            for (int i = 0; i < 8; i++) {
                double a = ticks * 0.08 + i * (Math.PI * 2 / 8);
                ParticleUtil.dust(rgb, 0.7f, px + Math.cos(a) * 0.35, py + player.getHeight() + 0.35,
                        pz + Math.sin(a) * 0.35, 0, 0, 0);
            }
        }
        if (trail.get() && player.getVelocity().horizontalLengthSquared() > 0.0025) {
            for (int i = 0; i < density.getInt(); i++) {
                ParticleUtil.dust(rgb, 0.9f, px + (Math.random() - 0.5) * 0.4, py + 0.1, pz + (Math.random() - 0.5) * 0.4,
                        0, 0.02, 0);
            }
        }
    }

    private void spawnWings(double px, double py, double pz, double rx, double rz, double bx, double bz, int rgb) {
        double flap = Math.sin(ticks * 0.18) * 0.35;
        for (int side = -1; side <= 1; side += 2) {
            for (int k = 0; k < 4; k++) {
                double angle = 0.45 + k * 0.3 + flap;
                double length = 1.25 - k * 0.2;
                for (int step = 1; step <= 3; step++) {
                    double t = step / 3.0;
                    double lateral = side * (0.12 + Math.sin(angle) * length * t);
                    double height = 1.3 + Math.cos(angle) * length * t * 0.85 - k * 0.1 * t;
                    double back = 0.18 + length * t * 0.25;
                    ParticleUtil.dust(rgb, 0.8f, px + rx * lateral + bx * back, py + height,
                            pz + rz * lateral + bz * back, 0, 0, 0);
                }
            }
        }
    }

    private void spawnAura(double px, double py, double pz, int rgb) {
        int per = density.getInt() * 2;
        if (auraStyle.index() == 0) {
            for (int ring = 0; ring < 2; ring++) {
                double y = py + 0.35 + ring * 0.95 + Math.sin(ticks * 0.1 + ring) * 0.08;
                for (int i = 0; i < per; i++) {
                    double a = ticks * 0.14 * (ring == 0 ? 1 : -1) + i * (Math.PI * 2 / per);
                    ParticleUtil.dust(rgb, 0.7f, px + Math.cos(a) * 0.85, y, pz + Math.sin(a) * 0.85, 0, 0, 0);
                }
            }
        } else {
            for (int i = 0; i < per; i++) {
                double a = ticks * 0.2 + i * 0.8;
                double y = py + ((ticks * 0.03 + i * 0.22) % 2.0);
                ParticleUtil.dust(rgb, 0.7f, px + Math.cos(a) * 0.7, y, pz + Math.sin(a) * 0.7, 0, 0, 0);
            }
        }
    }
}
