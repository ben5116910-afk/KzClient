package com.kzclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Tecla GLFW asignable (0 o negativo = sin asignar). */
public final class KeySetting extends Setting {
    private int key;
    private boolean listening;
    private boolean wasDown;

    public KeySetting(String name) {
        super(name);
    }

    public int get() {
        return key;
    }

    public void set(int key) {
        this.key = Math.max(0, key);
    }

    public boolean isListening() {
        return listening;
    }

    public void setListening(boolean value) {
        this.listening = value;
    }

    /** Flanco de pulsacion: true solo en el tick en el que la tecla pasa a estar pulsada. */
    public boolean edge(boolean down) {
        boolean pressed = down && !wasDown;
        wasDown = down;
        return pressed;
    }

    @Override
    public void reset() {
        key = 0;
        listening = false;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(key);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            set(element.getAsInt());
        }
    }
}
