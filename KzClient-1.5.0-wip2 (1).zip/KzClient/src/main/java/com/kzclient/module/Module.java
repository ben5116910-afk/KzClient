package com.kzclient.module;

import com.kzclient.KzClient;
import com.kzclient.gui.ToggleAnim;
import com.kzclient.module.setting.KeySetting;
import com.kzclient.module.setting.Setting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private final ToggleAnim anim = new ToggleAnim();
    private final ToggleAnim expandAnim = new ToggleAnim();
    private final KeySetting bind = new KeySetting("Keybind");
    private boolean expanded;
    private boolean enabled;
    private boolean silent;
    private boolean defaultEnabled;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        settings.add(bind);
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    protected final void enableByDefault() {
        defaultEnabled = true;
        enabled = true;
    }

    /** Desactiva el modulo, restaura sus ajustes y su estado por defecto. */
    public final void resetToDefaults() {
        boolean wasSilent = silent;
        silent = true;
        setEnabled(false);
        for (Setting setting : settings) {
            setting.reset();
        }
        setEnabled(defaultEnabled);
        silent = wasSilent;
    }

    protected final void setSilent(boolean value) {
        this.silent = value;
    }

    public final String name() {
        return name;
    }

    public final String description() {
        return description;
    }

    public final Category category() {
        return category;
    }

    public final List<Setting> settings() {
        return Collections.unmodifiableList(settings);
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final ToggleAnim anim() {
        return anim;
    }

    /** Tecla para activar/desactivar el modulo (aparece al final de su tarjeta). */
    public final KeySetting bind() {
        return bind;
    }

    /** Estado de la tarjeta desplegable en la GUI (no se persiste). */
    public final boolean isExpanded() {
        return expanded;
    }

    public final void toggleExpanded() {
        expanded = !expanded;
    }

    public final ToggleAnim expandAnim() {
        return expandAnim;
    }

    /** Numero de ajustes propios del modulo (sin contar la tecla). */
    public final boolean hasOwnSettings() {
        return settings.size() > 1;
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        if (value && (!canEnable() || panicBlocks())) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
        if (!silent && KzClient.notifications() != null) {
            KzClient.notifications().push(name + (enabled ? " enabled" : " disabled"));
        }
    }

    /**
     * Restaura el estado guardado (config.json o perfil) SIN notificacion pero ejecutando onEnable/onDisable:
     * antes los modulos con hilos o estado (AntiAFK...) nunca arrancaban tras reiniciar el juego.
     */
    public final void restoreEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        if (value && !canEnable()) {
            return;
        }
        enabled = value;
        try {
            if (value) {
                onEnable();
            } else {
                onDisable();
            }
        } catch (RuntimeException ex) {
            KzClient.LOGGER.error("Error al restaurar el modulo {}", name, ex);
            enabled = false;
        }
    }

    private boolean panicBlocks() {
        return KzClient.modules() != null && KzClient.modules().panic().blocksEnable(this);
    }

    /** Apagado temporal de Panic: ejecuta onDisable (detiene tareas) sin notificacion y sin tocar la config. */
    public final void suspend() {
        if (!enabled) {
            return;
        }
        enabled = false;
        try {
            onDisable();
        } catch (RuntimeException ex) {
            KzClient.LOGGER.error("Error al suspender el modulo {}", name, ex);
        }
    }

    public boolean isPersistent() {
        return true;
    }

    protected boolean canEnable() {
        return true;
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void onTick() {
    }
}
