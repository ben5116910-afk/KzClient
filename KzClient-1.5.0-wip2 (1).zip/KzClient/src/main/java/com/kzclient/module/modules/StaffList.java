package com.kzclient.module.modules;

import com.kzclient.KzClient;
import com.kzclient.config.PlayerLists;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

/** Muestra quien de tus listas de staff y amigos (SETTINGS > Player lists) esta en el servidor. */
public final class StaffList extends Module {
    public record Entry(String name, boolean staff) {
    }

    private final BoolSetting showStaff = add(new BoolSetting("Show staff", true));
    private final BoolSetting showFriends = add(new BoolSetting("Show friends", true));
    private final BoolSetting notify = add(new BoolSetting("Notify joins/leaves", true));
    private Set<String> previous = new HashSet<>();
    private List<Entry> online = new ArrayList<>();
    private int timer;

    public StaffList() {
        super("StaffList", "Tracks your staff and friends lists online.", Category.MISC);
    }

    public List<Entry> online() {
        return Collections.unmodifiableList(online);
    }

    @Override
    protected void onEnable() {
        previous = new HashSet<>();
        online = new ArrayList<>();
        timer = 0;
    }

    @Override
    protected void onDisable() {
        online = new ArrayList<>();
    }

    @Override
    public void onTick() {
        if (timer-- > 0) {
            return;
        }
        timer = 20;
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) {
            return;
        }
        PlayerLists lists = KzClient.lists();
        Set<String> now = new HashSet<>();
        List<Entry> display = new ArrayList<>();
        for (PlayerListEntry entry : handler.getPlayerList()) {
            String name = entry.getProfile().name();
            boolean staff = lists.isStaff(name);
            boolean friend = KzClient.friends().isFriend(name);
            if ((staff && showStaff.get()) || (friend && showFriends.get())) {
                now.add(name.toLowerCase(Locale.ROOT));
                display.add(new Entry(name, staff));
            }
        }
        if (notify.get()) {
            for (Entry entry : display) {
                if (!previous.contains(entry.name().toLowerCase(Locale.ROOT)) && !previous.isEmpty()) {
                    KzClient.notifications().push(entry.name() + " joined");
                }
            }
            for (String name : previous) {
                if (!now.contains(name)) {
                    KzClient.notifications().push(name + " left");
                }
            }
        }
        previous = now;
        display.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        online = display;
    }
}
