package com.kzclient.module.setting;

import com.google.gson.JsonElement;

public abstract class Setting {
    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    public abstract JsonElement save();

    public abstract void load(JsonElement element);

    /** Vuelve al valor por defecto. */
    public abstract void reset();
}
