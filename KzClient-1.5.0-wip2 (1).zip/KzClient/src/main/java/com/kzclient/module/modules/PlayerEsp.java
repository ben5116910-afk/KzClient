package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;
import com.kzclient.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Resaltado de jugadores a traves de paredes: contorno glow + cajas, relleno, lineas y distancia. */
public final class PlayerEsp extends Module {
    private final BoolSetting glow = add(new BoolSetting("Glow", true));
    private final BoolSetting boxes = add(new BoolSetting("Boxes", true));
    private final BoolSetting fill = add(new BoolSetting("Fill", false));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final BoolSetting friendColor = add(new BoolSetting("Friends green", true));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final NumberSetting hue = add(new NumberSetting("Hue", 0, 360, 1, 335));
    private final NumberSetting range = add(new NumberSetting("Range", 16, 256, 8, 128));

    public PlayerEsp() {
        super("PlayerESP", "Boxes, lines and glow on players through walls.", Category.RENDER);
    }

    public boolean valid(Entity entity) {
        return mc.player != null && entity instanceof PlayerEntity player && entity != mc.player
                && player.isAlive() && mc.player.distanceTo(entity) <= range.get();
    }

    public boolean shouldGlow(Entity entity) {
        return glow.get() && valid(entity);
    }

    public int colorFor(Entity entity) {
        if (friendColor.get() && Targets.isFriend(entity)) {
            return 0xFF55FF9A;
        }
        float h = rainbow.get() ? (System.currentTimeMillis() % 4000L) / 4000f * 360f : hue.getFloat();
        return ColorUtil.hsv(h, 0.72f, 1f);
    }

    public boolean boxes() {
        return boxes.get();
    }

    public boolean fill() {
        return fill.get();
    }

    public boolean tracers() {
        return tracers.get();
    }

    public boolean distance() {
        return distance.get();
    }
}
