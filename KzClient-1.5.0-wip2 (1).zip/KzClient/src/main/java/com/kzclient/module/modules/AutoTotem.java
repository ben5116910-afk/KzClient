package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Mueve un totem a la mano secundaria cuando la vida baja del umbral. */
public final class AutoTotem extends Module {
    private final NumberSetting health = add(new NumberSetting("Health", 1, 19, 1, 8));
    private final NumberSetting delay = add(new NumberSetting("Delay", 0, 10, 1, 1));
    private final BoolSetting always = add(new BoolSetting("Always", false));
    private int cooldown;

    public AutoTotem() {
        super("AutoTotem", "Swaps a totem into your offhand on low health.", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        cooldown = 0;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null) {
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (player.currentScreenHandler != player.playerScreenHandler) {
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }
        float effective = player.getHealth() + player.getAbsorptionAmount();
        if (!always.get() && effective > health.get()) {
            return;
        }
        int slot = findTotemSlot(player);
        if (slot < 0) {
            return;
        }
        mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, player);
        cooldown = delay.getInt();
    }

    private int findTotemSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }
}
