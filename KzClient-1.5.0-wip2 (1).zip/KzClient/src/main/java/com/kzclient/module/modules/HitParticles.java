package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;
import com.kzclient.util.ParticleUtil;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/** Particulas al golpear una entidad (disparadas desde AttackEntityCallback). */
public final class HitParticles extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", 0, "Burst", "Ring", "Rise"));
    private final NumberSetting count = add(new NumberSetting("Count", 4, 60, 2, 18));
    private final NumberSetting hue = add(new NumberSetting("Hue", 0, 360, 1, 335));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final BoolSetting crit = add(new BoolSetting("Crit sparks", true));

    public HitParticles() {
        super("HitParticles", "Particles when you hit something.", Category.VISUALS);
    }

    public void burst(Entity target) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        Vec3d center = target.getBoundingBox().getCenter();
        double w = target.getWidth() * 0.5;
        double h = target.getHeight() * 0.5;
        int n = count.getInt();
        for (int i = 0; i < n; i++) {
            float hh = rainbow.get() ? random.nextFloat() * 360f : hue.getFloat() + random.nextFloat() * 30f - 15f;
            int rgb = ColorUtil.hsv(hh, 0.75f, 1f);
            switch (style.index()) {
                case 1 -> {
                    double a = i * Math.PI * 2 / n;
                    ParticleUtil.dust(rgb, 1.1f, center.x + Math.cos(a) * w, center.y, center.z + Math.sin(a) * w,
                            Math.cos(a) * 0.12, 0.02, Math.sin(a) * 0.12);
                }
                case 2 -> ParticleUtil.dust(rgb, 1.1f, center.x + random.nextDouble(-w, w), center.y - h,
                        center.z + random.nextDouble(-w, w), 0, random.nextDouble(0.08, 0.22), 0);
                default -> ParticleUtil.dust(rgb, 1.1f, center.x + random.nextDouble(-w, w),
                        center.y + random.nextDouble(-h, h), center.z + random.nextDouble(-w, w),
                        random.nextDouble(-0.25, 0.25), random.nextDouble(0.0, 0.3), random.nextDouble(-0.25, 0.25));
            }
        }
        if (crit.get()) {
            for (int i = 0; i < 6; i++) {
                ParticleUtil.spawn(ParticleTypes.CRIT, center.x, center.y, center.z,
                        random.nextDouble(-0.4, 0.4), random.nextDouble(0.0, 0.4), random.nextDouble(-0.4, 0.4));
            }
        }
    }
}
