package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Elige la mejor herramienta de la barra rapida al minar o golpear. */
public final class AutoTool extends Module {
    private final BoolSetting tools = add(new BoolSetting("Blocks", true));
    private final BoolSetting weapons = add(new BoolSetting("Weapons", true));
    private final BoolSetting switchBack = add(new BoolSetting("Switch back", true));
    private int previousSlot = -1;

    public AutoTool() {
        super("AutoTool", "Selects the best hotbar tool when mining or hitting.", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        restore();
    }

    private void restore() {
        if (previousSlot >= 0 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.currentScreen != null) {
            return;
        }
        if (!mc.options.attackKey.isPressed()) {
            if (switchBack.get()) {
                restore();
            } else {
                previousSlot = -1;
            }
            return;
        }
        HitResult hit = mc.crosshairTarget;
        if (hit == null) {
            return;
        }
        int current = player.getInventory().getSelectedSlot();
        int best = current;
        if (hit.getType() == HitResult.Type.BLOCK && tools.get()) {
            BlockState state = mc.world.getBlockState(((BlockHitResult) hit).getBlockPos());
            float bestSpeed = player.getInventory().getStack(current).getMiningSpeedMultiplier(state);
            for (int i = 0; i < 9; i++) {
                float speed = player.getInventory().getStack(i).getMiningSpeedMultiplier(state);
                if (speed > bestSpeed + 0.01f) {
                    bestSpeed = speed;
                    best = i;
                }
            }
        } else if (hit.getType() == HitResult.Type.ENTITY && weapons.get()
                && ((EntityHitResult) hit).getEntity() instanceof LivingEntity) {
            int bestScore = weaponScore(player.getInventory().getStack(current));
            for (int i = 0; i < 9; i++) {
                int score = weaponScore(player.getInventory().getStack(i));
                if (score > bestScore) {
                    bestScore = score;
                    best = i;
                }
            }
        }
        if (best != current) {
            if (previousSlot < 0) {
                previousSlot = current;
            }
            player.getInventory().setSelectedSlot(best);
        }
    }

    private static int weaponScore(ItemStack stack) {
        if (stack.isOf(Items.MACE)) {
            return 5;
        }
        if (stack.isIn(ItemTags.SWORDS)) {
            return 4;
        }
        if (stack.isIn(ItemTags.AXES)) {
            return 3;
        }
        if (stack.isOf(Items.TRIDENT)) {
            return 2;
        }
        return 0;
    }
}
