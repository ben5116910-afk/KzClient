package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Ataca cuando la mira esta sobre un objetivo valido. Se suspende al romper bloques. */
public final class TriggerBot extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final BoolSetting bosses = add(new BoolSetting("Bosses", true));
    private final BoolSetting ignoreFriends = add(new BoolSetting("Ignore friends", true));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon only", false));
    private final NumberSetting range = add(new NumberSetting("Range", 2.0, 6.0, 0.5, 3.5));
    private final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.5, 1.0, 0.05, 0.95));
    private final NumberSetting delay = add(new NumberSetting("Extra delay", 0, 10, 1, 0));
    private int wait;

    public TriggerBot() {
        super("TriggerBot", "Attacks when your crosshair is on a valid target.", Category.COMBAT);
    }

    private static boolean isWeapon(ItemStack stack) {
        return stack.isIn(ItemTags.SWORDS) || stack.isIn(ItemTags.AXES) || stack.isOf(Items.MACE)
                || stack.isOf(Items.TRIDENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null || mc.currentScreen != null || Targets.mining(mc)) {
            return;
        }
        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) {
            return;
        }
        Entity entity = ((EntityHitResult) hit).getEntity();
        if (!Targets.matches(entity, players.get(), mobs.get(), bosses.get())
                || (ignoreFriends.get() && Targets.isFriend(entity)) || player.distanceTo(entity) > range.get()) {
            return;
        }
        if (weaponOnly.get() && !isWeapon(player.getMainHandStack())) {
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < cooldown.getFloat()) {
            return;
        }
        mc.interactionManager.attackEntity(player, entity);
        player.swingHand(Hand.MAIN_HAND);
        wait = delay.getInt();
    }
}
