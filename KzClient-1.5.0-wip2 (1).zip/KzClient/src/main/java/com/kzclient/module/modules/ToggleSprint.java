package com.kzclient.module.modules;

import com.kzclient.KzClient;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Mantiene el sprint automaticamente cuando se cumplen las condiciones configuradas. */
public final class ToggleSprint extends Module {
    private final ModeSetting trigger = add(new ModeSetting("Trigger", 0, "Forward only", "Any direction"));
    private final NumberSetting minHunger = add(new NumberSetting("Min hunger", 7, 20, 1, 7));
    private final BoolSetting stopSneaking = add(new BoolSetting("Stop when sneaking", true));
    private final BoolSetting stopUsingItem = add(new BoolSetting("Stop using item", true));
    private final BoolSetting notify = add(new BoolSetting("Notify", false));
    private boolean engaged;
    private long lastNotice;

    public ToggleSprint() {
        super("ToggleSprint", "Keeps you sprinting while you move.", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        engaged = false;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.currentScreen != null) {
            return;
        }
        boolean forward = mc.options.forwardKey.isPressed();
        boolean moving = trigger.index() == 0 ? forward
                : forward || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed()
                        || mc.options.rightKey.isPressed();
        boolean allowed = moving
                && !(stopSneaking.get() && player.isSneaking())
                && !(stopUsingItem.get() && player.isUsingItem())
                && !player.horizontalCollision
                && !player.hasStatusEffect(StatusEffects.BLINDNESS)
                && player.getHungerManager().getFoodLevel() >= minHunger.getInt();
        if (allowed) {
            if (!player.isSprinting()) {
                player.setSprinting(true);
            }
            if (!engaged) {
                engaged = true;
                notice("Sprint engaged");
            }
        } else if (engaged) {
            engaged = false;
            notice("Sprint released");
        }
    }

    private void notice(String text) {
        long now = System.currentTimeMillis();
        if (notify.get() && now - lastNotice > 3000L) {
            lastNotice = now;
            KzClient.notifications().push(text);
        }
    }
}
