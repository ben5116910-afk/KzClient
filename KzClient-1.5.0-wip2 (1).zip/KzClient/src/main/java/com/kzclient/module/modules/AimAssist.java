package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Ayuda de apuntado suave. Se suspende siempre que el jugador esta rompiendo un bloque. */
public final class AimAssist extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final BoolSetting bosses = add(new BoolSetting("Bosses", true));
    private final BoolSetting ignoreFriends = add(new BoolSetting("Ignore friends", true));
    private final BoolSetting visibleOnly = add(new BoolSetting("Visible only", true));
    private final NumberSetting range = add(new NumberSetting("Range", 2.0, 8.0, 0.5, 4.5));
    private final NumberSetting angle = add(new NumberSetting("Angle", 5.0, 120.0, 5.0, 40.0));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 20.0, 1.0, 6.0));
    private final ModeSetting priority = add(new ModeSetting("Priority", 0, "Angle", "Distance", "Health"));
    private final BoolSetting onAttack = add(new BoolSetting("Only attacking", true));
    private final BoolSetting verticalAim = add(new BoolSetting("Vertical aim", true));

    public AimAssist() {
        super("AimAssist", "Smoothly nudges your aim toward targets.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.currentScreen != null || Targets.mining(mc)) {
            return;
        }
        if (onAttack.get() && !mc.options.attackKey.isPressed()) {
            return;
        }
        Entity target = Targets.best(mc, range.get(), angle.get(), players.get(), mobs.get(), bosses.get(),
                visibleOnly.get(), ignoreFriends.get(), priority.index());
        if (target == null) {
            return;
        }
        Vec3d aim = target.getBoundingBox().getCenter();
        float[] wanted = Targets.anglesTo(player.getEyePos(), aim);
        float factor = speed.getFloat() / 20f;
        float dyaw = MathHelper.wrapDegrees(wanted[0] - player.getYaw());
        player.setYaw(player.getYaw() + dyaw * factor);
        if (verticalAim.get()) {
            float dpitch = wanted[1] - player.getPitch();
            player.setPitch(MathHelper.clamp(player.getPitch() + dpitch * factor, -90f, 90f));
        }
    }
}
