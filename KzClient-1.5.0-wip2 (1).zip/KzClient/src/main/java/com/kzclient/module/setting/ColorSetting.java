package com.kzclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.kzclient.util.ColorUtil;

/** Color RGB opaco con selector HSV. Se guarda como entero 0xRRGGBB. */
public final class ColorSetting extends Setting {
    private final int defaultValue;
    private int value;
    private final float[] hsv = new float[3];
    private boolean open;
    private float openAnim;

    public ColorSetting(String name, int rgb) {
        super(name);
        this.defaultValue = 0xFF000000 | rgb;
        set(rgb);
    }

    /** ARGB opaco. */
    public int get() {
        return value;
    }

    public void set(int rgb) {
        this.value = 0xFF000000 | (rgb & 0xFFFFFF);
        ColorUtil.toHsv(value, hsv);
    }

    public void setHsv(float h, float s, float v) {
        hsv[0] = ((h % 360f) + 360f) % 360f;
        hsv[1] = Math.max(0f, Math.min(1f, s));
        hsv[2] = Math.max(0f, Math.min(1f, v));
        value = ColorUtil.hsv(hsv[0], hsv[1], hsv[2]);
    }

    public float hue() {
        return hsv[0];
    }

    public float saturation() {
        return hsv[1];
    }

    public float brightness() {
        return hsv[2];
    }

    public boolean isOpen() {
        return open;
    }

    public void toggleOpen() {
        open = !open;
    }

    public float openProgress() {
        return openAnim;
    }

    /** Animacion 0..1 de apertura del selector (se actualiza desde la GUI). */
    public float stepOpen(double dt) {
        float target = open ? 1f : 0f;
        openAnim += (target - openAnim) * (float) (1.0 - Math.exp(-dt * 16.0));
        if (Math.abs(target - openAnim) < 0.004f) {
            openAnim = target;
        }
        return openAnim;
    }

    @Override
    public void reset() {
        set(defaultValue);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value & 0xFFFFFF);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            set(element.getAsInt());
        }
    }
}
