package com.kzclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.kzclient.gui.ToggleAnim;

public final class BoolSetting extends Setting {
    private final boolean defaultValue;
    private boolean value;
    private final ToggleAnim anim = new ToggleAnim();

    public BoolSetting(String name, boolean value) {
        super(name);
        this.value = value;
        this.defaultValue = value;
    }

    @Override
    public void reset() {
        value = defaultValue;
    }

    public boolean get() {
        return value;
    }

    public void set(boolean v) {
        this.value = v;
    }

    public void toggle() {
        this.value = !this.value;
    }

    public ToggleAnim anim() {
        return anim;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isBoolean()) {
            value = element.getAsBoolean();
        }
    }
}
