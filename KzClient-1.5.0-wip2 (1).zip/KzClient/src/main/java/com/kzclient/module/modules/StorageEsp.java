package com.kzclient.module.modules;

import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.render.EspTarget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

public final class StorageEsp extends Module {
    private final BoolSetting chests = add(new BoolSetting("Chests", true));
    private final BoolSetting enderChests = add(new BoolSetting("Ender chests", true));
    private final BoolSetting barrels = add(new BoolSetting("Barrels", true));
    private final BoolSetting shulkers = add(new BoolSetting("Shulkers", true));
    private final BoolSetting fill = add(new BoolSetting("Fill", true));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", false));
    private final NumberSetting range = add(new NumberSetting("Range", 8, 96, 4, 48));
    private List<EspTarget> targets = new ArrayList<>();
    private int timer;

    public StorageEsp() {
        super("StorageESP", "Highlights chests, barrels and shulkers.", Category.RENDER);
    }

    public List<EspTarget> targets() {
        return Collections.unmodifiableList(targets);
    }

    public boolean tracers() {
        return tracers.get();
    }

    public boolean fill() {
        return fill.get();
    }

    @Override
    protected void onDisable() {
        targets = new ArrayList<>();
    }

    @Override
    public void onTick() {
        if (timer-- > 0) {
            return;
        }
        timer = 20;
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null) {
            return;
        }
        List<EspTarget> found = new ArrayList<>();
        ChunkPos origin = player.getChunkPos();
        int radius = (range.getInt() >> 4) + 1;
        double maxSq = range.get() * range.get();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(origin.x + dx, origin.z + dz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity entity : chunk.getBlockEntities().values()) {
                    int color = colorOf(entity);
                    if (color == 0 || entity.getPos().getSquaredDistance(player.getX(), player.getY(), player.getZ()) > maxSq) {
                        continue;
                    }
                    found.add(new EspTarget(new Box(entity.getPos()), color));
                }
            }
        }
        targets = found;
    }

    private int colorOf(BlockEntity entity) {
        if (entity instanceof EnderChestBlockEntity) {
            return enderChests.get() ? 0xFFB45CFF : 0;
        }
        if (entity instanceof ShulkerBoxBlockEntity) {
            return shulkers.get() ? 0xFFFF278F : 0;
        }
        if (entity instanceof BarrelBlockEntity) {
            return barrels.get() ? 0xFFC28A4A : 0;
        }
        if (entity instanceof ChestBlockEntity) {
            return chests.get() ? 0xFFFFB02E : 0;
        }
        return 0;
    }
}
