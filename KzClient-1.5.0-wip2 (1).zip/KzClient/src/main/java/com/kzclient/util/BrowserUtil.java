package com.kzclient.util;

import java.net.URI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;

public final class BrowserUtil {
    private BrowserUtil() {
    }

    public static void open(String url) {
        Util.getOperatingSystem().open(URI.create(url));
    }

    public static void copy(String text) {
        MinecraftClient.getInstance().keyboard.setClipboard(text);
    }
}
