package com.kzclient.util;

import com.kzclient.KzClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    private Targets() {
    }

    public static boolean isBoss(Entity entity) {
        return entity instanceof WitherEntity || entity instanceof EnderDragonEntity;
    }

    public static boolean matches(Entity entity, boolean players, boolean mobs, boolean bosses) {
        if (!(entity instanceof LivingEntity living) || !living.isAlive() || entity instanceof ArmorStandEntity) {
            return false;
        }
        if (entity instanceof PlayerEntity) {
            return players;
        }
        if (isBoss(entity)) {
            return bosses;
        }
        return mobs;
    }

    public static boolean isFriend(Entity entity) {
        return KzClient.friends() != null && KzClient.friends().isFriend(entity);
    }

    /** true si el jugador esta rompiendo un bloque: AimAssist y TriggerBot no deben actuar. */
    public static boolean mining(MinecraftClient mc) {
        if (mc.interactionManager != null && mc.interactionManager.isBreakingBlock()) {
            return true;
        }
        HitResult hit = mc.crosshairTarget;
        return mc.options.attackKey.isPressed() && hit != null && hit.getType() == HitResult.Type.BLOCK;
    }

    /** Devuelve {yaw, pitch} en grados para mirar de "from" a "to". */
    public static float[] anglesTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return new float[] {yaw, pitch};
    }

    /** priority: 0 = menor angulo, 1 = menor distancia, 2 = menor vida. */
    public static Entity best(MinecraftClient mc, double range, double fov, boolean players, boolean mobs,
                              boolean bosses, boolean visibleOnly, boolean ignoreFriends, int priority) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null) {
            return null;
        }
        Vec3d eye = player.getEyePos();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity entity : mc.world.getEntities()) {
            if (entity == player || !matches(entity, players, mobs, bosses) || (ignoreFriends && isFriend(entity))) {
                continue;
            }
            if (player.distanceTo(entity) > range || (visibleOnly && !player.canSee(entity))) {
                continue;
            }
            float[] angles = anglesTo(eye, entity.getBoundingBox().getCenter());
            double dyaw = MathHelper.wrapDegrees(angles[0] - player.getYaw());
            double dpitch = angles[1] - player.getPitch();
            double angle = Math.sqrt(dyaw * dyaw + dpitch * dpitch);
            if (angle > fov) {
                continue;
            }
            double score = switch (priority) {
                case 1 -> player.distanceTo(entity);
                case 2 -> ((LivingEntity) entity).getHealth();
                default -> angle;
            };
            if (score < bestScore) {
                bestScore = score;
                best = entity;
            }
        }
        return best;
    }
}
