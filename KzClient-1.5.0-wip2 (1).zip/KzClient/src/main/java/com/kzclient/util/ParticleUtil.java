package com.kzclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;

/** Unico punto donde se crean particulas del lado cliente. */
public final class ParticleUtil {
    private ParticleUtil() {
    }

    public static void spawn(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            // Firma verificada en Yarn 1.21.11: World.addParticleClient(ParticleEffect, boolean force, boolean canSpawnOnMinimal, x, y, z, vx, vy, vz)
            mc.world.addParticleClient(effect, false, false, x, y, z, vx, vy, vz);
        }
    }

    public static void dust(int rgb, float scale, double x, double y, double z, double vx, double vy, double vz) {
        spawn(new DustParticleEffect(rgb & 0xFFFFFF, scale), x, y, z, vx, vy, vz);
    }
}
