package com.kzclient.notify;

import com.kzclient.KzClient;
import java.util.ArrayList;
import java.util.List;

/** Cola de notificaciones temporales (toggles de modulos, staff, vanish). */
public final class NotificationManager {
    public record Notice(String text, long created) {
    }

    private static final long LIFETIME_MS = 3200L;
    private final List<Notice> notices = new ArrayList<>();

    public void push(String text) {
        if (KzClient.settings() != null && !KzClient.settings().notifications) {
            return;
        }
        notices.add(new Notice(text, System.currentTimeMillis()));
        while (notices.size() > 6) {
            notices.remove(0);
        }
    }

    public void clear() {
        notices.clear();
    }

    public List<Notice> active() {
        long now = System.currentTimeMillis();
        notices.removeIf(n -> now - n.created() > LIFETIME_MS);
        return notices;
    }

    public float alpha(Notice notice) {
        long age = System.currentTimeMillis() - notice.created();
        long left = LIFETIME_MS - age;
        if (left < 500L) {
            return Math.max(0f, left / 500f);
        }
        return Math.min(1f, age / 150f);
    }
}
