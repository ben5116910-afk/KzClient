package com.kzclient.social;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kzclient.KzClient;
import com.kzclient.config.ListFiles;
import com.kzclient.config.PlayerLists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * API central de amigos. TODOS los modulos (AimAssist, TriggerBot, TargetESP, Nametags, Radar, PlayerESP...)
 * deben consultar {@link #isFriend(Entity)} / {@link #isFriend(String)} y no mantener listas propias.
 * Persistencia: config/kzclient/friends.json. El "estado" solo refleja lo que el servidor publica:
 * un amigo figura como online si aparece en la lista de jugadores del servidor actual.
 */
public final class FriendsManager {
    public static final int MAX_NAME = 16;

    /** Amigo guardado. El UUID se completa la primera vez que se ve al jugador en un servidor (puede ser null). */
    public static final class Friend {
        private final String name;
        private UUID uuid;
        private final long addedAt;

        Friend(String name, UUID uuid, long addedAt) {
            this.name = name;
            this.uuid = uuid;
            this.addedAt = addedAt;
        }

        public String name() {
            return name;
        }

        public UUID uuid() {
            return uuid;
        }

        public long addedAt() {
            return addedAt;
        }
    }

    public enum AddResult {
        ADDED, INVALID, DUPLICATE, SELF
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final List<Friend> friends = new ArrayList<>();
    private final Path file = ListFiles.dir().resolve("friends.json");

    // ------------------------------------------------------------ consulta

    public boolean isFriend(String name) {
        return find(name) != null;
    }

    public boolean isFriend(UUID uuid) {
        if (uuid == null) {
            return false;
        }
        for (Friend friend : friends) {
            if (uuid.equals(friend.uuid)) {
                return true;
            }
        }
        return false;
    }

    public boolean isFriend(Entity entity) {
        if (!(entity instanceof PlayerEntity player)) {
            return false;
        }
        return isFriend(player.getUuid()) || isFriend(player.getName().getString());
    }

    private Friend find(String name) {
        if (name == null) {
            return null;
        }
        for (Friend friend : friends) {
            if (friend.name.equalsIgnoreCase(name)) {
                return friend;
            }
        }
        return null;
    }

    /** Copia ordenada por nombre. */
    public List<Friend> list() {
        List<Friend> copy = new ArrayList<>(friends);
        copy.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        return Collections.unmodifiableList(copy);
    }

    public int count() {
        return friends.size();
    }

    /** Entrada de la lista de jugadores del servidor actual, o null si el amigo no esta (o no hay servidor). */
    public PlayerListEntry onlineEntry(Friend friend) {
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler == null) {
            return null;
        }
        for (PlayerListEntry entry : handler.getPlayerList()) {
            if (entry.getProfile().name().equalsIgnoreCase(friend.name)) {
                return entry;
            }
        }
        return null;
    }

    public boolean isOnline(Friend friend) {
        return onlineEntry(friend) != null;
    }

    // ------------------------------------------------------------ edicion

    public AddResult add(String rawName) {
        String name = rawName == null ? "" : rawName.trim();
        if (name.isEmpty() || name.length() > MAX_NAME || !name.matches("[A-Za-z0-9_]+")) {
            return AddResult.INVALID;
        }
        if (find(name) != null) {
            return AddResult.DUPLICATE;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getName().getString().equalsIgnoreCase(name)) {
            return AddResult.SELF;
        }
        friends.add(new Friend(name, null, System.currentTimeMillis()));
        save();
        notify(name + " added to friends");
        return AddResult.ADDED;
    }

    public boolean remove(String name) {
        Friend friend = find(name);
        if (friend == null) {
            return false;
        }
        friends.remove(friend);
        save();
        notify(friend.name + " removed from friends");
        return true;
    }

    /** Completa el UUID de los amigos conocidos que estan en el servidor (una vez por segundo basta). */
    public void learnUuids() {
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler == null) {
            return;
        }
        boolean changed = false;
        for (PlayerListEntry entry : handler.getPlayerList()) {
            Friend friend = find(entry.getProfile().name());
            if (friend != null && friend.uuid == null) {
                friend.uuid = entry.getProfile().id();
                changed = true;
            }
        }
        if (changed) {
            save();
        }
    }

    private static void notify(String text) {
        if (KzClient.notifications() != null) {
            KzClient.notifications().push(text);
        }
    }

    // ---------------------------------------------------------- persistencia

    public void load() {
        friends.clear();
        if (Files.exists(file)) {
            try {
                JsonElement parsed = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8));
                if (parsed.isJsonObject() && parsed.getAsJsonObject().has("friends")
                        && parsed.getAsJsonObject().get("friends").isJsonArray()) {
                    for (JsonElement element : parsed.getAsJsonObject().getAsJsonArray("friends")) {
                        if (!element.isJsonObject() || !element.getAsJsonObject().has("name")) {
                            continue;
                        }
                        JsonObject entry = element.getAsJsonObject();
                        UUID uuid = null;
                        if (entry.has("uuid") && entry.get("uuid").isJsonPrimitive()) {
                            try {
                                uuid = UUID.fromString(entry.get("uuid").getAsString());
                            } catch (IllegalArgumentException ignored) {
                                uuid = null;
                            }
                        }
                        long at = entry.has("addedAt") ? entry.get("addedAt").getAsLong() : 0L;
                        String name = entry.get("name").getAsString();
                        if (find(name) == null) {
                            friends.add(new Friend(name, uuid, at));
                        }
                    }
                }
            } catch (IOException | RuntimeException ex) {
                KzClient.LOGGER.error("No se pudo leer friends.json", ex);
                try {
                    Files.copy(file, file.resolveSibling("friends.json.corrupt-" + System.currentTimeMillis()));
                } catch (IOException | RuntimeException ignored) {
                    // se continua con la lista vacia
                }
            }
            return;
        }
        migrateLegacy();
    }

    /** Importa los amigos que estaban en lists.json (version 1.4.0) la primera vez. */
    private void migrateLegacy() {
        PlayerLists legacy = KzClient.lists();
        if (legacy == null) {
            return;
        }
        boolean any = false;
        for (String name : legacy.list(PlayerLists.Kind.FRIEND)) {
            if (find(name) == null) {
                friends.add(new Friend(name, null, System.currentTimeMillis()));
                any = true;
            }
        }
        if (any) {
            for (Friend friend : friends) {
                legacy.remove(PlayerLists.Kind.FRIEND, friend.name);
            }
            save();
        }
    }

    public void save() {
        JsonObject root = new JsonObject();
        JsonArray array = new JsonArray();
        for (Friend friend : friends) {
            JsonObject entry = new JsonObject();
            entry.addProperty("name", friend.name);
            if (friend.uuid != null) {
                entry.addProperty("uuid", friend.uuid.toString());
            }
            entry.addProperty("addedAt", friend.addedAt);
            array.add(entry);
        }
        root.add("friends", array);
        try {
            Files.createDirectories(file.getParent());
            Path temp = file.resolveSibling("friends.json.tmp");
            Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
            Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            KzClient.LOGGER.error("No se pudo guardar friends.json", ex);
        }
    }

    /** Para busquedas de la GUI: coincidencia por subcadena sin distinguir mayusculas. */
    public static boolean matches(Friend friend, String query) {
        return query == null || query.isBlank() || friend.name.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT));
    }
}
