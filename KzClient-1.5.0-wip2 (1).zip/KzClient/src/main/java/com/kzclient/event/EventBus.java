package com.kzclient.event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Bus de eventos minimo: suscripcion por clase exacta de evento. */
public final class EventBus {
    private final Map<Class<?>, List<Consumer<Object>>> handlers = new HashMap<>();

    public <T> void subscribe(Class<T> type, Consumer<T> handler) {
        handlers.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>())
                .add(o -> handler.accept(type.cast(o)));
    }

    public void post(Object event) {
        List<Consumer<Object>> list = handlers.get(event.getClass());
        if (list == null) {
            return;
        }
        for (Consumer<Object> handler : list) {
            handler.accept(event);
        }
    }
}
