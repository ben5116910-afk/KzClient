package com.kzclient.event;

import net.minecraft.client.MinecraftClient;

public record ClientTickEvent(MinecraftClient client) {
}
