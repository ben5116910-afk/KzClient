package com.kzclient.event;

/** Se emite al salir de un mundo o servidor. */
public record DisconnectEvent(long timestamp) {
    public DisconnectEvent() {
        this(System.currentTimeMillis());
    }
}
