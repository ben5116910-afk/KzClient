package com.kzclient.feature;

import com.kzclient.KzClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Carga por nombre las funciones opcionales que se compilaron en este jar. */
public final class FeatureLoader {
    private static final String[] KNOWN = {
            "com.kzclient.feature.skinviewer.SkinViewerFeature",
            "com.kzclient.feature.glint.GlintFeature"
    };
    private static final List<Feature> LOADED = new ArrayList<>();
    private static final List<String> FAILED = new ArrayList<>();

    private FeatureLoader() {
    }

    /** Instancia las funciones presentes. Una funcion que falla al cargar se omite y se registra el motivo. */
    public static List<Feature> load() {
        if (!LOADED.isEmpty() || !FAILED.isEmpty()) {
            return loaded();
        }
        for (String name : KNOWN) {
            try {
                Class<?> type = Class.forName(name);
                LOADED.add((Feature) type.getDeclaredConstructor().newInstance());
            } catch (ClassNotFoundException ex) {
                // no compilada en este jar: es lo normal si se desactivo con -Pfeature.<id>=false
            } catch (ReflectiveOperationException | LinkageError | RuntimeException ex) {
                FAILED.add(name.substring(name.lastIndexOf('.') + 1) + ": " + ex);
                KzClient.LOGGER.error("No se pudo cargar la funcion {}", name, ex);
            }
        }
        return loaded();
    }

    public static List<Feature> loaded() {
        return Collections.unmodifiableList(LOADED);
    }

    public static List<String> failed() {
        return Collections.unmodifiableList(FAILED);
    }

    public static void initAll() {
        for (Feature feature : LOADED) {
            try {
                feature.init();
            } catch (RuntimeException | LinkageError ex) {
                FAILED.add(feature.id() + ": " + ex);
                KzClient.LOGGER.error("Error al iniciar la funcion {}", feature.id(), ex);
            }
        }
    }
}
