package com.kzclient.feature;

import com.kzclient.module.Module;
import java.util.List;

/**
 * Funcion opcional que depende de APIs internas de Minecraft 1.21.11 (render, modelos) que no se pudieron
 * verificar sin compilar. Cada una vive en su propio directorio src/features/&lt;id&gt; y se activa/desactiva
 * con una propiedad de Gradle (-Pfeature.&lt;id&gt;=false). El codigo principal NUNCA referencia estas clases
 * directamente: {@link FeatureLoader} las busca por nombre, asi que quitar una funcion no rompe la compilacion.
 */
public interface Feature {
    String id();

    String description();

    /** Modulos que aporta la funcion (se registran antes de construir las listas por categoria). */
    default List<Module> modules() {
        return List.of();
    }

    /** Se llama una vez, despues de construir los modulos y el bus de eventos. */
    default void init() {
    }
}
