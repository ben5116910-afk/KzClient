package com.kzclient.hud.widgets;

import com.kzclient.hud.TextWidget;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

public final class PingWidget extends TextWidget {
    public PingWidget() {
        super("ping", "Ping", "PING", 6, 48);
    }

    @Override
    protected String text() {
        int latency = 0;
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler != null && mc.player != null) {
            PlayerListEntry entry = handler.getPlayerListEntry(mc.player.getUuid());
            if (entry != null) {
                latency = entry.getLatency();
            }
        }
        return "PING " + latency + "ms";
    }
}
