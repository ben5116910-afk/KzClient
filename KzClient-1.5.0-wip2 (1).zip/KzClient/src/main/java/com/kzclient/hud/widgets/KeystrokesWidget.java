package com.kzclient.hud.widgets;

import com.kzclient.gui.Render2D;
import com.kzclient.gui.ThemePalette;
import com.kzclient.hud.HudWidget;
import net.minecraft.client.gui.DrawContext;

public final class KeystrokesWidget extends HudWidget {
    private static final int GAP = 2;
    private static final int SPACE_HEIGHT = 12;

    public KeystrokesWidget() {
        super("keystrokes", "Keystrokes", "KEYS", 6, 132);
    }

    private int key() {
        return Math.max(10, (contentWidth() - GAP * 2) / 3);
    }

    @Override
    protected int autoWidth() {
        return 20 * 3 + GAP * 2;
    }

    @Override
    protected int contentHeight() {
        return key() * 2 + GAP * 2 + SPACE_HEIGHT;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        int k = key();
        key(ctx, x + k + GAP, y, k, k, "W", mc.options.forwardKey.isPressed());
        key(ctx, x, y + k + GAP, k, k, "A", mc.options.leftKey.isPressed());
        key(ctx, x + k + GAP, y + k + GAP, k, k, "S", mc.options.backKey.isPressed());
        key(ctx, x + 2 * (k + GAP), y + k + GAP, k, k, "D", mc.options.rightKey.isPressed());
        key(ctx, x, y + 2 * (k + GAP), k * 3 + GAP * 2, SPACE_HEIGHT, "-", mc.options.jumpKey.isPressed());
    }

    private void key(DrawContext ctx, int x, int y, int w, int h, String label, boolean pressed) {
        if (pressed) {
            Render2D.roundedRect(ctx, x, y, w, h, 4, accent());
        } else if (!minimal()) {
            Render2D.roundedRect(ctx, x, y, w, h, 4, mulAlpha(0xB40D0812));
        } else {
            Render2D.outline(ctx, x, y, x + w, y + h, dimColor());
        }
        Render2D.textCentered(ctx, mc.textRenderer, label, x, y + (h - 8) / 2 + 1, w,
                pressed ? mulAlpha(ThemePalette.BACKGROUND) : textColor());
    }
}
