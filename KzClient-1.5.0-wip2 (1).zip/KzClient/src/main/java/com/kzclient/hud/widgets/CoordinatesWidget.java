package com.kzclient.hud.widgets;

import com.kzclient.hud.TextWidget;

public final class CoordinatesWidget extends TextWidget {
    public CoordinatesWidget() {
        super("coordinates", "Coordinates", "XYZ", 6, 68);
    }

    @Override
    protected String text() {
        if (mc.player == null) {
            return "XYZ 0 0 0";
        }
        return "XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
    }
}
