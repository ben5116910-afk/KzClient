package com.kzclient.hud.widgets;

import com.kzclient.gui.Render2D;
import com.kzclient.gui.ThemePalette;
import com.kzclient.hud.HudWidget;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ColorSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Radar circular centrado en el jugador (arriba = hacia donde miras). Cada tipo de entidad tiene su propia forma
 * y color: jugadores (cuadrado), amigos (cuadrado verde), monstruos (rombo), animales (punto) y otros (punto tenue).
 * Se recorre la lista de entidades del mundo en cada fotograma, asi que nunca dibuja entidades que ya no existen.
 */
public final class RadarWidget extends HudWidget {
    private final NumberSetting range = add(new NumberSetting("Range (blocks)", 8, 128, 4, 32));
    private final NumberSetting dot = add(new NumberSetting("Dot size", 1, 4, 1, 2));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting monsters = add(new BoolSetting("Monsters", true));
    private final BoolSetting animals = add(new BoolSetting("Animals", true));
    private final BoolSetting others = add(new BoolSetting("Other mobs", false));
    private final BoolSetting rings = add(new BoolSetting("Range rings", true));
    private final BoolSetting cardinal = add(new BoolSetting("Direction marker", true));
    private final ColorSetting playerColor = add(new ColorSetting("Player color", 0xFF278F));
    private final ColorSetting friendColor = add(new ColorSetting("Friend color", 0x55FF9A));
    private final ColorSetting monsterColor = add(new ColorSetting("Monster color", 0xFF5555));
    private final ColorSetting animalColor = add(new ColorSetting("Animal color", 0xFFD34D));
    private final ColorSetting otherColor = add(new ColorSetting("Other color", 0x9C91A0));

    public RadarWidget() {
        super("radar", "Radar", "RADAR", 9999, 6);
    }

    @Override
    protected int autoWidth() {
        return 64;
    }

    @Override
    protected int contentHeight() {
        return contentWidth();
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        int size = contentWidth();
        if (minimal()) {
            Render2D.roundedPanel(ctx, x, y, size, size, size / 2, mulAlpha(0x200D0812), dimColor());
        } else {
            Render2D.roundedRect(ctx, x, y, size, size, size / 2, mulAlpha(0xB40D0812));
        }
        int cx = x + size / 2;
        int cy = y + size / 2;
        double half = size / 2.0 - 4.0;
        ctx.fill(cx - size / 2 + 4, cy, cx + size / 2 - 4, cy + 1, mulAlpha(ThemePalette.GRID));
        ctx.fill(cx, cy - size / 2 + 4, cx + 1, cy + size / 2 - 4, mulAlpha(ThemePalette.GRID));
        if (rings.get()) {
            int r = (int) Math.round(half / 2.0);
            Render2D.outline(ctx, cx - r, cy - r, cx + r, cy + r, mulAlpha(ThemePalette.GRID));
        }
        if (cardinal.get()) {
            ctx.drawText(mc.textRenderer, "F", cx - 2, y + 1, dimColor(), false);
        }
        if (mc.player == null || mc.world == null) {
            return;
        }
        double yaw = Math.toRadians(mc.player.getYaw());
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        double max = range.get();
        int d = dot.getInt();
        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player || !(entity instanceof LivingEntity living) || !living.isAlive()
                    || entity instanceof ArmorStandEntity) {
                continue;
            }
            int kind;
            int color;
            if (entity instanceof PlayerEntity) {
                if (!players.get()) {
                    continue;
                }
                kind = 0;
                color = Targets.isFriend(entity) ? friendColor.get() : playerColor.get();
            } else if (entity instanceof HostileEntity) {
                if (!monsters.get()) {
                    continue;
                }
                kind = 1;
                color = monsterColor.get();
            } else if (entity instanceof AnimalEntity) {
                if (!animals.get()) {
                    continue;
                }
                kind = 2;
                color = animalColor.get();
            } else {
                if (!others.get()) {
                    continue;
                }
                kind = 2;
                color = otherColor.get();
            }
            double dx = entity.getX() - mc.player.getX();
            double dz = entity.getZ() - mc.player.getZ();
            double px = (dx * rx + dz * rz) / max * half;
            double py = -(dx * fx + dz * fz) / max * half;
            if (px * px + py * py > half * half) {
                continue;
            }
            int ex = cx + (int) Math.round(px);
            int ey = cy + (int) Math.round(py);
            int argb = mulAlpha(color);
            switch (kind) {
                case 0 -> ctx.fill(ex - d, ey - d, ex + d + 1, ey + d + 1, argb);
                case 1 -> {
                    ctx.fill(ex - d, ey, ex + d + 1, ey + 1, argb);
                    ctx.fill(ex, ey - d, ex + 1, ey + d + 1, argb);
                    ctx.fill(ex - d + 1, ey - 1, ex + d, ey + 2, argb);
                }
                default -> Render2D.roundedRect(ctx, ex - d + 1, ey - d + 1, d * 2 - 1, d * 2 - 1, d, argb);
            }
        }
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, mulAlpha(0xFFFFFFFF));
    }
}
