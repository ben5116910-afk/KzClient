package com.kzclient.hud.widgets;

import com.kzclient.hud.HudWidget;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

public final class EffectsWidget extends HudWidget {
    public EffectsWidget() {
        super("effects", "Effects", "FX", 9999, 84);
    }

    private List<String> lines() {
        List<String> lines = new ArrayList<>();
        if (mc.player == null) {
            return lines;
        }
        for (StatusEffectInstance effect : mc.player.getStatusEffects()) {
            String name = effect.getEffectType().value().getName().getString();
            String time;
            if (effect.isInfinite()) {
                time = "inf";
            } else {
                int seconds = effect.getDuration() / 20;
                time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            }
            lines.add(name + " " + (effect.getAmplifier() + 1) + "  " + time);
        }
        return lines;
    }

    @Override
    protected int autoWidth() {
        int w = 90;
        for (String line : lines()) {
            w = Math.max(w, mc.textRenderer.getWidth(line) + 16);
        }
        return w;
    }

    @Override
    protected int contentHeight() {
        return Math.max(16, lines().size() * 12 + 4);
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        List<String> lines = lines();
        if (lines.isEmpty()) {
            return;
        }
        int w = contentWidth();
        box(ctx, x, y, w, contentHeight());
        int ly = y + 4;
        for (String line : lines) {
            label(ctx, line, x, ly, w, textColor());
            ly += 12;
        }
    }
}
