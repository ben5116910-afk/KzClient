package com.kzclient.hud.widgets;

import com.kzclient.KzClient;
import com.kzclient.hud.HudWidget;
import com.kzclient.module.modules.AntiAfk;
import net.minecraft.client.gui.DrawContext;

/** Indicador del modulo AntiAFK: solo se dibuja con el modulo activo y "HUD indicator" encendido. */
public final class AntiAfkWidget extends HudWidget {
    public AntiAfkWidget() {
        super("antiafk", "AntiAFK", "AFK", 6, 68);
    }

    private AntiAfk module() {
        return KzClient.modules().get(AntiAfk.class);
    }

    private boolean visible() {
        AntiAfk m = module();
        return m != null && m.isEnabled() && m.showHud();
    }

    @Override
    protected int autoWidth() {
        return visible() ? mc.textRenderer.getWidth(module().statusText()) + 16 : 90;
    }

    @Override
    protected int contentHeight() {
        return 16;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        if (!visible()) {
            return;
        }
        AntiAfk m = module();
        int w = contentWidth();
        box(ctx, x, y, w, 16);
        int color = !m.pauseReason().isEmpty() ? dimColor() : m.isRunning() ? accent() : textColor();
        label(ctx, m.statusText(), x, y + 4, w, color);
    }
}
