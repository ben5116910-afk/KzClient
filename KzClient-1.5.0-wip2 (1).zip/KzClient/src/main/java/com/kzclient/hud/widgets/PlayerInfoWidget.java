package com.kzclient.hud.widgets;

import com.kzclient.hud.TextWidget;

/** Nombre, vida y hambre del jugador. */
public final class PlayerInfoWidget extends TextWidget {
    public PlayerInfoWidget() {
        super("playerinfo", "Player info", "INFO", 6, 108);
    }

    @Override
    protected String text() {
        if (mc.player == null) {
            return "PLAYER  HP 20  FOOD 20";
        }
        return mc.player.getName().getString() + "  HP " + Math.round(mc.player.getHealth()) + "  FOOD "
                + mc.player.getHungerManager().getFoodLevel();
    }
}
