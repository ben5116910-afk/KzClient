package com.kzclient.hud.widgets;

import com.kzclient.hud.TextWidget;
import java.util.Locale;
import net.minecraft.util.math.MathHelper;

public final class DirectionWidget extends TextWidget {
    public DirectionWidget() {
        super("direction", "Direction", "DIR", 6, 88);
    }

    @Override
    protected String text() {
        if (mc.player == null) {
            return "DIR NORTH 0";
        }
        String facing = mc.player.getHorizontalFacing().asString().toUpperCase(Locale.ROOT);
        return "DIR " + facing + " " + Math.round(MathHelper.wrapDegrees(mc.player.getYaw()));
    }
}
