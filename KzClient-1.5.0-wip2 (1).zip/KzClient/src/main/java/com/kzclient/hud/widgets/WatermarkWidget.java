package com.kzclient.hud.widgets;

import com.kzclient.KzClient;
import com.kzclient.hud.HudWidget;
import net.minecraft.client.gui.DrawContext;

public final class WatermarkWidget extends HudWidget {
    public WatermarkWidget() {
        super("watermark", "Watermark", "KZ", 6, 6);
    }

    @Override
    protected int autoWidth() {
        return mc.textRenderer.getWidth("KZ") + mc.textRenderer.getWidth(KzClient.brand(true)) + 24;
    }

    @Override
    protected int contentHeight() {
        return 16;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        int w = contentWidth();
        box(ctx, x, y, w, 16);
        int kz = mc.textRenderer.getWidth("KZ");
        int total = kz + 6 + mc.textRenderer.getWidth(KzClient.brand(true));
        int start = x + 8;
        if (w > total + 16) {
            start = x + (w - total) / 2;
        }
        ctx.drawText(mc.textRenderer, "KZ", start, y + 4, accent(), minimal());
        ctx.drawText(mc.textRenderer, KzClient.brand(true), start + kz + 6, y + 4, textColor(), minimal());
    }
}
