package com.kzclient.hud.widgets;

import com.kzclient.KzClient;
import com.kzclient.hud.HudWidget;
import com.kzclient.input.KeyNames;
import com.kzclient.module.Module;
import com.kzclient.module.modules.HudQuickEditor;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;

/**
 * Lista dinamica de modulos activos. Cada fila entra y sale con una animacion propia (deslizamiento + fundido).
 * Se oculta por completo mientras Panic esta activo y nunca muestra modulos apagados una vez termina su salida.
 */
public final class ActiveModulesWidget extends HudWidget {
    private static final int ROW_H = 13;

    private final ModeSetting order = add(new ModeSetting("Order", 0, "Longest first", "Alphabetical", "Category"));
    private final BoolSetting keys = add(new BoolSetting("Show keybind", true));
    private final BoolSetting dot = add(new BoolSetting("Status dot", true));
    private final BoolSetting background = add(new BoolSetting("Row background", true));
    private final NumberSetting animSpeed = add(new NumberSetting("Animation speed", 4, 20, 1, 10));

    private final Map<Module, Float> progress = new IdentityHashMap<>();
    private long lastNanos;

    public ActiveModulesWidget() {
        super("activemodules", "Active Modules", "AM", 6, 120);
    }

    private boolean listed(Module module) {
        return module.isPersistent() && !(module instanceof HudQuickEditor);
    }

    /** Avanza las animaciones. Se llama una vez por fotograma desde draw(). */
    private void advance() {
        long now = System.nanoTime();
        double dt = lastNanos == 0L ? 0.016 : Math.min(0.1, (now - lastNanos) / 1.0e9);
        lastNanos = now;
        boolean panic = KzClient.modules().panic().isActive();
        float step = (float) (dt * animSpeed.get());
        for (Module module : KzClient.modules().all()) {
            if (!listed(module)) {
                continue;
            }
            boolean on = module.isEnabled() && !panic;
            Float current = progress.get(module);
            if (current == null) {
                if (!on) {
                    continue;
                }
                current = 0f;
            }
            float next = on ? Math.min(1f, current + step) : Math.max(0f, current - step);
            if (next <= 0f && !on) {
                progress.remove(module);
            } else {
                progress.put(module, next);
            }
        }
    }

    private String label(Module module) {
        String text = module.name();
        int key = module.bind().get();
        if (keys.get() && key > 0) {
            text += " [" + KeyNames.of(key) + "]";
        }
        return text;
    }

    private List<Module> rows() {
        List<Module> list = new ArrayList<>(progress.keySet());
        switch (order.index()) {
            case 1 -> list.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
            case 2 -> list.sort((a, b) -> a.category() != b.category()
                    ? Integer.compare(a.category().ordinal(), b.category().ordinal())
                    : a.name().compareToIgnoreCase(b.name()));
            default -> list.sort((a, b) -> Integer.compare(mc.textRenderer.getWidth(label(b)),
                    mc.textRenderer.getWidth(label(a))));
        }
        return list;
    }

    @Override
    protected int autoWidth() {
        int w = 80;
        for (Module module : progress.keySet()) {
            w = Math.max(w, mc.textRenderer.getWidth(label(module)) + 24);
        }
        return w;
    }

    @Override
    protected int contentHeight() {
        return Math.max(ROW_H, progress.size() * ROW_H);
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        advance();
        if (progress.isEmpty()) {
            return;
        }
        int w = contentWidth();
        int ry = y;
        for (Module module : rows()) {
            float p = progress.get(module);
            float eased = 1f - (1f - p) * (1f - p);
            int alpha = Math.round(255 * eased);
            int slide = Math.round((1f - eased) * 14f);
            int rx = x + slide;
            if (background.get() && !minimal()) {
                ctx.fill(rx, ry, rx + w, ry + ROW_H - 1, mulAlpha(ColorUtil.withAlpha(0x0D0812, alpha * 180 / 255)));
            }
            if (dot.get()) {
                ctx.fill(rx + 5, ry + 4, rx + 9, ry + 8, ColorUtil.withAlpha(accent() & 0xFFFFFF, alpha));
            }
            label(ctx, label(module), rx + (dot.get() ? 8 : 0), ry + 2, w - (dot.get() ? 8 : 0),
                    ColorUtil.withAlpha(textColor() & 0xFFFFFF, alpha * ((textColor() >>> 24) & 0xFF) / 255));
            ry += ROW_H;
        }
    }
}
