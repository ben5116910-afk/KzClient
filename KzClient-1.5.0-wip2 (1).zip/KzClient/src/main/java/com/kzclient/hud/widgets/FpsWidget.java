package com.kzclient.hud.widgets;

import com.kzclient.hud.TextWidget;

public final class FpsWidget extends TextWidget {
    public FpsWidget() {
        super("fps", "FPS", "FPS", 6, 28);
    }

    @Override
    protected String text() {
        return "FPS " + mc.getCurrentFps();
    }
}
