package com.kzclient.hud;

import com.kzclient.gui.Render2D;
import com.kzclient.gui.ThemePalette;
import com.kzclient.gui.ToggleAnim;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ModeSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.module.setting.Setting;
import com.kzclient.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Elemento del HUD con posicion, escala, tamano, color, opacidad, estilo y alineacion propios. */
public abstract class HudWidget {
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private final String id;
    private final String name;
    private final String shortName;
    private final int defaultX;
    private final int defaultY;
    private final ToggleAnim anim = new ToggleAnim();
    private final List<Setting> settings = new ArrayList<>();
    private final NumberSetting scale = new NumberSetting("Scale", 0.5, 2.0, 0.1, 1.0);
    private final NumberSetting width = new NumberSetting("Width (0 = auto)", 0, 300, 10, 0);
    private final NumberSetting opacity = new NumberSetting("Opacity %", 20, 100, 5, 100);
    private final BoolSetting customColor = new BoolSetting("Custom color", false);
    private final NumberSetting hue = new NumberSetting("Hue", 0, 360, 1, 335);
    private final ModeSetting style = new ModeSetting("Style", 0, "Filled", "Outline", "Minimal");
    private final ModeSetting align = new ModeSetting("Align", 0, "Left", "Center", "Right");
    private int x;
    private int y;
    private boolean enabled = true;

    protected HudWidget(String id, String name, String shortName, int defaultX, int defaultY) {
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
        this.x = defaultX;
        this.y = defaultY;
        settings.add(scale);
        settings.add(width);
        settings.add(opacity);
        settings.add(customColor);
        settings.add(hue);
        settings.add(style);
        settings.add(align);
    }

    /** Ajustes propios del widget (aparecen en el editor de HUD y se guardan en config.json). */
    protected final <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    /** Ancho natural del contenido (sin escala). */
    protected abstract int autoWidth();

    /** Alto del contenido (sin escala). */
    protected abstract int contentHeight();

    /** Dibuja el contenido en (x, y) con coordenadas sin escalar. */
    protected abstract void draw(DrawContext ctx, int x, int y);

    public final int contentWidth() {
        int fixed = width.getInt();
        return fixed > 0 ? Math.max(24, fixed) : autoWidth();
    }

    public final int width() {
        return Math.max(1, Math.round(contentWidth() * scale.getFloat()));
    }

    public final int height() {
        return Math.max(1, Math.round(contentHeight() * scale.getFloat()));
    }

    /** Dibuja el widget (ya escalado) con su esquina superior izquierda en (x, y). */
    public final void render(DrawContext ctx, int x, int y) {
        float s = scale.getFloat();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale(s, s);
        draw(ctx, 0, 0);
        ctx.getMatrices().popMatrix();
    }

    // ---- ayudas de estilo para las subclases

    protected final int mulAlpha(int argb) {
        int a = (argb >>> 24) & 0xFF;
        a = a * opacity.getInt() / 100;
        return (a << 24) | (argb & 0x00FFFFFF);
    }

    protected final int accent() {
        return mulAlpha(customColor.get() ? ColorUtil.hsv(hue.getFloat(), 0.72f, 1f) : ThemePalette.ACCENT);
    }

    protected final int textColor() {
        return mulAlpha(ThemePalette.TEXT);
    }

    protected final int dimColor() {
        return mulAlpha(ThemePalette.TEXT_DIM);
    }

    protected final boolean minimal() {
        return style.index() == 2;
    }

    protected final void box(DrawContext ctx, int bx, int by, int w, int h) {
        switch (style.index()) {
            case 1 -> Render2D.roundedPanel(ctx, bx, by, w, h, 4, mulAlpha(0x400D0812), accent());
            case 2 -> {
            }
            default -> {
                Render2D.roundedRect(ctx, bx, by, w, h, 4, mulAlpha(0xB40D0812));
                ctx.fill(bx + 1, by + 3, bx + 3, by + h - 3, accent());
            }
        }
    }

    /** Dibuja una linea de texto respetando la alineacion elegida dentro de un ancho w. */
    protected final void label(DrawContext ctx, String text, int bx, int by, int w, int color) {
        int tw = mc.textRenderer.getWidth(text);
        int tx = switch (align.index()) {
            case 1 -> bx + (w - tw) / 2;
            case 2 -> bx + w - tw - 8;
            default -> bx + 8;
        };
        ctx.drawText(mc.textRenderer, text, tx, by, color, minimal());
    }

    // ---- acceso

    public final List<Setting> settings() {
        return Collections.unmodifiableList(settings);
    }

    public final void resetAll() {
        for (Setting setting : settings) {
            setting.reset();
        }
        resetPosition();
        enabled = true;
    }

    public final String id() {
        return id;
    }

    public final String name() {
        return name;
    }

    public final String shortName() {
        return shortName;
    }

    public final int x() {
        return x;
    }

    public final int y() {
        return y;
    }

    public final void setPosition(int nx, int ny) {
        this.x = nx;
        this.y = ny;
    }

    public final void resetPosition() {
        this.x = defaultX;
        this.y = defaultY;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final void setEnabled(boolean value) {
        this.enabled = value;
    }

    public final ToggleAnim anim() {
        return anim;
    }
}
