package com.kzclient.hud;

import net.minecraft.client.gui.DrawContext;

/** Widget de una linea de texto con caja. */
public abstract class TextWidget extends HudWidget {
    protected TextWidget(String id, String name, String shortName, int defaultX, int defaultY) {
        super(id, name, shortName, defaultX, defaultY);
    }

    protected abstract String text();

    @Override
    protected int autoWidth() {
        return mc.textRenderer.getWidth(text()) + 16;
    }

    @Override
    protected int contentHeight() {
        return 16;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        int w = contentWidth();
        box(ctx, x, y, w, contentHeight());
        label(ctx, text(), x, y + 4, w, textColor());
    }
}
