package com.kzclient.hud;

import com.kzclient.hud.widgets.ActiveModulesWidget;
import com.kzclient.hud.widgets.AntiAfkWidget;
import com.kzclient.hud.widgets.CoordinatesWidget;
import com.kzclient.hud.widgets.DirectionWidget;
import com.kzclient.hud.widgets.EffectsWidget;
import com.kzclient.hud.widgets.FpsWidget;
import com.kzclient.hud.widgets.KeystrokesWidget;
import com.kzclient.hud.widgets.NotificationsWidget;
import com.kzclient.hud.widgets.PingWidget;
import com.kzclient.hud.widgets.PlayerInfoWidget;
import com.kzclient.hud.widgets.RadarWidget;
import com.kzclient.hud.widgets.StaffListWidget;
import com.kzclient.hud.widgets.WatermarkWidget;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class HudManager {
    private final List<HudWidget> widgets = List.of(
            new WatermarkWidget(),
            new FpsWidget(),
            new PingWidget(),
            new CoordinatesWidget(),
            new DirectionWidget(),
            new PlayerInfoWidget(),
            new KeystrokesWidget(),
            new RadarWidget(),
            new EffectsWidget(),
            new StaffListWidget(),
            new AntiAfkWidget(),
            new NotificationsWidget(),
            new ActiveModulesWidget());
    private boolean enabled = true;

    public List<HudWidget> widgets() {
        return Collections.unmodifiableList(widgets);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        this.enabled = value;
    }

    public void resetAll() {
        enabled = true;
        for (HudWidget widget : widgets) {
            widget.resetAll();
        }
    }

    public void resetPositions() {
        for (HudWidget widget : widgets) {
            widget.resetPosition();
        }
    }

    public void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled || mc.player == null || mc.options.hudHidden) {
            return;
        }
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        for (HudWidget widget : widgets) {
            if (!widget.isEnabled()) {
                continue;
            }
            int x = Math.max(0, Math.min(widget.x(), sw - widget.width()));
            int y = Math.max(0, Math.min(widget.y(), sh - widget.height()));
            widget.render(ctx, x, y);
        }
    }
}
