package com.kzclient.hud.widgets;

import com.kzclient.KzClient;
import com.kzclient.hud.HudWidget;
import com.kzclient.module.modules.StaffList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;

public final class StaffListWidget extends HudWidget {
    public StaffListWidget() {
        super("stafflist", "StaffList", "STAFF", 9999, 150);
    }

    private StaffList module() {
        return KzClient.modules().get(StaffList.class);
    }

    @Override
    protected int autoWidth() {
        int w = 100;
        for (StaffList.Entry entry : module().online()) {
            w = Math.max(w, mc.textRenderer.getWidth(entry.name()) + 16);
        }
        return w;
    }

    @Override
    protected int contentHeight() {
        return 16 + Math.max(1, module().online().size()) * 12;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        StaffList module = module();
        if (!module.isEnabled()) {
            return;
        }
        List<StaffList.Entry> online = module.online();
        int w = contentWidth();
        box(ctx, x, y, w, contentHeight());
        label(ctx, "ONLINE " + online.size(), x, y + 4, w, accent());
        int ly = y + 16;
        if (online.isEmpty()) {
            label(ctx, "none", x, ly, w, dimColor());
            return;
        }
        for (StaffList.Entry entry : online) {
            label(ctx, entry.name(), x, ly, w, entry.staff() ? accent() : mulAlpha(0xFF55FF9A));
            ly += 12;
        }
    }
}
