package com.kzclient.hud.widgets;

import com.kzclient.KzClient;
import com.kzclient.gui.Render2D;
import com.kzclient.hud.HudWidget;
import com.kzclient.notify.NotificationManager;
import com.kzclient.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

/** Toasts de modulos y avisos (staff, vanish). */
public final class NotificationsWidget extends HudWidget {
    public NotificationsWidget() {
        super("notifications", "Notifications", "NOTIF", 160, 6);
    }

    @Override
    protected int autoWidth() {
        int w = 120;
        for (NotificationManager.Notice notice : KzClient.notifications().active()) {
            w = Math.max(w, mc.textRenderer.getWidth(notice.text()) + 18);
        }
        return w;
    }

    @Override
    protected int contentHeight() {
        return Math.max(1, KzClient.notifications().active().size()) * 18 - 2;
    }

    @Override
    protected void draw(DrawContext ctx, int x, int y) {
        int ny = y;
        int w = contentWidth();
        for (NotificationManager.Notice notice : KzClient.notifications().active()) {
            float alpha = KzClient.notifications().alpha(notice);
            int a = Math.round(alpha * 255f);
            if (a < 8) {
                continue;
            }
            if (!minimal()) {
                Render2D.roundedRect(ctx, x, ny, w, 16, 4, mulAlpha(ColorUtil.withAlpha(0x0D0812, Math.round(alpha * 180f))));
                ctx.fill(x + 1, ny + 3, x + 3, ny + 13, ColorUtil.withAlpha(accent(), Math.min(a, (accent() >>> 24))));
            }
            label(ctx, notice.text(), x, ny + 4, w, ColorUtil.withAlpha(textColor(), Math.min(a, (textColor() >>> 24))));
            ny += 18;
        }
    }
}
