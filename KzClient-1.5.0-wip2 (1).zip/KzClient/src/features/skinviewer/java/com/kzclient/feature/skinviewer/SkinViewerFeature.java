package com.kzclient.feature.skinviewer;

import com.kzclient.feature.Feature;
import com.kzclient.gui.SkinViewer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Visor de skin para Minecraft 1.21.11. Esta version de InventoryScreen ya no expone
 * la sobrecarga con Quaternionf; se usa la API publica vigente y se orienta temporalmente
 * el jugador antes de extraer su estado de renderizado.
 */
public final class SkinViewerFeature implements Feature {
    @Override
    public String id() {
        return "skinviewer";
    }

    @Override
    public String description() {
        return "360 degree skin viewer in PROFILE";
    }

    @Override
    public void init() {
        SkinViewer.setBackend(SkinViewerFeature::draw);
    }

    private static void draw(DrawContext ctx, int x1, int y1, int x2, int y2, int size,
                             float yawDegrees, float pitchDegrees, ClientPlayerEntity player) {
        // Guardar todos los angulos que se modifican para no alterar al jugador en el mundo.
        float bodyYaw = player.bodyYaw;
        float lastBodyYaw = player.lastBodyYaw;
        float headYaw = player.headYaw;
        float lastHeadYaw = player.lastHeadYaw;
        float yaw = player.getYaw();
        float pitch = player.getPitch();

        // El visor mira al frente y aplica el giro solicitado por el usuario (incluye 360 grados).
        float previewYaw = 180.0f + yawDegrees;
        player.bodyYaw = previewYaw;
        player.lastBodyYaw = previewYaw;
        player.headYaw = previewYaw;
        player.lastHeadYaw = previewYaw;
        player.setYaw(previewYaw);
        player.setPitch(pitchDegrees);

        try {
            // Firma publica de Yarn 1.21.11+build.4:
            // (DrawContext, int, int, int, int, int, float, float, float, LivingEntity)
            // El centro del recuadro evita introducir rotacion adicional por el mouse simulado.
            float centerX = (x1 + x2) * 0.5f;
            float centerY = (y1 + y2) * 0.5f;
            InventoryScreen.drawEntity(ctx, x1, y1, x2, y2, size, 0.0625f,
                    centerX, centerY, player);
        } finally {
            player.bodyYaw = bodyYaw;
            player.lastBodyYaw = lastBodyYaw;
            player.headYaw = headYaw;
            player.lastHeadYaw = lastHeadYaw;
            player.setYaw(yaw);
            player.setPitch(pitch);
        }
    }
}
