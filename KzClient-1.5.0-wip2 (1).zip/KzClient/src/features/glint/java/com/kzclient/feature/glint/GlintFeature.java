package com.kzclient.feature.glint;

import com.kzclient.feature.Feature;
import com.kzclient.module.Module;
import java.util.List;

/** CustomGlint: color (y arcoiris) del brillo de encantamiento, cambiando las texturas del brillo en tiempo real. */
public final class GlintFeature implements Feature {
    @Override
    public String id() {
        return "glint";
    }

    @Override
    public String description() {
        return "CustomGlint module (enchant glint color / rainbow)";
    }

    @Override
    public List<Module> modules() {
        return List.of(new CustomGlint());
    }
}
