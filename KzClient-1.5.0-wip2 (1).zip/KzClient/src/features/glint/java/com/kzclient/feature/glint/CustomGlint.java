package com.kzclient.feature.glint;

import com.kzclient.KzClient;
import com.kzclient.module.Category;
import com.kzclient.module.Module;
import com.kzclient.module.setting.BoolSetting;
import com.kzclient.module.setting.ColorSetting;
import com.kzclient.module.setting.NumberSetting;
import com.kzclient.util.ColorUtil;

/** Cambia el color del brillo de encantamiento de objetos y armaduras (propio o ajeno: es solo visual local). */
public final class CustomGlint extends Module {
    private final ColorSetting color = add(new ColorSetting("Color", 0xFF278F));
    private final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    private final NumberSetting speed = add(new NumberSetting("Rainbow speed", 1, 20, 1, 6));
    private final NumberSetting strength = add(new NumberSetting("Brightness", 0.5, 2.5, 0.1, 1.2));
    private boolean installed;
    private int lastRgb = -1;
    private float lastStrength = -1f;
    private long ticks;

    public CustomGlint() {
        super("CustomGlint", "Custom color for the enchantment glint.", Category.VISUALS);
    }

    private int currentRgb() {
        if (rainbow.get()) {
            float hue = (ticks * speed.getFloat() * 0.5f) % 360f;
            return ColorUtil.hsv(hue, 0.8f, 1f) & 0xFFFFFF;
        }
        return color.get() & 0xFFFFFF;
    }

    @Override
    public void onTick() {
        ticks++;
        try {
            if (!installed) {
                GlintTextures.install(mc);
                installed = true;
                lastRgb = -1;
            }
            // el arcoiris se actualiza como mucho cada 2 ticks para no subir la textura en cada tick
            if (rainbow.get() && ticks % 2 != 0) {
                return;
            }
            int rgb = currentRgb();
            float bright = strength.getFloat();
            if (rgb != lastRgb || bright != lastStrength) {
                GlintTextures.apply(rgb, bright);
                lastRgb = rgb;
                lastStrength = bright;
            }
        } catch (Throwable ex) {
            KzClient.LOGGER.error("CustomGlint fallo", ex);
            KzClient.notifications().push("CustomGlint failed: " + ex.getClass().getSimpleName());
            setEnabled(false);
        }
    }

    @Override
    protected void onDisable() {
        installed = false;
        lastRgb = -1;
        GlintTextures.restore(mc);
    }
}
