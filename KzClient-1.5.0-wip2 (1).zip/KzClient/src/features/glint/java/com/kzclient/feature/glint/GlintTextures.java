package com.kzclient.feature.glint;

import com.kzclient.KzClient;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/**
 * Sustituye las texturas del brillo de vanilla por copias tintadas del mismo archivo. Al desactivar se destruye la
 * textura propia y Minecraft vuelve a cargar la de vanilla de forma perezosa. Los ids que no existan en esta
 * version se saltan. El constructor de NativeImageBackedTexture se busca por reflexion sobre los TIPOS de sus
 * parametros (no por nombres), porque su forma cambio entre versiones.
 */
final class GlintTextures {
    private static final String[] PATHS = {
            "textures/misc/enchanted_glint_item.png",
            "textures/misc/enchanted_glint_entity.png",
            "textures/misc/enchanted_glint_armor.png"
    };

    private static final class Slot {
        final Identifier id;
        final NativeImageBackedTexture texture;
        final int[] base;
        final int width;
        final int height;

        Slot(Identifier id, NativeImageBackedTexture texture, int[] base, int width, int height) {
            this.id = id;
            this.texture = texture;
            this.base = base;
            this.width = width;
            this.height = height;
        }
    }

    private static final List<Slot> SLOTS = new ArrayList<>();

    private GlintTextures() {
    }

    static void install(MinecraftClient mc) throws Exception {
        restore(mc);
        for (String path : PATHS) {
            Identifier id = Identifier.ofVanilla(path);
            NativeImage image;
            try (InputStream in = mc.getResourceManager().open(id)) {
                image = NativeImage.read(in);
            } catch (IOException ex) {
                continue; // esta version no tiene esa textura
            }
            int w = image.getWidth();
            int h = image.getHeight();
            int[] base = new int[w * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    base[y * w + x] = image.getColorArgb(x, y);
                }
            }
            NativeImageBackedTexture texture = create(id.toString(), image);
            mc.getTextureManager().registerTexture(id, texture);
            SLOTS.add(new Slot(id, texture, base, w, h));
        }
        if (SLOTS.isEmpty()) {
            throw new IllegalStateException("no glint textures found");
        }
    }

    private static NativeImageBackedTexture create(String name, NativeImage image) throws ReflectiveOperationException {
        for (Constructor<?> constructor : NativeImageBackedTexture.class.getConstructors()) {
            Class<?>[] p = constructor.getParameterTypes();
            if (p.length == 2 && p[1] == NativeImage.class) {
                if (p[0] == String.class) {
                    return (NativeImageBackedTexture) constructor.newInstance(name, image);
                }
                if (p[0] == Supplier.class) {
                    Supplier<String> supplier = () -> name;
                    return (NativeImageBackedTexture) constructor.newInstance(supplier, image);
                }
            }
            if (p.length == 1 && p[0] == NativeImage.class) {
                return (NativeImageBackedTexture) constructor.newInstance(image);
            }
        }
        throw new NoSuchMethodException("NativeImageBackedTexture(?, NativeImage)");
    }

    /** Tinta las texturas: color = rgb * luminancia del pixel original * brillo; el alfa original se conserva. */
    static void apply(int rgb, float brightness) {
        float k = brightness * 2.0f;
        int tr = (rgb >> 16) & 0xFF;
        int tg = (rgb >> 8) & 0xFF;
        int tb = rgb & 0xFF;
        for (Slot slot : SLOTS) {
            NativeImage image = slot.texture.getImage();
            if (image == null) {
                continue;
            }
            for (int y = 0; y < slot.height; y++) {
                for (int x = 0; x < slot.width; x++) {
                    int px = slot.base[y * slot.width + x];
                    int a = (px >>> 24) & 0xFF;
                    float lum = (0.299f * ((px >> 16) & 0xFF) + 0.587f * ((px >> 8) & 0xFF) + 0.114f * (px & 0xFF))
                            / 255f * k;
                    int r = Math.min(255, Math.round(tr * lum));
                    int g = Math.min(255, Math.round(tg * lum));
                    int b = Math.min(255, Math.round(tb * lum));
                    image.setColorArgb(x, y, (a << 24) | (r << 16) | (g << 8) | b);
                }
            }
            slot.texture.upload();
        }
    }

    static void restore(MinecraftClient mc) {
        if (SLOTS.isEmpty()) {
            return;
        }
        for (Slot slot : SLOTS) {
            try {
                mc.getTextureManager().destroyTexture(slot.id);
            } catch (RuntimeException ex) {
                KzClient.LOGGER.warn("No se pudo restaurar {}", slot.id, ex);
            }
        }
        SLOTS.clear();
    }
}
